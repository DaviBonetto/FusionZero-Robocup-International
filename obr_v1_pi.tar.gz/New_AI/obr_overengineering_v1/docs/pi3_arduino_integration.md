# Raspberry Pi 3 + Arduino + Dashboard remoto

## Objetivo

- Raspberry Pi 3:
  - roda a IA oficial headless
  - publica eventos e frames para o dashboard remoto
  - envia comando serial para o Arduino
- PC:
  - abre o dashboard remoto
  - recebe logs, estado FSM, frames e deteccoes
- Arduino:
  - recebe comandos ASCII simples do Raspberry
  - aciona o motor

## Protocolo serial oficial desta etapa

Formato de linha:

```text
CMD FORWARD 5000
CMD STOP 0
```

Observacoes:

- cada comando termina com `\n`
- protocolo textual foi escolhido para facilitar debug por monitor serial
- primeira validacao oficial:
  - `GREEN` no `FOLLOWING_LINE` => `CMD FORWARD 5000`

## Histerese e antispam

- trigger somente apos `2` deteccoes consecutivas de `GREEN`
- cooldown padrao de `6000 ms`
- intervalo minimo entre envios: `120 ms`

Isso evita spam de serial quando a deteccao fica alta por muitos frames.

## Runner no Raspberry

Descubra primeiro a serial do Arduino:

```bash
ls /dev/ttyACM* /dev/ttyUSB* 2>/dev/null
ls /dev/serial/by-id/* 2>/dev/null
```

Suba o runner oficial headless:

```bash
python New_AI/obr_overengineering_v1/src/live_dashboard_runner.py \
  --headless \
  --camera-index 0 \
  --camera-width 640 \
  --camera-height 480 \
  --camera-fps 30 \
  --remote-bind 0.0.0.0 \
  --remote-port 8765 \
  --remote-stream-fps 8 \
  --remote-jpeg-quality 70 \
  --robot-serial-port /dev/ttyACM0 \
  --robot-baud 115200 \
  --robot-green-forward-ms 5000
```

Se quiser validar sem mover o robo:

```bash
python New_AI/obr_overengineering_v1/src/live_dashboard_runner.py \
  --headless \
  --camera-index 0 \
  --camera-width 640 \
  --camera-height 480 \
  --camera-fps 30 \
  --remote-bind 0.0.0.0 \
  --remote-port 8765 \
  --remote-stream-fps 8 \
  --remote-jpeg-quality 70 \
  --robot-serial-port /dev/ttyACM0 \
  --robot-baud 115200 \
  --robot-green-forward-ms 5000 \
  --robot-dry-run
```

## Dashboard no PC

```bash
python New_AI/obr_overengineering_v1/src/remote_dashboard_client.py \
  --host <IP_DO_RASPBERRY> \
  --port 8765
```

## O que deve aparecer no dashboard

- frames e overlays em tempo real
- estado FSM
- `Force LINE`
- `Force RESCUE`
- logs do adaptador serial:
  - `robot serial connected ...`
  - `robot command -> CMD FORWARD 5000 ...`

## Firmware exemplo do Arduino

Arquivo:

- `New_AI/obr_overengineering_v1/arduino/fusionzero_motor_bridge_template/fusionzero_motor_bridge_template.ino`

Esse sketch:

- interpreta `CMD FORWARD <ms>`
- interpreta `CMD STOP 0`
- responde `ACK ...`
- exige ajuste manual dos pinos do driver de motor

## Validacao minima em campo

1. carregar o sketch no Arduino
2. ligar Arduino no Raspberry via USB
3. confirmar a serial com `ls /dev/ttyACM* /dev/ttyUSB*`
4. subir o runner headless no Raspberry
5. abrir o dashboard no PC
6. mostrar um quadrado verde para a camera
7. confirmar no dashboard:
   - badge/deteccao de `GREEN`
   - log `robot command -> CMD FORWARD 5000`
8. confirmar no robo:
   - movimento para frente por 5 segundos

## Dependencia adicional no Raspberry

```bash
python -m pip install pyserial
```
