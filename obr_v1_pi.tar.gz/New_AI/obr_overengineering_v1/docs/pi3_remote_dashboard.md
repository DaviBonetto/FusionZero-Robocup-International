# Raspberry Pi 3 + PC Dashboard

## Objetivo

Rodar a IA e a camera no Raspberry Pi 3 e exibir o dashboard completo no computador pela mesma rede Wi-Fi.

## Arquitetura oficial

- Raspberry Pi 3:
  - captura camera
  - roda visao, FSM e publicacao de eventos
  - abre um relay TCP para o dashboard remoto
- PC:
  - conecta no relay TCP do Raspberry
  - recebe frames, deteccoes, estado, logs e telemetria
  - envia `UI_COMMAND` de volta para o Raspberry

## Comando no Raspberry Pi 3

```bash
python New_AI/obr_overengineering_v1/src/live_dashboard_runner.py \
  --headless \
  --camera-index 0 \
  --camera-width 640 \
  --camera-height 480 \
  --camera-fps 30 \
  --remote-bind 0.0.0.0 \
  --remote-port 8765 \
  --remote-stream-fps 8 \
  --remote-jpeg-quality 70
```

## Comando no PC

Troque `<IP_DO_RASPBERRY>` pelo IP real dele na rede Wi-Fi.

```bash
python New_AI/obr_overengineering_v1/src/remote_dashboard_client.py \
  --host <IP_DO_RASPBERRY> \
  --port 8765
```

## Recomendacao para Pi 3

- manter `--remote-stream-fps 8`
- manter `--remote-jpeg-quality 70`
- fechar apps desnecessarios no Pi
- se precisar aliviar mais:
  - reduzir camera para `320x240`
  - reduzir `camera-fps` para `20`
  - reduzir `remote-stream-fps` para `5`

## O que funciona pela rede

- `Processed View`
- `Raw View`
- status badges
- logs
- estado FSM
- telemetria
- comandos da UI:
  - reconnect camera
  - tuning
  - `Force LINE`
  - `Force RESCUE`

## Requisitos de rede

- Raspberry e PC na mesma Wi-Fi
- nao precisa internet boa; so rede local estavel
- hotspot do celular pode funcionar, mas roteador normal tende a ser mais estavel

## Teste rapido

1. descobrir o IP do Raspberry com `hostname -I`
2. subir o runner headless no Raspberry
3. subir o dashboard remoto no PC
4. validar se o dashboard reage em tempo real
5. testar `Force LINE` e `Force RESCUE`
