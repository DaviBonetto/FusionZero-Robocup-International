/*
  FusionZero serial motor bridge template

  Protocol:
    CMD FORWARD <duration_ms>\n
    CMD STOP 0\n

  Response:
    ACK FORWARD <duration_ms>
    ACK STOP
    ERR <reason>

  Edit the pin mapping below to match the motor driver actually used on the robot.
  This template assumes a common differential-drive H-bridge topology with:
    - one PWM pin per motor
    - two direction pins per motor
*/

const long SERIAL_BAUD = 115200;

const int LEFT_PWM_PIN = 5;
const int LEFT_IN1_PIN = 7;
const int LEFT_IN2_PIN = 8;
const int RIGHT_PWM_PIN = 6;
const int RIGHT_IN1_PIN = 9;
const int RIGHT_IN2_PIN = 10;

const int DEFAULT_SPEED = 170;

String lineBuffer;
unsigned long forwardUntilMs = 0;

void setup() {
  Serial.begin(SERIAL_BAUD);

  pinMode(LEFT_PWM_PIN, OUTPUT);
  pinMode(LEFT_IN1_PIN, OUTPUT);
  pinMode(LEFT_IN2_PIN, OUTPUT);
  pinMode(RIGHT_PWM_PIN, OUTPUT);
  pinMode(RIGHT_IN1_PIN, OUTPUT);
  pinMode(RIGHT_IN2_PIN, OUTPUT);

  stopMotors();
  Serial.println("READY FUSIONZERO");
}

void loop() {
  while (Serial.available() > 0) {
    char ch = (char)Serial.read();
    if (ch == '\n' || ch == '\r') {
      if (lineBuffer.length() > 0) {
        handleCommand(lineBuffer);
        lineBuffer = "";
      }
    } else {
      lineBuffer += ch;
    }
  }

  if (forwardUntilMs > 0 && millis() >= forwardUntilMs) {
    stopMotors();
    forwardUntilMs = 0;
    Serial.println("ACK STOP");
  }
}

void handleCommand(const String& command) {
  if (command.startsWith("CMD FORWARD ")) {
    long durationMs = command.substring(12).toInt();
    if (durationMs <= 0) {
      Serial.println("ERR invalid_duration");
      return;
    }
    driveForward(DEFAULT_SPEED);
    forwardUntilMs = millis() + (unsigned long)durationMs;
    Serial.print("ACK FORWARD ");
    Serial.println(durationMs);
    return;
  }

  if (command == "CMD STOP 0") {
    stopMotors();
    forwardUntilMs = 0;
    Serial.println("ACK STOP");
    return;
  }

  Serial.println("ERR unknown_command");
}

void driveForward(int pwm) {
  digitalWrite(LEFT_IN1_PIN, HIGH);
  digitalWrite(LEFT_IN2_PIN, LOW);
  digitalWrite(RIGHT_IN1_PIN, HIGH);
  digitalWrite(RIGHT_IN2_PIN, LOW);
  analogWrite(LEFT_PWM_PIN, pwm);
  analogWrite(RIGHT_PWM_PIN, pwm);
}

void stopMotors() {
  analogWrite(LEFT_PWM_PIN, 0);
  analogWrite(RIGHT_PWM_PIN, 0);
  digitalWrite(LEFT_IN1_PIN, LOW);
  digitalWrite(LEFT_IN2_PIN, LOW);
  digitalWrite(RIGHT_IN1_PIN, LOW);
  digitalWrite(RIGHT_IN2_PIN, LOW);
}
