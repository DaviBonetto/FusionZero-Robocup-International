from __future__ import annotations

import argparse
import math
import sys
import threading
import time
from pathlib import Path
from typing import Any, Mapping

import cv2
import psutil

if __package__ in (None, ""):
    PROJECT_ROOT = Path(__file__).resolve().parents[1]
    SRC_ROOT = Path(__file__).resolve().parent
    if str(PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(PROJECT_ROOT))
    if str(SRC_ROOT) not in sys.path:
        sys.path.insert(0, str(SRC_ROOT))

    from src.core.event_bus import EventBus, EventTopic, HealthEvent, LogEvent, PoseEvent, UICommandEvent, VisionDetectionEvent
    from src.core.state_machine import RobotEvent, RobotState, StateMachine
    from src.remote_dashboard import RemoteDashboardServer
    from src.modules.control import RobotSerialConfig, SerialRobotAdapter
    from src.modules.vision.vision_node import VisionNode
    from src.ui_overengineering.dashboard import run_dashboard
else:
    from .core.event_bus import EventBus, EventTopic, HealthEvent, LogEvent, PoseEvent, UICommandEvent, VisionDetectionEvent
    from .core.state_machine import RobotEvent, RobotState, StateMachine
    from .remote_dashboard import RemoteDashboardServer
    from .modules.control import RobotSerialConfig, SerialRobotAdapter
    from .modules.vision.vision_node import VisionNode
    from .ui_overengineering.dashboard import run_dashboard


class LiveDashboardRunner:
    def __init__(
        self,
        *,
        camera_index: int,
        camera_width: int,
        camera_height: int,
        camera_fps: int,
        config_path: str | Path | None = None,
        robot_serial_port: str | None = None,
        robot_baud: int = 115200,
        robot_green_forward_ms: int = 5000,
        robot_green_streak: int = 2,
        robot_green_cooldown_ms: int = 6000,
        robot_dry_run: bool = False,
    ) -> None:
        self.camera_index = int(camera_index)
        self.camera_width = int(camera_width)
        self.camera_height = int(camera_height)
        self.camera_fps = max(1, int(camera_fps))
        self.config_path = config_path

        self.bus = EventBus(max_queue_size=2048, drop_oldest=True)
        self.fsm = StateMachine(event_bus=self.bus)
        self.vision = VisionNode(
            self.bus,
            config=config_path,
            publish_raw_frame=True,
            publish_processed_frame=True,
        )
        self.robot = SerialRobotAdapter(
            self.bus,
            config=RobotSerialConfig(
                port=(str(robot_serial_port).strip() if robot_serial_port else None),
                baud_rate=int(robot_baud),
                green_forward_ms=int(robot_green_forward_ms),
                green_trigger_streak=int(robot_green_streak),
                green_cooldown_ms=int(robot_green_cooldown_ms),
                dry_run=bool(robot_dry_run),
            ),
        )

        self._capture_lock = threading.RLock()
        self._capture: Any = None
        self._stop_event = threading.Event()
        self._worker: threading.Thread | None = None

        self._frame_id = 0
        self._last_capture_ts = 0.0
        self._fps_capture = 0.0
        self._last_health_ts = 0.0
        self._last_no_camera_log = 0.0

        self._line_lost_streak = 0
        self._line_found_streak = 0
        self._pose_x = 0.0
        self._pose_y = 0.0
        self._pose_theta = 0.0

        self._subs = [
            self.bus.subscribe(EventTopic.VISION_DETECTIONS, self._on_detection),
            self.bus.subscribe(EventTopic.UI_COMMAND, self._on_ui_command),
        ]

    def start(self) -> None:
        self._open_camera()
        self.robot.start()
        self._worker = threading.Thread(target=self._capture_loop, name="live-dashboard-capture", daemon=True)
        self._worker.start()
        self._publish_log("INFO", f"live runner started cam={self.camera_index} {self.camera_width}x{self.camera_height}@{self.camera_fps}")

    def stop(self) -> None:
        self._stop_event.set()
        if self._worker is not None:
            self._worker.join(timeout=2.0)
        self._worker = None

        for sub in self._subs:
            try:
                sub.unsubscribe()
            except Exception:
                pass
        self._subs.clear()

        self._release_camera()
        self.robot.stop()
        self.vision.close()
        self.bus.stop()

    def _capture_loop(self) -> None:
        while not self._stop_event.is_set():
            cap = self._get_capture()
            if cap is None:
                now = time.monotonic()
                if now - self._last_no_camera_log >= 2.0:
                    self._last_no_camera_log = now
                    self._publish_log("WARNING", f"camera {self.camera_index} unavailable, retrying")
                self._open_camera()
                time.sleep(0.2)
                continue

            ok, frame = cap.read()
            if not ok or frame is None:
                self._publish_log("WARNING", f"camera {self.camera_index} frame read failed")
                time.sleep(0.03)
                continue

            ts = time.time()
            self._frame_id += 1
            try:
                self.vision.process_frame(frame, frame_id=self._frame_id, timestamp=ts)
            except Exception as exc:
                self._publish_log("ERROR", f"vision process failed: {exc}")
                time.sleep(0.01)
                continue

            self._update_capture_fps()
            self._publish_health_if_due()

    def _on_detection(self, event: VisionDetectionEvent) -> None:
        if not isinstance(event, VisionDetectionEvent):
            return

        self._inject_telemetry(event)
        self._publish_pose(event)

        trigger: RobotEvent | None = None
        reason = "vision_live"

        if event.red:
            trigger = RobotEvent.ON_RESCUE_RED_DETECTED
        elif event.victims > 0:
            trigger = RobotEvent.ON_VICTIM_DETECTED
        elif event.line:
            self._line_found_streak += 1
            self._line_lost_streak = 0
            if self.fsm.state in {
                RobotState.SEARCHING_LINE,
                RobotState.VALIDATING_GAP,
                RobotState.CROSSING_GAP,
            }:
                trigger = RobotEvent.ON_LINE_FOUND
            elif self.fsm.state == RobotState.FOLLOWING_LINE and event.green:
                trigger = RobotEvent.ON_INTERSECTION
        else:
            self._line_lost_streak += 1
            self._line_found_streak = 0
            if self.fsm.state == RobotState.FOLLOWING_LINE and self._line_lost_streak == 1:
                trigger = RobotEvent.ON_GAP
                reason = "line_gap_suspected"
            elif self._line_lost_streak >= 3:
                trigger = RobotEvent.ON_LINE_LOST
                reason = "line_lost_streak"

        if trigger is None:
            return
        try:
            self.fsm.handle(trigger, payload={"reason": reason})
        except Exception as exc:
            self._publish_log("ERROR", f"fsm handle failed: {exc}")

    def _on_ui_command(self, event: UICommandEvent) -> None:
        if not isinstance(event, UICommandEvent):
            return
        command = str(event.command or "").strip().lower()
        params = event.params if isinstance(event.params, Mapping) else {}

        if command == "tuning.update":
            key = str(params.get("key", "")).strip()
            value = params.get("value")
            if key:
                self._apply_tuning(key, value)
            return

        if command == "camera.reconnect":
            self.camera_index = int(params.get("index", self.camera_index))
            self.camera_width = int(params.get("width", self.camera_width))
            self.camera_height = int(params.get("height", self.camera_height))
            self.camera_fps = max(1, int(params.get("fps", self.camera_fps)))
            self._open_camera()
            self._publish_log(
                "INFO",
                f"camera reconfigured idx={self.camera_index} {self.camera_width}x{self.camera_height}@{self.camera_fps}",
            )
            return

        if command == "fsm.force_mode":
            mode = str(params.get("mode", "")).strip().lower()
            if mode == "line":
                trigger = RobotEvent.ON_LINE_FOUND
            elif mode == "rescue":
                trigger = RobotEvent.ON_RESCUE_RED_DETECTED
            else:
                self._publish_log("WARNING", f"unknown mode request: {mode!r}")
                return
            try:
                self.fsm.handle(trigger, payload={"reason": f"ui_force_mode:{mode}"})
                self._publish_log("INFO", f"fsm forced to {self.fsm.state.value} via {mode}")
            except Exception as exc:
                self._publish_log("ERROR", f"fsm force mode failed: {exc}")

    def _apply_tuning(self, key: str, value: object) -> None:
        manager = self.vision._pipeline
        line = manager.line_detector
        color = manager.color_detector
        ball = manager.ball_detector

        try:
            if key == "line.black_v_max":
                line.black_v_max = int(value)
            elif key == "line.black_s_max":
                line.black_s_max = int(value)
            elif key == "line.min_area":
                line.min_black_area = int(value)
            elif key == "line.erode_iter":
                line.erode_iter = int(value)
            elif key == "line.dilate_iter":
                line.dilate_iter = int(value)
            elif key == "green.h_min":
                color.green_h_min = int(value)
            elif key == "green.h_max":
                color.green_h_max = int(value)
            elif key == "green.min_area":
                color.green_min_area = float(value)
            elif key == "red.h1_min":
                color.red_h1_min = int(value)
            elif key == "red.h1_max":
                color.red_h1_max = int(value)
            elif key == "red.h2_min":
                color.red_h2_min = int(value)
            elif key == "red.h2_max":
                color.red_h2_max = int(value)
            elif key == "red.min_area":
                color.red_min_area = float(value)
            elif key == "silver.conf":
                manager.silver.threshold = float(value)
            elif key == "silver.blur":
                blur = max(3, int(value))
                ball.silver_blur = blur if blur % 2 == 1 else blur + 1
            elif key == "dead.black_v_max":
                v = max(0, min(255, int(value)))
                ball.dead_black_threshold = (v, v, v)
            else:
                return
            self._publish_log("INFO", f"tuning applied {key}={value}")
        except Exception as exc:
            self._publish_log("ERROR", f"failed tuning {key}: {exc}")

    def _inject_telemetry(self, event: VisionDetectionEvent) -> None:
        metadata = event.metadata if isinstance(event.metadata, dict) else {}
        angle = float(metadata.get("line_angle_deg", 90.0))
        front = max(120, int(1200 - abs(angle - 90.0) * 8.0))
        left = max(100, int(900 + (angle - 90.0) * 9.0))
        right = max(100, int(900 - (angle - 90.0) * 9.0))
        back = 1400 if event.line else max(250, int(500 + self._line_lost_streak * 120))
        metadata["telemetry"] = {
            "front": front,
            "left": left,
            "right": right,
            "back": back,
            "yaw": round(self._pose_theta * 180.0 / math.pi, 2),
            "roll": round(math.sin(time.monotonic() * 0.7) * 4.0, 2),
            "pitch": round(math.cos(time.monotonic() * 0.6) * 4.0, 2),
            "gripper": 90 if event.victims == 0 else 1400,
        }
        event.metadata = metadata

    def _publish_pose(self, event: VisionDetectionEvent) -> None:
        angle_deg = float(event.metadata.get("line_angle_deg", 90.0)) if isinstance(event.metadata, Mapping) else 90.0
        self._pose_theta = math.radians(max(0.0, min(180.0, angle_deg)) - 90.0)
        step = 0.012 if event.line else 0.004
        self._pose_x += math.cos(self._pose_theta) * step
        self._pose_y += math.sin(self._pose_theta) * step

        try:
            self.bus.publish(
                EventTopic.NAV_POSE,
                PoseEvent(timestamp=time.time(), x=self._pose_x, y=self._pose_y, theta=self._pose_theta),
            )
        except Exception:
            pass

    def _update_capture_fps(self) -> None:
        now = time.perf_counter()
        if self._last_capture_ts <= 0:
            self._last_capture_ts = now
            return
        dt = now - self._last_capture_ts
        self._last_capture_ts = now
        if dt <= 0:
            return
        instant = 1.0 / dt
        self._fps_capture = instant if self._fps_capture <= 0 else (0.9 * self._fps_capture + 0.1 * instant)

    def _publish_health_if_due(self) -> None:
        now = time.monotonic()
        if now - self._last_health_ts < 0.2:
            return
        self._last_health_ts = now
        try:
            self.bus.publish(
                EventTopic.SYSTEM_HEALTH,
                HealthEvent(
                    timestamp=time.time(),
                    cpu_percent=float(psutil.cpu_percent(interval=None)),
                    fps_capture=float(self._fps_capture),
                    fps_process=float(self.vision.fps),
                    fps_ui=float(self.vision.fps),
                    queue_depth=int(self.bus.queue_depth),
                ),
            )
        except Exception:
            pass

    def _open_camera(self) -> None:
        with self._capture_lock:
            self._release_camera_locked()

            backend = cv2.CAP_DSHOW if hasattr(cv2, "CAP_DSHOW") else cv2.CAP_ANY
            cap = cv2.VideoCapture(self.camera_index, backend)
            if cap is None or not cap.isOpened():
                cap = cv2.VideoCapture(self.camera_index)
            if cap is None or not cap.isOpened():
                self._capture = None
                return

            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.camera_width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.camera_height)
            cap.set(cv2.CAP_PROP_FPS, self.camera_fps)
            self._capture = cap

    def _get_capture(self) -> Any:
        with self._capture_lock:
            return self._capture

    def _release_camera(self) -> None:
        with self._capture_lock:
            self._release_camera_locked()

    def _release_camera_locked(self) -> None:
        cap = self._capture
        self._capture = None
        if cap is None:
            return
        try:
            cap.release()
        except Exception:
            pass

    def _publish_log(self, level: str, message: str) -> None:
        try:
            self.bus.publish(
                EventTopic.SYSTEM_LOG,
                LogEvent(
                    timestamp=time.time(),
                    level=level,
                    message=message,
                    source="live_runner",
                    state=self.fsm.state.value,
                ),
            )
        except Exception:
            pass


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Live camera + AI runner for overengineering dashboard")
    parser.add_argument("--camera-index", type=int, default=0, help="Camera index")
    parser.add_argument("--camera-width", type=int, default=640, help="Camera capture width")
    parser.add_argument("--camera-height", type=int, default=480, help="Camera capture height")
    parser.add_argument("--camera-fps", type=int, default=30, help="Camera capture FPS target")
    parser.add_argument("--headless", action="store_true", help="Run only the AI + remote relay server, without opening a local dashboard")
    parser.add_argument(
        "--config",
        type=str,
        default="New_AI/obr_overengineering_v1/configs/vision_config.json",
        help="Vision config path",
    )
    parser.add_argument("--remote-bind", type=str, default="0.0.0.0", help="Bind address for the remote dashboard relay")
    parser.add_argument("--remote-port", type=int, default=8765, help="TCP port for the remote dashboard relay")
    parser.add_argument("--remote-stream-fps", type=float, default=8.0, help="Max frame rate sent to the remote dashboard")
    parser.add_argument("--remote-jpeg-quality", type=int, default=70, help="JPEG quality used for remote frame streaming")
    parser.add_argument("--robot-serial-port", type=str, default="", help="Arduino serial port on the Raspberry, for example /dev/ttyACM0")
    parser.add_argument("--robot-baud", type=int, default=115200, help="Arduino serial baud rate")
    parser.add_argument("--robot-green-forward-ms", type=int, default=5000, help="Milliseconds sent on GREEN integration test")
    parser.add_argument("--robot-green-streak", type=int, default=2, help="Consecutive GREEN detections required before triggering")
    parser.add_argument("--robot-green-cooldown-ms", type=int, default=6000, help="Cooldown between GREEN motor commands")
    parser.add_argument("--robot-dry-run", action="store_true", help="Log robot commands without writing to serial")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    runner = LiveDashboardRunner(
        camera_index=args.camera_index,
        camera_width=args.camera_width,
        camera_height=args.camera_height,
        camera_fps=args.camera_fps,
        config_path=args.config,
        robot_serial_port=args.robot_serial_port,
        robot_baud=args.robot_baud,
        robot_green_forward_ms=args.robot_green_forward_ms,
        robot_green_streak=args.robot_green_streak,
        robot_green_cooldown_ms=args.robot_green_cooldown_ms,
        robot_dry_run=args.robot_dry_run,
    )
    remote_server: RemoteDashboardServer | None = None
    runner.start()
    try:
        if args.headless:
            remote_server = RemoteDashboardServer(
                runner.bus,
                host=args.remote_bind,
                port=args.remote_port,
                stream_fps=args.remote_stream_fps,
                jpeg_quality=args.remote_jpeg_quality,
            )
            remote_server.start()
            runner._publish_log(
                "INFO",
                (
                    f"remote dashboard relay listening on {args.remote_bind}:{args.remote_port} "
                    f"fps={args.remote_stream_fps} jpeg_q={args.remote_jpeg_quality}"
                ),
            )
            try:
                while True:
                    time.sleep(0.5)
            except KeyboardInterrupt:
                return 0
        return run_dashboard(
            event_bus=runner.bus,
            camera_index=args.camera_index,
            camera_width=args.camera_width,
            camera_height=args.camera_height,
            camera_fps=args.camera_fps,
            mock=False,
        )
    finally:
        if remote_server is not None:
            remote_server.stop()
        runner.stop()


if __name__ == "__main__":
    raise SystemExit(main())
