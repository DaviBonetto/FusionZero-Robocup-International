from __future__ import annotations

import argparse
import math
import sys
import threading
import time
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

import numpy as np
from PyQt6.QtCore import QObject, QThread, QTimer, Qt, pyqtSignal, pyqtSlot
from PyQt6.QtWidgets import QApplication, QHBoxLayout, QMainWindow, QSplitter, QVBoxLayout, QWidget

try:
    import cv2
except Exception:  # pragma: no cover
    cv2 = None

if __package__ in (None, ""):
    SRC_ROOT = Path(__file__).resolve().parents[1]
    if str(SRC_ROOT) not in sys.path:
        sys.path.insert(0, str(SRC_ROOT))

    from core.event_bus import (  # type: ignore
        EventBus,
        EventTopic,
        FrameEvent,
        HealthEvent,
        LogEvent,
        PathEvent,
        StateSnapshotEvent,
        StateTransitionEvent,
        UICommandEvent,
        VisionDetectionEvent,
    )
    from ui_overengineering.components import (  # type: ignore
        RobotPlaceholderPanel,
        StatusPanel,
        SteeringPanel,
        TelemetryPanel,
        TimerPanel,
        TopMetricsBar,
        TransitionLogPanel,
        TuningPanel,
        VideoView,
        build_dashboard_stylesheet,
    )
else:
    from ..core.event_bus import (
        EventBus,
        EventTopic,
        FrameEvent,
        HealthEvent,
        LogEvent,
        PathEvent,
        StateSnapshotEvent,
        StateTransitionEvent,
        UICommandEvent,
        VisionDetectionEvent,
    )
    from .components import (
        RobotPlaceholderPanel,
        StatusPanel,
        SteeringPanel,
        TelemetryPanel,
        TimerPanel,
        TopMetricsBar,
        TransitionLogPanel,
        TuningPanel,
        VideoView,
        build_dashboard_stylesheet,
    )


STATUS_TEMPLATE: dict[str, bool] = {
    "LINE": False,
    "SILVER": False,
    "GREEN": False,
    "RED": False,
    "GREEN CORNER": False,
    "RED CORNER": False,
    "SILVER BALL": False,
    "BLACK BALL": False,
}


STATE_SEQUENCE: tuple[str, ...] = (
    "SEARCHING_LINE",
    "FOLLOWING_LINE",
    "VALIDATING_GAP",
    "CROSSING_GAP",
    "VICTIM_FOUND",
    "RESCUE_ZONE_DETECTED",
)


def _iso_timestamp(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat(timespec="milliseconds")


def _safe_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        return float(value)
    except Exception:
        return None


def _frame_from_event(event: FrameEvent) -> np.ndarray | None:
    encoding = str(event.encoding or "bgr8").strip().lower()
    if encoding in {"jpeg", "jpg"}:
        if cv2 is None or not event.data:
            return None
        encoded = np.frombuffer(event.data, dtype=np.uint8)
        frame = cv2.imdecode(encoded, cv2.IMREAD_COLOR)
        if frame is None or frame.size == 0:
            return None
        return np.ascontiguousarray(frame)

    if event.width <= 0 or event.height <= 0:
        return None
    raw = np.frombuffer(event.data, dtype=np.uint8)
    expected = event.width * event.height * 3
    if raw.size < expected:
        return None
    frame = raw[:expected].reshape((event.height, event.width, 3))
    if encoding.startswith("rgb"):
        frame = frame[:, :, ::-1]
    return np.ascontiguousarray(frame)


class UiBridge(QObject):
    raw_frame_event = pyqtSignal(object)
    processed_frame_event = pyqtSignal(object)
    detection_event = pyqtSignal(object)
    state_event = pyqtSignal(object)
    transition_event = pyqtSignal(object)
    health_event = pyqtSignal(object)
    log_event = pyqtSignal(object)
    path_event = pyqtSignal(object)
    camera_frame = pyqtSignal(object)
    camera_status = pyqtSignal(str)


class CameraCaptureWorker(QObject):
    frame_ready = pyqtSignal(object)
    status = pyqtSignal(str)

    def __init__(self, index: int, width: int, height: int, fps: int) -> None:
        super().__init__()
        self._index = int(index)
        self._width = int(width)
        self._height = int(height)
        self._fps = max(1, int(fps))
        self._timer: QTimer | None = None
        self._capture: Any = None
        self._running = False
        self._last_fail_status_ts = 0.0

    @pyqtSlot()
    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._ensure_timer()
        self._open_camera()
        self._timer.start(max(8, int(1000 / max(1, self._fps))))

    @pyqtSlot()
    def stop(self) -> None:
        self._running = False
        if self._timer is not None:
            self._timer.stop()
        self._release_camera()

    @pyqtSlot(int, int, int, int)
    def set_config(self, index: int, width: int, height: int, fps: int) -> None:
        self._index = int(index)
        self._width = int(width)
        self._height = int(height)
        self._fps = max(1, int(fps))
        if self._timer is not None:
            self._timer.setInterval(max(8, int(1000 / max(1, self._fps))))
        if self._running:
            self._open_camera()

    @pyqtSlot()
    def reconnect(self) -> None:
        if self._running:
            self._open_camera()

    def _ensure_timer(self) -> None:
        if self._timer is not None:
            return
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)

    def _open_camera(self) -> None:
        self._release_camera()
        if cv2 is None:
            self.status.emit("camera unavailable: opencv not installed")
            return

        cap = cv2.VideoCapture(self._index, cv2.CAP_DSHOW) if hasattr(cv2, "CAP_DSHOW") else cv2.VideoCapture(self._index)
        if not cap.isOpened():
            cap = cv2.VideoCapture(self._index)

        if cap is None or not cap.isOpened():
            self.status.emit(f"camera {self._index} not available")
            return

        cap.set(cv2.CAP_PROP_FRAME_WIDTH, self._width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._height)
        cap.set(cv2.CAP_PROP_FPS, self._fps)
        self._capture = cap
        self.status.emit(f"camera {self._index} connected ({self._width}x{self._height}@{self._fps})")

    def _release_camera(self) -> None:
        if self._capture is None:
            return
        try:
            self._capture.release()
        except Exception:
            pass
        self._capture = None

    def _tick(self) -> None:
        if not self._running:
            return
        if self._capture is None:
            return
        ok, frame = self._capture.read()
        if not ok or frame is None:
            now = time.monotonic()
            if now - self._last_fail_status_ts >= 2.0:
                self._last_fail_status_ts = now
                self.status.emit(f"camera {self._index} frame read failed")
            return
        self.frame_ready.emit(np.ascontiguousarray(frame))


class MockSource(QObject):
    raw_frame = pyqtSignal(object)
    processed_frame = pyqtSignal(object)
    detection_event = pyqtSignal(object)
    state_event = pyqtSignal(object)
    transition_event = pyqtSignal(object)
    health_event = pyqtSignal(object)
    log_event = pyqtSignal(object)

    def __init__(self, fps: int = 14) -> None:
        super().__init__()
        self._fps = max(2, int(fps))
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._frame_id = 0
        self._state_index = 0
        self._state_change_ts = time.monotonic()
        self._current_state = STATE_SEQUENCE[self._state_index]

    def start(self) -> None:
        if self._timer.isActive():
            return
        self._timer.start(int(1000 / self._fps))

    def stop(self) -> None:
        self._timer.stop()

    def is_running(self) -> bool:
        return self._timer.isActive()

    def _tick(self) -> None:
        self._frame_id += 1
        now_wall = time.time()
        now_mono = time.monotonic()
        phase = self._frame_id / 11.0

        if now_mono - self._state_change_ts >= 5.0:
            old_state = self._current_state
            self._state_index = (self._state_index + 1) % len(STATE_SEQUENCE)
            self._current_state = STATE_SEQUENCE[self._state_index]
            self._state_change_ts = now_mono
            transition = StateTransitionEvent(
                timestamp=now_wall,
                old_state=old_state,
                new_state=self._current_state,
                trigger="ON_TIMEOUT",
                reason="mock progression",
            )
            self.transition_event.emit(transition)
            self.state_event.emit(StateSnapshotEvent(timestamp=now_wall, state=self._current_state))
            self.log_event.emit(
                LogEvent(
                    timestamp=now_wall,
                    level="INFO",
                    message=f"{old_state} --ON_TIMEOUT--> {self._current_state} | mock progression",
                    source="ui.mock",
                    state=self._current_state,
                )
            )

        line_on = self._current_state != "SEARCHING_LINE" or (math.sin(phase) > 0.1)
        silver_on = self._current_state == "VALIDATING_GAP" and math.sin(phase * 1.8) > 0.0
        green_on = self._current_state in {"FOLLOWING_LINE", "VALIDATING_GAP"} and math.cos(phase * 1.3) > 0.45
        red_on = self._current_state == "RESCUE_ZONE_DETECTED" or (
            self._current_state == "FOLLOWING_LINE" and math.sin(phase * 0.7) > 0.95
        )
        silver_ball_on = self._current_state == "VICTIM_FOUND" and math.sin(phase * 1.1) > -0.1
        black_ball_on = self._current_state == "VICTIM_FOUND" and math.cos(phase * 1.1) > 0.65
        latency_ms = 12.0 + 8.0 * abs(math.sin(phase * 0.85))

        telemetry = {
            "front": int(600 + 350 * math.sin(phase * 0.8)),
            "left": int(900 + 500 * math.cos(phase * 0.7)),
            "right": int(350 + 260 * math.sin(phase * 1.15)),
            "back": int(700 + 400 * math.cos(phase * 0.6)),
            "yaw": round((math.degrees(math.sin(phase * 0.35)) * 2.5), 2),
            "roll": round(5.0 * math.cos(phase * 0.4), 2),
            "pitch": round(4.0 * math.sin(phase * 0.45), 2),
            "gripper": int(90 + 20 * math.sin(phase * 0.5)),
        }
        metadata: dict[str, Any] = {
            "telemetry": telemetry,
            "silver_line": {"found": silver_on, "confidence": 0.96 if silver_on else 0.32},
            "dead_victim": {"found": black_ball_on, "confidence": 0.91 if black_ball_on else 0.22},
            "mock": True,
        }

        detection = VisionDetectionEvent(
            timestamp=now_wall,
            state=self._current_state,
            line=line_on,
            balls=1 if silver_ball_on else 0,
            green=green_on,
            red=red_on,
            victims=1 if black_ball_on else 0,
            latency_ms=latency_ms,
            metadata=metadata,
        )

        raw = self._build_frame(phase, self._current_state, detection, processed=False)
        processed = self._build_frame(phase, self._current_state, detection, processed=True)
        self.raw_frame.emit(raw)
        self.processed_frame.emit(processed)
        self.detection_event.emit(detection)
        self.health_event.emit(
            HealthEvent(
                timestamp=now_wall,
                cpu_percent=45.0 + 22.0 * abs(math.sin(phase * 0.38)),
                fps_capture=float(self._fps),
                fps_process=1000.0 / max(latency_ms, 1e-3),
                fps_ui=float(self._fps),
                queue_depth=int(1 + abs(math.sin(phase * 0.4)) * 3),
            )
        )

    def _build_frame(self, phase: float, state: str, detection: VisionDetectionEvent, *, processed: bool) -> np.ndarray:
        height, width = 360, 640
        frame = np.zeros((height, width, 3), dtype=np.uint8)
        base = 34 if not processed else 28
        frame[:, :] = (base + 8, base + 9, base + 12)
        gradient = np.linspace(0, 22, width, dtype=np.uint8)
        frame[:, :, 1] = np.clip(frame[:, :, 1] + gradient, 0, 255)

        line_x = int(width * (0.5 + 0.3 * math.sin(phase * 0.55)))
        if cv2 is not None:
            if detection.line:
                cv2.line(frame, (line_x, height), (line_x - 90, 0), (10, 10, 10), 38)
            if detection.green:
                cv2.rectangle(frame, (line_x - 70, height - 120), (line_x + 10, height - 40), (50, 205, 95), 2)
            if detection.red:
                cv2.rectangle(frame, (int(width * 0.6), 28), (width - 15, 88), (60, 25, 220), 3)
            if detection.balls > 0:
                cv2.circle(frame, (int(width * 0.75), int(height * 0.65)), 18, (180, 180, 180), 3)
            if detection.victims > 0:
                cv2.circle(frame, (int(width * 0.8), int(height * 0.55)), 15, (20, 20, 20), 3)
            cv2.putText(
                frame,
                state,
                (16, height - 16),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (210, 220, 230),
                2,
                cv2.LINE_AA,
            )
            if processed:
                cv2.putText(
                    frame,
                    "mock processed",
                    (16, 30),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (80, 220, 140),
                    2,
                    cv2.LINE_AA,
                )
        return frame


class DashboardWindow(QMainWindow):
    camera_set_config_signal = pyqtSignal(int, int, int, int)
    camera_reconnect_signal = pyqtSignal()
    camera_start_signal = pyqtSignal()
    camera_stop_signal = pyqtSignal()

    def __init__(
        self,
        event_bus: EventBus | None = None,
        *,
        camera_index: int = 0,
        camera_width: int = 640,
        camera_height: int = 480,
        camera_fps: int = 30,
        start_mock: bool = False,
    ) -> None:
        super().__init__()
        self._event_bus = event_bus
        self._subscriptions: list[Any] = []
        self._bridge = UiBridge()
        self._frame_lock = threading.Lock()
        self._latest_raw_frame: np.ndarray | None = None
        self._latest_processed_frame: np.ndarray | None = None
        self._raw_generation = 0
        self._processed_generation = 0
        self._rendered_raw_generation = -1
        self._rendered_processed_generation = -1
        self._latest_bus_frame_ts = 0.0

        self._cpu_percent: float | None = None
        self._queue_depth: int | None = None
        self._ips: float | None = None
        self._fps_ui = 0.0
        self._last_ui_tick = time.monotonic()

        self._state = "SEARCHING_LINE"
        self._state_started_ts = time.monotonic()
        self._app_started_ts = time.monotonic()
        self._status_flags = dict(STATUS_TEMPLATE)
        self._mock_enabled = False
        self._corner_window = 5
        self._corner_on_votes = 3
        self._corner_off_votes = 1
        self._green_corner_votes: deque[int] = deque(maxlen=self._corner_window)
        self._red_corner_votes: deque[int] = deque(maxlen=self._corner_window)
        self._green_corner_conf: deque[float] = deque(maxlen=self._corner_window)
        self._red_corner_conf: deque[float] = deque(maxlen=self._corner_window)
        self._green_corner_on = False
        self._red_corner_on = False
        self._steering_current_deg = 0.0
        self._steering_target_deg = 0.0

        self.setWindowTitle("FusionZero Overengineering Dashboard")
        self.setMinimumSize(1360, 820)
        self._build_ui()
        self.setStyleSheet(build_dashboard_stylesheet())
        self._wire_signals()
        self._setup_camera_worker(camera_index, camera_width, camera_height, camera_fps)
        self._setup_mock_source()
        self._subscribe_event_bus()

        self._render_timer = QTimer(self)
        self._render_timer.timeout.connect(self._render_tick)
        self._render_timer.start(33)

        self._append_transition_log("dashboard boot complete")
        if start_mock:
            self._set_mock_mode(True)
        else:
            self._set_mock_mode(False)
            if event_bus is None:
                self.camera_start_signal.emit()

    def _build_ui(self) -> None:
        root = QWidget(self)
        root.setObjectName("DashboardRoot")
        self.setCentralWidget(root)
        root_layout = QHBoxLayout(root)
        root_layout.setContentsMargins(14, 12, 14, 12)
        root_layout.setSpacing(10)

        splitter = QSplitter(Qt.Orientation.Horizontal, root)
        splitter.setChildrenCollapsible(False)
        root_layout.addWidget(splitter, 1)

        dashboard_host = QWidget(splitter)
        dashboard_layout = QVBoxLayout(dashboard_host)
        dashboard_layout.setContentsMargins(0, 0, 0, 0)
        dashboard_layout.setSpacing(10)

        self.top_bar = TopMetricsBar(dashboard_host)
        dashboard_layout.addWidget(self.top_bar)

        frame_row = QHBoxLayout()
        frame_row.setContentsMargins(0, 0, 0, 0)
        frame_row.setSpacing(10)
        self.raw_view = VideoView("Raw View", dashboard_host)
        self.steering_panel = SteeringPanel(dashboard_host)
        self.processed_view = VideoView("Processed View", dashboard_host)
        frame_row.addWidget(self.raw_view, 1)
        frame_row.addWidget(self.steering_panel, 0)
        frame_row.addWidget(self.processed_view, 1)
        dashboard_layout.addLayout(frame_row, 3)

        mid_row = QHBoxLayout()
        mid_row.setContentsMargins(0, 0, 0, 0)
        mid_row.setSpacing(10)
        self.telemetry_panel = TelemetryPanel(dashboard_host)
        self.robot_panel = RobotPlaceholderPanel(dashboard_host)
        self.status_panel = StatusPanel(dashboard_host)
        mid_row.addWidget(self.telemetry_panel, 2)
        mid_row.addWidget(self.robot_panel, 2)
        mid_row.addWidget(self.status_panel, 3)
        dashboard_layout.addLayout(mid_row, 2)

        bottom_row = QHBoxLayout()
        bottom_row.setContentsMargins(0, 0, 0, 0)
        bottom_row.setSpacing(10)
        self.timer_panel = TimerPanel(dashboard_host)
        self.log_panel = TransitionLogPanel(dashboard_host)
        bottom_row.addWidget(self.timer_panel, 2)
        bottom_row.addWidget(self.log_panel, 5)
        dashboard_layout.addLayout(bottom_row, 2)

        self.tuning_panel = TuningPanel(splitter)
        self.tuning_panel.setMinimumWidth(320)
        self.tuning_panel.setMaximumWidth(400)

        splitter.addWidget(dashboard_host)
        splitter.addWidget(self.tuning_panel)
        splitter.setStretchFactor(0, 6)
        splitter.setStretchFactor(1, 2)

    def _wire_signals(self) -> None:
        self._bridge.raw_frame_event.connect(self._on_raw_frame_event)
        self._bridge.processed_frame_event.connect(self._on_processed_frame_event)
        self._bridge.detection_event.connect(self._on_detection_event)
        self._bridge.state_event.connect(self._on_state_event)
        self._bridge.transition_event.connect(self._on_transition_event)
        self._bridge.health_event.connect(self._on_health_event)
        self._bridge.log_event.connect(self._on_log_event)
        self._bridge.path_event.connect(self._on_path_event)
        self._bridge.camera_frame.connect(self._on_camera_frame)
        self._bridge.camera_status.connect(self._on_camera_status)

        self.tuning_panel.parameter_changed.connect(self._on_parameter_changed)
        self.tuning_panel.camera_reconnect_requested.connect(self._on_camera_reconnect_requested)
        self.tuning_panel.mock_mode_changed.connect(self._set_mock_mode)
        self.tuning_panel.mode_switch_requested.connect(self._on_mode_switch_requested)

    def _setup_camera_worker(self, index: int, width: int, height: int, fps: int) -> None:
        self._camera_thread = QThread(self)
        self._camera_worker = CameraCaptureWorker(index=index, width=width, height=height, fps=fps)
        self._camera_worker.moveToThread(self._camera_thread)
        self._camera_worker.frame_ready.connect(self._bridge.camera_frame)
        self._camera_worker.status.connect(self._bridge.camera_status)

        self.camera_set_config_signal.connect(self._camera_worker.set_config)
        self.camera_reconnect_signal.connect(self._camera_worker.reconnect)
        self.camera_start_signal.connect(self._camera_worker.start)
        self.camera_stop_signal.connect(self._camera_worker.stop)
        self._camera_thread.start()

    def _setup_mock_source(self) -> None:
        self._mock_source = MockSource()
        self._mock_source.raw_frame.connect(self._store_raw_frame)
        self._mock_source.processed_frame.connect(self._store_processed_frame)
        self._mock_source.detection_event.connect(self._on_detection_event)
        self._mock_source.state_event.connect(self._on_state_event)
        self._mock_source.transition_event.connect(self._on_transition_event)
        self._mock_source.health_event.connect(self._on_health_event)
        self._mock_source.log_event.connect(self._on_log_event)

    def _subscribe_event_bus(self) -> None:
        if self._event_bus is None:
            return
        self._subscriptions.append(
            self._event_bus.subscribe(EventTopic.VISION_RAW_FRAME, lambda event: self._bridge.raw_frame_event.emit(event))
        )
        self._subscriptions.append(
            self._event_bus.subscribe(
                EventTopic.VISION_PROCESSED_FRAME,
                lambda event: self._bridge.processed_frame_event.emit(event),
            )
        )
        self._subscriptions.append(
            self._event_bus.subscribe(EventTopic.VISION_DETECTIONS, lambda event: self._bridge.detection_event.emit(event))
        )
        self._subscriptions.append(
            self._event_bus.subscribe(EventTopic.FSM_STATE, lambda event: self._bridge.state_event.emit(event))
        )
        self._subscriptions.append(
            self._event_bus.subscribe(
                EventTopic.FSM_TRANSITION,
                lambda event: self._bridge.transition_event.emit(event),
            )
        )
        self._subscriptions.append(
            self._event_bus.subscribe(EventTopic.SYSTEM_HEALTH, lambda event: self._bridge.health_event.emit(event))
        )
        self._subscriptions.append(
            self._event_bus.subscribe(EventTopic.SYSTEM_LOG, lambda event: self._bridge.log_event.emit(event))
        )
        self._subscriptions.append(
            self._event_bus.subscribe(EventTopic.NAV_PATH, lambda event: self._bridge.path_event.emit(event))
        )
        self._append_transition_log("event bus subscribers attached")

    def _set_mock_mode(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if enabled == self._mock_enabled:
            return
        self._mock_enabled = enabled
        self.tuning_panel.set_mock_mode(enabled)

        if enabled:
            self.camera_stop_signal.emit()
            self._mock_source.start()
            self._append_transition_log("mock mode enabled")
        else:
            self._mock_source.stop()
            if self._event_bus is None:
                self.camera_start_signal.emit()
            self._append_transition_log("mock mode disabled")

    def _on_parameter_changed(self, key: str, value: object) -> None:
        payload = {"key": key, "value": value}
        self._publish_ui_command("tuning.update", payload)

    def _on_camera_reconnect_requested(self, config: Mapping[str, Any]) -> None:
        index = int(config.get("index", 0))
        width = int(config.get("width", 640))
        height = int(config.get("height", 480))
        fps = int(config.get("fps", 30))

        if self._event_bus is None:
            self.camera_set_config_signal.emit(index, width, height, fps)
            self.camera_reconnect_signal.emit()
            if not self._mock_enabled:
                self.camera_start_signal.emit()

        self._append_transition_log(f"camera reconnect requested idx={index} {width}x{height}@{fps}")
        self._publish_ui_command(
            "camera.reconnect",
            {"index": index, "width": width, "height": height, "fps": fps},
        )

    def _on_mode_switch_requested(self, mode: str) -> None:
        normalized = str(mode or "").strip().lower()
        if normalized not in {"line", "rescue"}:
            return
        self._append_transition_log(f"mode switch requested: {normalized}")
        self._publish_ui_command("fsm.force_mode", {"mode": normalized})

    def _publish_ui_command(self, command: str, params: Mapping[str, Any]) -> None:
        if self._event_bus is None:
            return
        try:
            self._event_bus.publish(
                EventTopic.UI_COMMAND,
                UICommandEvent(timestamp=time.time(), command=command, params=dict(params)),
            )
        except Exception as exc:
            self._append_transition_log(f"ui.command publish failed: {exc}")

    def _on_raw_frame_event(self, event: object) -> None:
        if not isinstance(event, FrameEvent):
            return
        frame = _frame_from_event(event)
        if frame is None:
            return
        self._latest_bus_frame_ts = time.monotonic()
        self._store_raw_frame(frame)

    def _on_processed_frame_event(self, event: object) -> None:
        if not isinstance(event, FrameEvent):
            return
        frame = _frame_from_event(event)
        if frame is None:
            return
        self._store_processed_frame(frame)

    def _on_camera_frame(self, frame: object) -> None:
        if self._mock_enabled:
            return
        if not isinstance(frame, np.ndarray):
            return
        live_bus = (time.monotonic() - self._latest_bus_frame_ts) < 1.0
        if live_bus:
            return
        self._store_raw_frame(frame)
        with self._frame_lock:
            has_processed = self._latest_processed_frame is not None
        if not has_processed:
            self._store_processed_frame(self._build_processed_fallback(frame))

    def _on_camera_status(self, text: str) -> None:
        self._append_transition_log(text)
        self.raw_view.set_overlay(text if "connected" not in text else "")
        lowered = text.lower()
        if (
            self._event_bus is None
            and not self._mock_enabled
            and ("not available" in lowered or "unavailable" in lowered)
        ):
            self._append_transition_log("camera unavailable, enabling mock fallback")
            self._set_mock_mode(True)

    def _on_detection_event(self, event: object) -> None:
        if not isinstance(event, VisionDetectionEvent):
            return

        self._state = event.state or self._state
        self.status_panel.update_state(self._state)

        metadata = event.metadata if isinstance(event.metadata, Mapping) else {}
        self._update_corner_runtime_config(metadata)

        silver_line = (
            bool(metadata.get("silver_line", {}).get("found", False)) if isinstance(metadata.get("silver_line"), Mapping) else False
        )
        silver_ball = bool(metadata.get("silver_ball_found", False)) or bool(event.balls > 0)
        black_ball = bool(metadata.get("black_ball_found", False))
        if not black_ball and isinstance(metadata.get("dead_victim"), Mapping):
            black_ball = bool(metadata.get("dead_victim", {}).get("found", False))
        if event.victims > 0:
            black_ball = True

        raw_green_corner = bool(metadata.get("green_corner_found", False))
        raw_red_corner = bool(metadata.get("red_corner_found", False))
        green_corner_conf = _safe_float(metadata.get("green_corner_confidence"))
        red_corner_conf = _safe_float(metadata.get("red_corner_confidence"))
        self._green_corner_on = self._apply_corner_hysteresis(
            queue=self._green_corner_votes,
            conf_queue=self._green_corner_conf,
            detected=raw_green_corner,
            confidence=green_corner_conf if green_corner_conf is not None else 0.0,
            current=self._green_corner_on,
        )
        self._red_corner_on = self._apply_corner_hysteresis(
            queue=self._red_corner_votes,
            conf_queue=self._red_corner_conf,
            detected=raw_red_corner,
            confidence=red_corner_conf if red_corner_conf is not None else 0.0,
            current=self._red_corner_on,
        )

        self._status_flags = {
            "LINE": bool(event.line),
            "SILVER": silver_line,
            "GREEN": bool(event.green),
            "RED": bool(event.red),
            "GREEN CORNER": bool(self._green_corner_on),
            "RED CORNER": bool(self._red_corner_on),
            "SILVER BALL": bool(silver_ball),
            "BLACK BALL": black_ball,
        }
        self.status_panel.update_statuses(self._status_flags)

        if event.latency_ms > 0:
            self._ips = 1000.0 / float(event.latency_ms)

        telemetry = self._extract_telemetry(metadata)
        if telemetry:
            self.telemetry_panel.update_values(telemetry)

        status_text = metadata.get("status_text") if isinstance(metadata, Mapping) else None
        if isinstance(status_text, str) and status_text.strip():
            active_text = status_text.strip()
        else:
            active = [key for key, enabled in self._status_flags.items() if enabled]
            if not active:
                active_text = "No markers"
            else:
                active_text = " | ".join(active[:3]) + (" ..." if len(active) > 3 else "")
        corner_parts: list[str] = []
        gc_conf = self._corner_confidence(self._green_corner_conf)
        rc_conf = self._corner_confidence(self._red_corner_conf)
        if self._green_corner_on or gc_conf > 0.01:
            corner_parts.append(f"GC {int(round(gc_conf * 100.0)):02d}%")
        if self._red_corner_on or rc_conf > 0.01:
            corner_parts.append(f"RC {int(round(rc_conf * 100.0)):02d}%")
        if corner_parts:
            active_text = f"{active_text} | {' | '.join(corner_parts)}"
        self.processed_view.set_overlay(active_text)
        self.processed_view.set_corner(f"{event.latency_ms:.1f} ms")
        self._update_steering_from_detection(event, metadata)
        self.robot_panel.set_step(int(time.monotonic() * 1.5))

    def _on_state_event(self, event: object) -> None:
        if not isinstance(event, StateSnapshotEvent):
            return
        next_state = event.state.strip().upper() if event.state else self._state
        if next_state != self._state:
            self._state_started_ts = time.monotonic()
        self._state = next_state
        self.status_panel.update_state(self._state)

    def _on_transition_event(self, event: object) -> None:
        if not isinstance(event, StateTransitionEvent):
            return
        self._state = event.new_state or self._state
        self._state_started_ts = time.monotonic()
        line = (
            f"{_iso_timestamp(event.timestamp)} [{event.new_state}] "
            f"{event.old_state} --{event.trigger}--> {event.new_state} | {event.reason}"
        )
        self._append_transition_log(line)
        self.status_panel.update_state(self._state)

    def _on_health_event(self, event: object) -> None:
        if not isinstance(event, HealthEvent):
            return
        self._cpu_percent = float(event.cpu_percent)
        self._queue_depth = int(event.queue_depth)
        if event.fps_ui > 0:
            self._fps_ui = float(event.fps_ui)
        elif event.fps_process > 0:
            self._fps_ui = float(event.fps_process)

    def _on_log_event(self, event: object) -> None:
        if not isinstance(event, LogEvent):
            return
        state = event.state.strip().upper() if event.state else self._state
        line = f"{_iso_timestamp(event.timestamp)} [{state}] {event.source}: {event.message}"
        self._append_transition_log(line)

    def _on_path_event(self, event: object) -> None:
        if not isinstance(event, PathEvent):
            return
        poses = event.poses if isinstance(event.poses, list) else []
        if not poses:
            return
        last_pose = poses[-1]
        yaw = _safe_float(getattr(last_pose, "theta", None))
        if yaw is not None:
            self.telemetry_panel.update_values({"yaw": math.degrees(yaw)})
        self.robot_panel.set_step(len(poses) % 3)

    def _store_raw_frame(self, frame: object) -> None:
        if not isinstance(frame, np.ndarray):
            return
        with self._frame_lock:
            self._latest_raw_frame = np.ascontiguousarray(frame)
            self._raw_generation += 1

    def _store_processed_frame(self, frame: object) -> None:
        if not isinstance(frame, np.ndarray):
            return
        with self._frame_lock:
            self._latest_processed_frame = np.ascontiguousarray(frame)
            self._processed_generation += 1

    def _extract_telemetry(self, metadata: Mapping[str, Any]) -> dict[str, Any]:
        keys = ("front", "left", "right", "back", "yaw", "roll", "pitch", "gripper")
        out: dict[str, Any] = {}
        for candidate_key in ("telemetry", "sensors", "distances"):
            candidate = metadata.get(candidate_key)
            if not isinstance(candidate, Mapping):
                continue
            for key in keys:
                if key in candidate:
                    out[key] = candidate[key]
        return out

    def _update_corner_runtime_config(self, metadata: Mapping[str, Any]) -> None:
        runtime = metadata.get("runtime")
        if not isinstance(runtime, Mapping):
            return
        window = int(runtime.get("corner_stability_window", self._corner_window))
        on_votes = int(runtime.get("corner_on_votes", self._corner_on_votes))
        off_votes = int(runtime.get("corner_off_votes", self._corner_off_votes))

        window = max(3, min(15, window))
        on_votes = max(1, min(window, on_votes))
        off_votes = max(0, min(on_votes, off_votes))

        if window == self._corner_window and on_votes == self._corner_on_votes and off_votes == self._corner_off_votes:
            return
        self._corner_window = window
        self._corner_on_votes = on_votes
        self._corner_off_votes = off_votes
        self._green_corner_votes = deque(self._green_corner_votes, maxlen=window)
        self._red_corner_votes = deque(self._red_corner_votes, maxlen=window)
        self._green_corner_conf = deque(self._green_corner_conf, maxlen=window)
        self._red_corner_conf = deque(self._red_corner_conf, maxlen=window)

    def _apply_corner_hysteresis(
        self,
        *,
        queue: deque[int],
        conf_queue: deque[float],
        detected: bool,
        confidence: float,
        current: bool,
    ) -> bool:
        queue.append(1 if detected else 0)
        conf_queue.append(max(0.0, min(1.0, float(confidence))))
        votes = int(sum(queue))
        if not current:
            return votes >= self._corner_on_votes
        return votes > self._corner_off_votes

    @staticmethod
    def _corner_confidence(conf_queue: deque[float]) -> float:
        if not conf_queue:
            return 0.0
        return float(sum(conf_queue) / len(conf_queue))

    def _build_processed_fallback(self, frame: np.ndarray) -> np.ndarray:
        if frame is None or frame.size == 0:
            return frame
        if cv2 is None:
            return np.ascontiguousarray(np.clip(frame * 0.85 + 10, 0, 255).astype(np.uint8))

        output = frame.copy()
        cv2.rectangle(output, (10, 10), (output.shape[1] - 10, output.shape[0] - 10), (120, 130, 140), 1)
        cv2.putText(
            output,
            "processed fallback",
            (14, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (80, 220, 120),
            2,
            cv2.LINE_AA,
        )
        return output

    def _append_transition_log(self, text: str) -> None:
        if not text:
            return
        self.log_panel.append_line(text)

    def _render_tick(self) -> None:
        now_mono = time.monotonic()
        dt = now_mono - self._last_ui_tick
        self._last_ui_tick = now_mono
        if dt > 0:
            instant = 1.0 / dt
            if self._fps_ui <= 0:
                self._fps_ui = instant
            else:
                self._fps_ui = 0.9 * self._fps_ui + 0.1 * instant

        with self._frame_lock:
            raw_gen = self._raw_generation
            processed_gen = self._processed_generation
            raw = self._latest_raw_frame
            processed = self._latest_processed_frame

        raw_changed = raw_gen != self._rendered_raw_generation
        if raw_gen != self._rendered_raw_generation:
            self._rendered_raw_generation = raw_gen
            self.raw_view.set_frame(raw, fallback_text="No camera signal")
            if isinstance(raw, np.ndarray):
                self.raw_view.set_corner(f"{raw.shape[1]}x{raw.shape[0]}")

        has_live_processed = processed is not None
        processed_changed = processed_gen != self._rendered_processed_generation
        if processed is None and isinstance(raw, np.ndarray):
            processed = self._build_processed_fallback(raw)
            processed_changed = raw_changed or self._rendered_processed_generation < 0
        if processed_changed:
            self._rendered_processed_generation = processed_gen if has_live_processed else raw_gen
            self.processed_view.set_frame(processed, fallback_text="No processed stream")

        self.timer_panel.set_elapsed(
            now_mono - self._app_started_ts,
            now_mono - self._state_started_ts,
        )
        self.top_bar.update_metrics(self._cpu_percent, self._fps_ui, self._ips, self._queue_depth)

    def _update_steering_from_detection(self, event: VisionDetectionEvent, metadata: Mapping[str, Any]) -> None:
        state = (event.state or self._state or "SEARCHING_LINE").strip().upper()
        green_side = str(metadata.get("green_side", "NONE")).strip().upper()
        green_instruction = str(metadata.get("green_instruction", "")).strip().upper()
        line_angle = _safe_float(metadata.get("line_angle_deg"))
        if line_angle is None or (not event.line and state == "SEARCHING_LINE"):
            current_turn = 0.0
        else:
            current_turn = max(-180.0, min(180.0, float(line_angle) - 90.0))
        target_turn = 0.0
        mode = "n"
        arrow = "^"

        if ("MEIA VOLTA" in green_instruction) or green_side == "BOTH":
            mode = "u"
            arrow = "UT"
            target_turn = 180.0
        elif green_side == "LEFT":
            mode = "g"
            arrow = "<"
            target_turn = 90.0
        elif green_side == "RIGHT":
            mode = "g"
            arrow = ">"
            target_turn = 90.0
        elif state == "FOLLOWING_LINE" and event.line:
            mode = "n"
            arrow = "^"
            target_turn = 0.0
        elif state == "SEARCHING_LINE":
            mode = "n"
            arrow = "~"
            target_turn = 0.0
            current_turn = 0.0
        else:
            if current_turn > 8.0:
                arrow = "<"
                target_turn = abs(current_turn)
            elif current_turn < -8.0:
                arrow = ">"
                target_turn = abs(current_turn)
            else:
                arrow = "^"
                target_turn = 0.0

        self._steering_current_deg = current_turn
        self._steering_target_deg = target_turn
        self.steering_panel.update_command(
            mode=mode,
            current_angle_deg=current_turn,
            target_angle_deg=target_turn,
            arrow_symbol=arrow,
        )

    def closeEvent(self, event) -> None:  # noqa: ANN001
        self._render_timer.stop()
        self._mock_source.stop()
        self.camera_stop_signal.emit()
        try:
            self._camera_thread.quit()
            self._camera_thread.wait(1200)
        except Exception:
            pass
        for sub in self._subscriptions:
            try:
                sub.unsubscribe()
            except Exception:
                pass
        super().closeEvent(event)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="FusionZero PyQt6 dashboard")
    parser.add_argument("--camera-index", type=int, default=0, help="Camera index (for example 0 or 1)")
    parser.add_argument("--camera-width", type=int, default=640, help="Capture width")
    parser.add_argument("--camera-height", type=int, default=480, help="Capture height")
    parser.add_argument("--camera-fps", type=int, default=30, help="Capture fps")
    parser.add_argument("--mock", action="store_true", help="Start in mock mode")
    return parser


def run_dashboard(
    *,
    event_bus: EventBus | None = None,
    camera_index: int = 0,
    camera_width: int = 640,
    camera_height: int = 480,
    camera_fps: int = 30,
    mock: bool = False,
) -> int:
    app = QApplication.instance()
    owns_app = app is None
    if app is None:
        app = QApplication(sys.argv)
    window = DashboardWindow(
        event_bus=event_bus,
        camera_index=camera_index,
        camera_width=camera_width,
        camera_height=camera_height,
        camera_fps=camera_fps,
        start_mock=mock,
    )
    window.show()
    if owns_app:
        return app.exec()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    return run_dashboard(
        camera_index=args.camera_index,
        camera_width=args.camera_width,
        camera_height=args.camera_height,
        camera_fps=args.camera_fps,
        mock=args.mock,
    )


if __name__ == "__main__":
    raise SystemExit(main())
