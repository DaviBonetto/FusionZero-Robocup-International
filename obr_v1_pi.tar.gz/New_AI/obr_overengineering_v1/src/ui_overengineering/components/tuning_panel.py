from __future__ import annotations

from typing import Any

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import (
    QCheckBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from .base import CardFrame


class TuningPanel(CardFrame):
    parameter_changed = pyqtSignal(str, object)
    camera_reconnect_requested = pyqtSignal(dict)
    mock_mode_changed = pyqtSignal(bool)
    mode_switch_requested = pyqtSignal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__("Tuning", parent)
        self._controls: dict[str, QSpinBox | QDoubleSpinBox] = {}
        self._defaults: dict[str, float | int] = {}

        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        panel = QWidget(scroll)
        root = QVBoxLayout(panel)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(8)

        root.addWidget(self._build_camera_group(panel))
        root.addWidget(self._build_line_group(panel))
        root.addWidget(self._build_color_group(panel))
        root.addWidget(self._build_ball_group(panel))
        root.addWidget(self._build_actions_group(panel))
        root.addStretch(1)

        scroll.setWidget(panel)
        self.content_layout.addWidget(scroll, 1)

    def _build_camera_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Camera", parent)
        layout = QVBoxLayout(group)
        form = QFormLayout()
        form.setContentsMargins(8, 8, 8, 8)
        form.setSpacing(6)

        self._add_spin(form, "camera.index", "Index", 0, 8, 0)
        self._add_spin(form, "camera.width", "Width", 160, 1920, 640, step=16)
        self._add_spin(form, "camera.height", "Height", 120, 1080, 480, step=16)
        self._add_spin(form, "camera.fps", "FPS", 1, 120, 30)
        layout.addLayout(form)

        self.mock_checkbox = QCheckBox("Mock mode", group)
        self.mock_checkbox.setChecked(False)
        self.mock_checkbox.toggled.connect(self.mock_mode_changed.emit)
        layout.addWidget(self.mock_checkbox)

        reconnect = QPushButton("Reconnect camera", group)
        reconnect.clicked.connect(self._emit_camera_reconnect)
        layout.addWidget(reconnect)
        return group

    def _build_line_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Line Detector", parent)
        form = QFormLayout(group)
        form.setContentsMargins(8, 8, 8, 8)
        form.setSpacing(6)
        self._add_spin(form, "line.black_v_max", "Black V max", 0, 255, 70)
        self._add_spin(form, "line.black_s_max", "Black S max", 0, 255, 255)
        self._add_spin(form, "line.min_area", "Min area", 1, 4000, 50)
        self._add_spin(form, "line.erode_iter", "Erode iter", 0, 8, 3)
        self._add_spin(form, "line.dilate_iter", "Dilate iter", 0, 8, 4)
        return group

    def _build_color_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Markers", parent)
        form = QFormLayout(group)
        form.setContentsMargins(8, 8, 8, 8)
        form.setSpacing(6)
        self._add_spin(form, "green.h_min", "Green H min", 0, 179, 35)
        self._add_spin(form, "green.h_max", "Green H max", 0, 179, 90)
        self._add_spin(form, "green.min_area", "Green area", 1, 6000, 180)

        self._add_spin(form, "red.h1_min", "Red H1 min", 0, 179, 0)
        self._add_spin(form, "red.h1_max", "Red H1 max", 0, 179, 12)
        self._add_spin(form, "red.h2_min", "Red H2 min", 0, 179, 165)
        self._add_spin(form, "red.h2_max", "Red H2 max", 0, 179, 179)
        self._add_spin(form, "red.min_area", "Red area", 1, 6000, 300)
        return group

    def _build_ball_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Balls / Victims", parent)
        form = QFormLayout(group)
        form.setContentsMargins(8, 8, 8, 8)
        form.setSpacing(6)
        self._add_double(form, "silver.conf", "Silver conf", 0.0, 1.0, 0.95, 0.01)
        self._add_spin(form, "silver.blur", "Silver blur", 3, 31, 7, step=2)
        self._add_spin(form, "dead.black_v_max", "Black V max", 0, 120, 60)
        return group

    def _build_actions_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Actions", parent)
        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        mode_row = QHBoxLayout()
        mode_row.setContentsMargins(0, 0, 0, 0)
        mode_row.setSpacing(6)
        force_line = QPushButton("Force LINE", group)
        force_line.clicked.connect(lambda: self.mode_switch_requested.emit("line"))
        mode_row.addWidget(force_line)

        force_rescue = QPushButton("Force RESCUE", group)
        force_rescue.clicked.connect(lambda: self.mode_switch_requested.emit("rescue"))
        mode_row.addWidget(force_rescue)
        layout.addLayout(mode_row)

        reset = QPushButton("Reset defaults", group)
        reset.clicked.connect(self.reset_defaults)
        layout.addWidget(reset)
        return group

    def _add_spin(
        self,
        form: QFormLayout,
        key: str,
        label: str,
        minimum: int,
        maximum: int,
        value: int,
        step: int = 1,
    ) -> None:
        spin = QSpinBox(form.parentWidget())
        spin.setMinimum(minimum)
        spin.setMaximum(maximum)
        spin.setSingleStep(step)
        spin.setValue(value)
        spin.valueChanged.connect(lambda v, item=key: self.parameter_changed.emit(item, int(v)))
        form.addRow(label, spin)
        self._controls[key] = spin
        self._defaults[key] = int(value)

    def _add_double(
        self,
        form: QFormLayout,
        key: str,
        label: str,
        minimum: float,
        maximum: float,
        value: float,
        step: float,
    ) -> None:
        spin = QDoubleSpinBox(form.parentWidget())
        spin.setMinimum(minimum)
        spin.setMaximum(maximum)
        spin.setSingleStep(step)
        spin.setValue(value)
        spin.setDecimals(3 if step < 0.01 else 2)
        spin.valueChanged.connect(lambda v, item=key: self.parameter_changed.emit(item, float(v)))
        form.addRow(label, spin)
        self._controls[key] = spin
        self._defaults[key] = float(value)

    def _emit_camera_reconnect(self) -> None:
        self.camera_reconnect_requested.emit(
            {
                "index": int(self.value("camera.index", 0)),
                "width": int(self.value("camera.width", 640)),
                "height": int(self.value("camera.height", 480)),
                "fps": int(self.value("camera.fps", 30)),
            }
        )

    def reset_defaults(self) -> None:
        for key, default in self._defaults.items():
            control = self._controls[key]
            control.blockSignals(True)
            if isinstance(control, QDoubleSpinBox):
                control.setValue(float(default))
            else:
                control.setValue(int(default))
            control.blockSignals(False)
            self.parameter_changed.emit(key, self.value(key, default))

    def set_mock_mode(self, enabled: bool) -> None:
        self.mock_checkbox.blockSignals(True)
        self.mock_checkbox.setChecked(bool(enabled))
        self.mock_checkbox.blockSignals(False)

    def value(self, key: str, fallback: Any = None) -> Any:
        control = self._controls.get(key)
        if control is None:
            return fallback
        if isinstance(control, QDoubleSpinBox):
            return float(control.value())
        return int(control.value())
