from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QHBoxLayout, QWidget

from .base import MetricPill


class TopMetricsBar(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        self._metrics: dict[str, MetricPill] = {}
        for key in ("CPU", "FPS", "IPS", "QUEUE"):
            pill = MetricPill(key, "--", self)
            pill.setMinimumWidth(130)
            layout.addWidget(pill)
            self._metrics[key] = pill
        layout.addStretch(1)

    def set_metric(self, key: str, value: str) -> None:
        item = self._metrics.get(key.upper())
        if item is not None:
            item.set_value(value)

    def update_metrics(self, cpu: float | None, fps_ui: float | None, ips: float | None, queue_depth: int | None) -> None:
        self.set_metric("CPU", f"{cpu:.1f}%" if cpu is not None else "--")
        self.set_metric("FPS", f"{fps_ui:.1f}" if fps_ui is not None else "--")
        self.set_metric("IPS", f"{ips:.1f}" if ips is not None else "--")
        self.set_metric("QUEUE", str(queue_depth) if queue_depth is not None else "--")

