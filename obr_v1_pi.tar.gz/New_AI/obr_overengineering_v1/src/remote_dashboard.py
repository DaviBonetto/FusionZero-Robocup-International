from __future__ import annotations

import json
import socket
import threading
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable

import numpy as np

try:
    import cv2
except Exception:  # pragma: no cover
    cv2 = None

if __package__ in (None, ""):
    SRC_ROOT = Path(__file__).resolve().parent
    import sys

    if str(SRC_ROOT) not in sys.path:
        sys.path.insert(0, str(SRC_ROOT))

    from core.event_bus import (  # type: ignore
        EventBus,
        EventBusError,
        EventBusFullError,
        EventTopic,
        FrameEvent,
        HealthEvent,
        LogEvent,
        PathEvent,
        PoseEvent,
        StateSnapshotEvent,
        StateTransitionEvent,
        Subscription,
        UICommandEvent,
        VisionDetectionEvent,
    )
else:
    from .core.event_bus import (
        EventBus,
        EventBusError,
        EventBusFullError,
        EventTopic,
        FrameEvent,
        HealthEvent,
        LogEvent,
        PathEvent,
        PoseEvent,
        StateSnapshotEvent,
        StateTransitionEvent,
        Subscription,
        UICommandEvent,
        VisionDetectionEvent,
    )


EVENT_CLASS_BY_NAME: dict[str, type[Any]] = {
    "FrameEvent": FrameEvent,
    "HealthEvent": HealthEvent,
    "LogEvent": LogEvent,
    "PathEvent": PathEvent,
    "PoseEvent": PoseEvent,
    "StateSnapshotEvent": StateSnapshotEvent,
    "StateTransitionEvent": StateTransitionEvent,
    "UICommandEvent": UICommandEvent,
    "VisionDetectionEvent": VisionDetectionEvent,
}

FORWARDED_TOPICS: tuple[EventTopic, ...] = (
    EventTopic.VISION_RAW_FRAME,
    EventTopic.VISION_PROCESSED_FRAME,
    EventTopic.VISION_DETECTIONS,
    EventTopic.FSM_STATE,
    EventTopic.FSM_TRANSITION,
    EventTopic.SYSTEM_HEALTH,
    EventTopic.SYSTEM_LOG,
    EventTopic.NAV_PATH,
)


def _read_exact(sock: socket.socket, size: int) -> bytes:
    chunks: list[bytes] = []
    remaining = int(size)
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            raise ConnectionError("socket closed")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def _encode_frame_payload(event: FrameEvent, jpeg_quality: int) -> tuple[dict[str, Any], bytes]:
    encoding = str(event.encoding or "bgr8").strip().lower()
    payload = bytes(event.data)
    fields = {
        "timestamp": float(event.timestamp),
        "frame_id": int(event.frame_id),
        "width": int(event.width),
        "height": int(event.height),
        "encoding": encoding,
    }
    if encoding in {"jpeg", "jpg"}:
        fields["encoding"] = "jpeg"
        return fields, payload

    if cv2 is None or event.width <= 0 or event.height <= 0:
        return fields, payload

    raw = np.frombuffer(event.data, dtype=np.uint8)
    expected = int(event.width) * int(event.height) * 3
    if raw.size < expected:
        return fields, payload

    frame = raw[:expected].reshape((int(event.height), int(event.width), 3))
    if encoding.startswith("rgb"):
        frame = frame[:, :, ::-1]

    ok, encoded = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(jpeg_quality)])
    if not ok:
        return fields, payload

    fields["encoding"] = "jpeg"
    return fields, encoded.tobytes()


def pack_event_message(topic: str, event: object, *, jpeg_quality: int = 70) -> bytes:
    if isinstance(event, FrameEvent):
        fields, payload = _encode_frame_payload(event, jpeg_quality)
    else:
        fields = asdict(event)
        payload = b""

    header = {
        "topic": str(topic),
        "event_type": type(event).__name__,
        "payload_length": int(len(payload)),
        "fields": fields,
    }
    header_bytes = json.dumps(header, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    return len(header_bytes).to_bytes(4, byteorder="big", signed=False) + header_bytes + payload


def recv_event_message(sock: socket.socket) -> tuple[str, object]:
    header_len = int.from_bytes(_read_exact(sock, 4), byteorder="big", signed=False)
    if header_len <= 0:
        raise ConnectionError("invalid header length")
    header = json.loads(_read_exact(sock, header_len).decode("utf-8"))
    topic = str(header["topic"])
    event_type = str(header["event_type"])
    payload_length = int(header.get("payload_length", 0))
    fields = header.get("fields", {})
    if not isinstance(fields, dict):
        raise ValueError("invalid message fields")

    payload = _read_exact(sock, payload_length) if payload_length > 0 else b""
    event_cls = EVENT_CLASS_BY_NAME.get(event_type)
    if event_cls is None:
        raise ValueError(f"unsupported event type: {event_type}")

    if event_cls is FrameEvent:
        fields["data"] = payload
    elif event_cls is PathEvent:
        poses = fields.get("poses", [])
        if isinstance(poses, list):
            fields["poses"] = [PoseEvent(**pose) if isinstance(pose, dict) else pose for pose in poses]
    event = event_cls(**fields)
    return topic, event


class RemoteDashboardServer:
    def __init__(
        self,
        event_bus: EventBus,
        *,
        host: str = "0.0.0.0",
        port: int = 8765,
        stream_fps: float = 8.0,
        jpeg_quality: int = 70,
    ) -> None:
        self._event_bus = event_bus
        self._host = str(host)
        self._port = int(port)
        self._stream_fps = max(1.0, float(stream_fps))
        self._jpeg_quality = max(35, min(95, int(jpeg_quality)))
        self._subscriptions: list[Subscription] = []
        self._stop_event = threading.Event()
        self._server_socket: socket.socket | None = None
        self._client_socket: socket.socket | None = None
        self._accept_thread: threading.Thread | None = None
        self._recv_thread: threading.Thread | None = None
        self._client_lock = threading.RLock()
        self._send_lock = threading.RLock()
        self._last_frame_sent_at: dict[str, float] = {
            EventTopic.VISION_RAW_FRAME.value: 0.0,
            EventTopic.VISION_PROCESSED_FRAME.value: 0.0,
        }

    def start(self) -> None:
        if self._accept_thread is not None:
            return

        self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_socket.bind((self._host, self._port))
        self._server_socket.listen(1)
        self._server_socket.settimeout(1.0)

        for topic in FORWARDED_TOPICS:
            self._subscriptions.append(self._event_bus.subscribe(topic, self._build_forwarder(topic.value)))

        self._accept_thread = threading.Thread(target=self._accept_loop, name="remote-dashboard-accept", daemon=True)
        self._accept_thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        self._close_client()
        server = self._server_socket
        self._server_socket = None
        if server is not None:
            try:
                server.close()
            except Exception:
                pass
        if self._accept_thread is not None:
            self._accept_thread.join(timeout=2.0)
        if self._recv_thread is not None:
            self._recv_thread.join(timeout=2.0)
        self._accept_thread = None
        self._recv_thread = None
        for sub in self._subscriptions:
            try:
                sub.unsubscribe()
            except Exception:
                pass
        self._subscriptions.clear()

    def _accept_loop(self) -> None:
        while not self._stop_event.is_set():
            server = self._server_socket
            if server is None:
                return
            try:
                client, _ = server.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self._replace_client(client)

    def _replace_client(self, client: socket.socket) -> None:
        self._close_client()
        with self._client_lock:
            self._client_socket = client
        self._recv_thread = threading.Thread(
            target=self._recv_loop,
            args=(client,),
            name="remote-dashboard-recv",
            daemon=True,
        )
        self._recv_thread.start()

    def _close_client(self) -> None:
        with self._client_lock:
            client = self._client_socket
            self._client_socket = None
        if client is not None:
            try:
                client.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                client.close()
            except Exception:
                pass

    def _recv_loop(self, client: socket.socket) -> None:
        try:
            while not self._stop_event.is_set():
                topic, event = recv_event_message(client)
                if topic != EventTopic.UI_COMMAND.value or not isinstance(event, UICommandEvent):
                    continue
                try:
                    self._event_bus.publish(EventTopic.UI_COMMAND, event)
                except EventBusError:
                    continue
        except Exception:
            pass
        finally:
            with self._client_lock:
                if self._client_socket is client:
                    self._client_socket = None
            try:
                client.close()
            except Exception:
                pass

    def _build_forwarder(self, topic: str) -> Callable[[object], None]:
        def _forward(event: object) -> None:
            if self._stop_event.is_set():
                return
            if topic in self._last_frame_sent_at:
                now = time.monotonic()
                min_interval = 1.0 / self._stream_fps
                if (now - self._last_frame_sent_at[topic]) < min_interval:
                    return
                self._last_frame_sent_at[topic] = now
            self._send_event(topic, event)

        return _forward

    def _send_event(self, topic: str, event: object) -> None:
        with self._client_lock:
            client = self._client_socket
        if client is None:
            return

        try:
            packet = pack_event_message(topic, event, jpeg_quality=self._jpeg_quality)
            with self._send_lock:
                client.sendall(packet)
        except Exception:
            self._close_client()


class RemoteDashboardClient:
    def __init__(
        self,
        event_bus: EventBus,
        *,
        host: str,
        port: int = 8765,
        reconnect_interval: float = 2.0,
    ) -> None:
        self._event_bus = event_bus
        self._host = str(host)
        self._port = int(port)
        self._reconnect_interval = max(0.5, float(reconnect_interval))
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._socket: socket.socket | None = None
        self._socket_lock = threading.RLock()
        self._send_lock = threading.RLock()
        self._ui_subscription: Subscription | None = None

    def start(self) -> None:
        if self._thread is not None:
            return
        self._ui_subscription = self._event_bus.subscribe(EventTopic.UI_COMMAND, self._on_ui_command)
        self._thread = threading.Thread(target=self._run_loop, name="remote-dashboard-client", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._ui_subscription is not None:
            try:
                self._ui_subscription.unsubscribe()
            except Exception:
                pass
            self._ui_subscription = None
        self._close_socket()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        self._thread = None

    def _run_loop(self) -> None:
        while not self._stop_event.is_set():
            sock: socket.socket | None = None
            try:
                sock = socket.create_connection((self._host, self._port), timeout=5.0)
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                with self._socket_lock:
                    self._socket = sock
                self._publish_local_log("INFO", f"connected to raspberry {self._host}:{self._port}")
                while not self._stop_event.is_set():
                    topic, event = recv_event_message(sock)
                    self._publish_remote_event(topic, event)
            except Exception:
                if not self._stop_event.is_set():
                    self._publish_local_log("WARNING", f"remote dashboard disconnected from {self._host}:{self._port}")
                    time.sleep(self._reconnect_interval)
            finally:
                self._close_socket()

    def _publish_remote_event(self, topic: str, event: object) -> None:
        try:
            self._event_bus.publish(topic, event)
        except EventBusFullError:
            return
        except EventBusError:
            return

    def _publish_local_log(self, level: str, message: str) -> None:
        try:
            self._event_bus.publish(
                EventTopic.SYSTEM_LOG,
                LogEvent(timestamp=time.time(), level=level, message=message, source="remote_client", state=""),
            )
        except EventBusError:
            pass

    def _on_ui_command(self, event: UICommandEvent) -> None:
        if not isinstance(event, UICommandEvent):
            return
        with self._socket_lock:
            sock = self._socket
        if sock is None:
            return
        try:
            packet = pack_event_message(EventTopic.UI_COMMAND.value, event)
            with self._send_lock:
                sock.sendall(packet)
        except Exception:
            self._close_socket()

    def _close_socket(self) -> None:
        with self._socket_lock:
            sock = self._socket
            self._socket = None
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                sock.close()
            except Exception:
                pass
