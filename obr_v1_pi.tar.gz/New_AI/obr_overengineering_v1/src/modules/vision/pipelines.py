from __future__ import annotations

import importlib
import json
import contextlib
import io
import os
import sys
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import cv2
import numpy as np

try:
    from ...core.event_bus import VisionDetectionEvent
    from ...core.state_machine import RobotState
except ImportError:  # pragma: no cover
    from core.event_bus import VisionDetectionEvent
    from core.state_machine import RobotState

try:
    from .preprocessor import VisionPreprocessor
except ImportError:  # pragma: no cover
    from preprocessor import VisionPreprocessor


_FILE = Path(__file__).resolve()
_OBR_ROOT = _FILE.parents[3]
_REPO_ROOT = _FILE.parents[5]
DEFAULT_CONFIG_PATH = _OBR_ROOT / "configs" / "vision_config.json"


def _state_name(state: RobotState | str) -> str:
    if isinstance(state, RobotState):
        return state.value
    raw = str(state).strip().upper()
    return raw if raw in RobotState._value2member_map_ else RobotState.SEARCHING_LINE.value


def _clamp01(value: float) -> float:
    return float(max(0.0, min(1.0, value)))


def _safe_bbox(
    x: int | float,
    y: int | float,
    w: int | float,
    h: int | float,
    frame_shape: tuple[int, ...],
) -> dict[str, int] | None:
    frame_h = int(frame_shape[0]) if len(frame_shape) > 0 else 0
    frame_w = int(frame_shape[1]) if len(frame_shape) > 1 else 0
    if frame_w <= 0 or frame_h <= 0:
        return None

    x0 = max(0, min(frame_w - 1, int(round(x))))
    y0 = max(0, min(frame_h - 1, int(round(y))))
    ww = max(1, int(round(w)))
    hh = max(1, int(round(h)))
    if x0 + ww > frame_w:
        ww = frame_w - x0
    if y0 + hh > frame_h:
        hh = frame_h - y0
    if ww <= 0 or hh <= 0:
        return None
    return {"x": int(x0), "y": int(y0), "w": int(ww), "h": int(hh)}


def _bbox_from_circle(
    cx: int | float,
    cy: int | float,
    radius: int | float,
    frame_shape: tuple[int, ...],
) -> dict[str, int] | None:
    r = max(1, int(round(radius)))
    return _safe_bbox(int(round(cx)) - r, int(round(cy)) - r, r * 2, r * 2, frame_shape)


def _bbox_iou(a: Mapping[str, Any] | None, b: Mapping[str, Any] | None) -> float:
    if not isinstance(a, Mapping) or not isinstance(b, Mapping):
        return 0.0
    ax = int(a.get("x", -1))
    ay = int(a.get("y", -1))
    aw = int(a.get("w", -1))
    ah = int(a.get("h", -1))
    bx = int(b.get("x", -1))
    by = int(b.get("y", -1))
    bw = int(b.get("w", -1))
    bh = int(b.get("h", -1))
    if aw <= 0 or ah <= 0 or bw <= 0 or bh <= 0:
        return 0.0
    ax2 = ax + aw
    ay2 = ay + ah
    bx2 = bx + bw
    by2 = by + bh

    inter_x1 = max(ax, bx)
    inter_y1 = max(ay, by)
    inter_x2 = min(ax2, bx2)
    inter_y2 = min(ay2, by2)
    inter_w = max(0, inter_x2 - inter_x1)
    inter_h = max(0, inter_y2 - inter_y1)
    if inter_w <= 0 or inter_h <= 0:
        return 0.0
    inter = float(inter_w * inter_h)
    union = float(aw * ah + bw * bh) - inter
    if union <= 0:
        return 0.0
    return float(inter / union)


@dataclass(slots=True)
class VisionConfig:
    data: dict[str, Any]
    config_path: Path
    project_root: Path
    cache_key: str

    @property
    def preprocessor(self) -> Mapping[str, Any]:
        raw = self.data.get("preprocessor")
        return raw if isinstance(raw, Mapping) else {}

    def pipeline(self, state_name: str) -> Mapping[str, Any]:
        raw = self.data.get("pipelines", {})
        if not isinstance(raw, Mapping):
            return {}
        state_cfg = raw.get(state_name)
        if isinstance(state_cfg, Mapping):
            return state_cfg
        default_cfg = raw.get("default")
        return default_cfg if isinstance(default_cfg, Mapping) else {}

    def detector(self, detector_name: str) -> Mapping[str, Any]:
        raw = self.data.get("detectors", {})
        if not isinstance(raw, Mapping):
            return {}
        detector_cfg = raw.get(detector_name)
        return detector_cfg if isinstance(detector_cfg, Mapping) else {}

    def model_path(self, model_name: str) -> Path | None:
        raw = self.data.get("models", {})
        if not isinstance(raw, Mapping):
            return None
        candidate = raw.get(model_name)
        if not candidate:
            return None
        path = Path(str(candidate))
        return path if path.is_absolute() else (self.project_root / path).resolve()

    def benchmark(self) -> Mapping[str, Any]:
        raw = self.data.get("benchmark")
        return raw if isinstance(raw, Mapping) else {}


def load_vision_config(config_path: str | Path | None = None) -> VisionConfig:
    if config_path is None:
        resolved = DEFAULT_CONFIG_PATH.resolve()
    else:
        p = Path(config_path)
        resolved = p if p.is_absolute() else (_REPO_ROOT / p).resolve()

    with resolved.open("r", encoding="utf-8") as fp:
        data = json.load(fp)

    model_root = _REPO_ROOT
    paths_cfg = data.get("paths")
    if isinstance(paths_cfg, Mapping):
        model_root_raw = paths_cfg.get("model_root")
        if model_root_raw:
            model_root_candidate = Path(str(model_root_raw))
            model_root = (
                model_root_candidate
                if model_root_candidate.is_absolute()
                else (_REPO_ROOT / model_root_candidate).resolve()
            )

    cache_key = f"{resolved}:{resolved.stat().st_mtime_ns}"
    return VisionConfig(
        data=data,
        config_path=resolved,
        project_root=model_root,
        cache_key=cache_key,
    )


class LineDetector:
    def __init__(self, width: int, height: int, settings: Mapping[str, Any] | None = None) -> None:
        cfg = dict(settings or {})
        self.width = int(width)
        self.height = int(height)
        self.min_black_area = int(cfg.get("min_black_area", 50))
        self.prev_angle = 90
        self.gap_found = 0

        self.black_h_max = int(cfg.get("black_h_max", 180))
        self.black_s_max = int(cfg.get("black_s_max", 255))
        self.black_v_max = int(cfg.get("black_v_max", 70))
        self.erode_iter = int(cfg.get("erode_iter", 3))
        self.dilate_iter = int(cfg.get("dilate_iter", 4))
        self.erode_ksize = int(cfg.get("erode_ksize", 3))
        self.dilate_ksize = int(cfg.get("dilate_ksize", 3))
        self.line_border_margin = int(cfg.get("line_border_margin", 8))
        self.round_blob_circularity = float(cfg.get("round_blob_circularity", 0.72))
        self.round_blob_aspect = float(cfg.get("round_blob_aspect", 1.25))
        self.min_aspect_without_border = float(cfg.get("min_aspect_without_border", 1.35))
        self.min_area_ratio_for_internal = float(cfg.get("min_area_ratio_for_internal", 0.10))
        self.min_internal_long_side_ratio = float(cfg.get("min_internal_long_side_ratio", 0.45))
        self.compact_extent_reject = float(cfg.get("compact_extent_reject", 0.44))
        self.compact_solidity_reject = float(cfg.get("compact_solidity_reject", 0.70))
        self.compact_circularity_reject = float(cfg.get("compact_circularity_reject", 0.36))

    def black_mask(self, image: np.ndarray) -> tuple[np.ndarray | None, np.ndarray]:
        hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        black_mask = cv2.inRange(
            hsv_image,
            (0, 0, 0),
            (self.black_h_max, self.black_s_max, self.black_v_max),
        )

        if self.erode_iter > 0:
            kernel = cv2.getStructuringElement(
                cv2.MORPH_RECT,
                (max(1, self.erode_ksize), max(1, self.erode_ksize)),
            )
            black_mask = cv2.erode(black_mask, kernel, iterations=self.erode_iter)
        if self.dilate_iter > 0:
            kernel = cv2.getStructuringElement(
                cv2.MORPH_RECT,
                (max(1, self.dilate_ksize), max(1, self.dilate_ksize)),
            )
            black_mask = cv2.dilate(black_mask, kernel, iterations=self.dilate_iter)

        contours, _ = cv2.findContours(black_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2:]
        contours = [cnt for cnt in contours if cv2.contourArea(cnt) > self.min_black_area]
        contours = [cnt for cnt in contours if self._is_line_candidate(cnt)]
        if not contours:
            return None, black_mask
        if len(contours) == 1:
            return contours[0], black_mask

        diffs: list[float] = []
        for contour in contours:
            angle, _ = self.calculate_angle(contour, update_state=False)
            diffs.append(abs(float(angle) - float(self.prev_angle)))
        best = int(np.argmin(np.array(diffs, dtype=np.float32)))
        return contours[best], black_mask

    def _is_line_candidate(self, contour: np.ndarray) -> bool:
        if contour is None or len(contour) < 3:
            return False

        area = float(cv2.contourArea(contour))
        if area < float(self.min_black_area):
            return False

        x, y, w, h = cv2.boundingRect(contour)
        if w <= 0 or h <= 0:
            return False

        short = float(min(w, h))
        long = float(max(w, h))
        aspect = long / max(1.0, short)
        extent = area / float(w * h) if (w * h) > 0 else 0.0

        margin = max(2, int(self.line_border_margin))
        touches_border = (
            x <= margin
            or y <= margin
            or (x + w) >= (self.width - margin)
            or (y + h) >= (self.height - margin)
        )

        perimeter = float(cv2.arcLength(contour, True))
        circularity = 0.0
        if perimeter > 1e-6:
            circularity = float((4.0 * np.pi * area) / (perimeter * perimeter))
        hull = cv2.convexHull(contour)
        hull_area = float(cv2.contourArea(hull))
        solidity = area / hull_area if hull_area > 1e-6 else 0.0

        if (not touches_border) and circularity >= self.round_blob_circularity and aspect <= self.round_blob_aspect:
            return False

        if (not touches_border) and (
            extent >= self.compact_extent_reject
            and solidity >= self.compact_solidity_reject
            and circularity >= self.compact_circularity_reject
            and aspect <= max(self.round_blob_aspect, 1.45)
        ):
            return False

        if touches_border:
            return True

        frame_area = float(max(1, self.width * self.height))
        if (area / frame_area) < self.min_area_ratio_for_internal:
            return False
        min_long_side = float(min(self.width, self.height)) * max(0.05, self.min_internal_long_side_ratio)
        if long < min_long_side:
            return False
        return aspect >= self.min_aspect_without_border

    def calculate_angle(self, contour: np.ndarray | None, *, update_state: bool = True) -> tuple[int, int]:
        if contour is None:
            if update_state:
                self.gap_found += 1
            return self.prev_angle, self.gap_found

        points = contour.reshape(-1, 2)
        top_points = points[points[:, 1] <= 5]
        left_points = points[points[:, 0] <= 10]
        right_points = points[points[:, 0] >= self.width - 10]
        ref_point: tuple[int, int] | None = None

        if len(top_points) > 0:
            ref_point = (int(np.mean(top_points[:, 0])), 0)
        elif len(left_points) > 0 and len(right_points) > 0:
            if self.prev_angle <= 90:
                ref_point = (0, int(np.mean(left_points[:, 1])))
            else:
                ref_point = (self.width - 1, int(np.mean(right_points[:, 1])))
        else:
            top_idx = int(np.argmin(points[:, 1]))
            top = points[top_idx]
            ref_point = (int(top[0]), int(top[1]))

        if ref_point is None:
            if update_state:
                self.gap_found += 1
            return self.prev_angle, self.gap_found

        bottom = (self.width // 2, self.height)
        dx = bottom[0] - ref_point[0]
        dy = bottom[1] - ref_point[1]
        angle = int(np.degrees(np.arctan2(dy, dx)))
        if update_state:
            self.prev_angle = angle
            self.gap_found = 0
        return angle, self.gap_found


class BallDetector:
    def __init__(self, width: int, height: int, settings: Mapping[str, Any] | None = None) -> None:
        cfg = dict(settings or {})
        self.width = int(width)
        self.height = int(height)
        self.crop_size = int(cfg.get("crop_size", 200))
        self.silver_blur = int(cfg.get("silver_blur", 7))
        self.silver_hough_dp = float(cfg.get("silver_hough_dp", 1.2))
        self.silver_hough_min_distance = int(cfg.get("silver_hough_min_distance", 60))
        self.silver_hough_param1 = int(cfg.get("silver_hough_param1", 120))
        self.silver_hough_param2 = int(cfg.get("silver_hough_param2", 30))
        self.silver_hough_min_radius = int(cfg.get("silver_hough_min_radius", 8))
        self.silver_hough_max_radius = int(cfg.get("silver_hough_max_radius", 120))
        self.silver_specular_v_min = int(cfg.get("silver_specular_v_min", 175))
        self.silver_specular_s_max = int(cfg.get("silver_specular_s_max", 95))
        self.silver_specular_min_area = float(cfg.get("silver_specular_min_area", 120))
        self.silver_specular_max_area_ratio = float(cfg.get("silver_specular_max_area_ratio", 0.22))
        self.silver_specular_min_circularity = float(cfg.get("silver_specular_min_circularity", 0.55))
        self.silver_conf_threshold = float(cfg.get("silver_conf_threshold", 0.62))
        self.silver_candidate_threshold = float(
            cfg.get("silver_candidate_threshold", max(0.28, self.silver_conf_threshold * 0.72))
        )
        self.silver_max_candidates = max(1, int(cfg.get("silver_max_candidates", 3)))
        self.silver_candidate_min_center_dist = float(
            cfg.get("silver_candidate_min_center_dist", max(14.0, self.silver_hough_min_distance * 0.45))
        )
        self.silver_candidate_iou_nms = float(cfg.get("silver_candidate_iou_nms", 0.35))

        self.dead_white_kernel = np.ones((9, 9), np.uint8)
        self.dead_black_kernel = np.ones((25, 25), np.uint8)
        self.dead_white_threshold = tuple(cfg.get("dead_white_threshold", [160, 160, 160]))
        self.dead_black_threshold = tuple(cfg.get("dead_black_threshold", [60, 60, 60]))
        self.dead_min_black_area = int(cfg.get("dead_min_black_area", 300))
        self.dead_min_y = int(cfg.get("dead_min_y", 40))
        self.dead_radius_y_min = int(cfg.get("dead_radius_y_min", -50))
        self.dead_hough_dp = float(cfg.get("dead_hough_dp", 1))
        self.dead_hough_min_distance = int(cfg.get("dead_hough_min_distance", 200))
        self.dead_hough_param1 = int(cfg.get("dead_hough_param1", 50))
        self.dead_hough_param2 = int(cfg.get("dead_hough_param2", 30))
        self.dead_hough_min_radius = int(cfg.get("dead_hough_min_radius", 5))
        self.dead_hough_max_radius = int(cfg.get("dead_hough_max_radius", 150))
        self.black_conf_threshold = float(cfg.get("black_conf_threshold", 0.60))
        self.silver_black_overlap_px = int(cfg.get("silver_black_overlap_px", 24))

        self.last_live_circle: tuple[int, int, int] | None = None
        self.last_dead_circle: tuple[int, int, int] | None = None
        self.last_live_confidence = 0.0
        self.last_dead_confidence = 0.0
        self.last_live_bbox: dict[str, int] | None = None
        self.last_dead_bbox: dict[str, int] | None = None
        self.last_live_origin = "none"
        self.last_dead_origin = "none"

    def live(self, image: np.ndarray, last_x: int | None) -> int | None:
        out = self.live_detection(image, last_x)
        return int(out["x"]) if out["found"] else None

    def dead(self, image: np.ndarray, last_x: int | None) -> int | None:
        out = self.dead_detection(image, last_x)
        return int(out["x"]) if out["found"] else None

    def live_detection(self, image: np.ndarray, last_x: int | None) -> dict[str, Any]:
        candidates = self.live_detections(image, last_x)
        if not candidates:
            self._reset_live()
            return self._empty_result()
        return dict(candidates[0])

    def live_detections(self, image: np.ndarray, last_x: int | None) -> list[dict[str, Any]]:
        if image is None or image.size == 0:
            self._reset_live()
            return []

        if last_x is not None:
            x0 = max(0, int(last_x) - self.crop_size)
            x1 = min(image.shape[1], int(last_x) + self.crop_size)
            working = image[:, x0:x1]
        else:
            x0 = 0
            working = image

        gray = cv2.cvtColor(working, cv2.COLOR_BGR2GRAY)
        ksize = max(3, self.silver_blur + (1 - self.silver_blur % 2))
        gray = cv2.GaussianBlur(gray, (ksize, ksize), 0)
        circles = cv2.HoughCircles(
            gray,
            cv2.HOUGH_GRADIENT,
            self.silver_hough_dp,
            self.silver_hough_min_distance,
            param1=self.silver_hough_param1,
            param2=self.silver_hough_param2,
            minRadius=self.silver_hough_min_radius,
            maxRadius=self.silver_hough_max_radius,
        )

        candidates: list[dict[str, Any]] = []
        if circles is not None:
            for cx, cy, radius in np.round(circles[0, :]).astype("int"):
                if radius < 2:
                    continue
                conf = self._silver_circle_confidence(working, int(cx), int(cy), int(radius))
                if last_x is not None:
                    abs_x = int(cx) + x0
                    proximity = 1.0 - (abs(float(abs_x - last_x)) / max(1.0, float(image.shape[1])))
                    conf = _clamp01(0.90 * conf + 0.10 * _clamp01(proximity))
                if conf < self.silver_candidate_threshold:
                    continue
                abs_x = int(cx) + x0
                bbox = _bbox_from_circle(abs_x, int(cy), int(radius), image.shape)
                if bbox is None:
                    continue
                candidates.append(
                    {
                        "found": bool(conf >= self.silver_conf_threshold),
                        "x": int(abs_x),
                        "confidence": float(_clamp01(conf)),
                        "bbox": bbox,
                        "circle": {"x": int(abs_x), "y": int(cy), "r": int(radius)},
                        "origin": "heuristic_hough",
                    }
                )

        if not candidates:
            fallback = self._fallback_live_circle(working, last_x=last_x, x_offset=x0, frame_width=image.shape[1])
            if fallback is not None:
                fx, fy, fr, fconf = fallback
                abs_x = int(fx) + x0
                bbox = _bbox_from_circle(abs_x, int(fy), int(fr), image.shape)
                if bbox is not None:
                    conf = float(_clamp01(fconf))
                    candidates.append(
                        {
                            "found": bool(conf >= self.silver_conf_threshold),
                            "x": int(abs_x),
                            "confidence": conf,
                            "bbox": bbox,
                            "circle": {"x": int(abs_x), "y": int(fy), "r": int(fr)},
                            "origin": "heuristic_specular",
                        }
                    )

        if not candidates:
            self._reset_live()
            return []

        deduped = self._deduplicate_live_candidates(candidates)
        deduped.sort(key=lambda item: float(item.get("confidence", 0.0)), reverse=True)
        deduped = deduped[: self.silver_max_candidates]
        if not deduped:
            self._reset_live()
            return []

        top = deduped[0]
        top_circle = top.get("circle")
        if isinstance(top_circle, Mapping):
            self.last_live_circle = (
                int(top_circle.get("x", 0)),
                int(top_circle.get("y", 0)),
                int(top_circle.get("r", 0)),
            )
        else:
            self.last_live_circle = None
        self.last_live_confidence = float(_clamp01(float(top.get("confidence", 0.0))))
        self.last_live_bbox = top.get("bbox") if isinstance(top.get("bbox"), Mapping) else None
        self.last_live_origin = str(top.get("origin", "none"))
        return deduped

    def dead_detection(self, image: np.ndarray, last_x: int | None) -> dict[str, Any]:
        if image is None or image.size == 0:
            self._reset_dead()
            return self._empty_result()

        if last_x is not None:
            x0 = max(0, int(last_x) - self.crop_size)
            x1 = min(image.shape[1], int(last_x) + self.crop_size)
            working = image[:, x0:x1].copy()
        else:
            x0 = 0
            working = image.copy()

        white = cv2.inRange(working, self.dead_white_threshold, (255, 255, 255))
        white = cv2.erode(white, self.dead_white_kernel, iterations=1)
        white = cv2.dilate(white, self.dead_white_kernel, iterations=1)
        working[white > 0] = [160, 160, 160]

        black = cv2.inRange(working, (0, 0, 0), self.dead_black_threshold)
        contours, _ = cv2.findContours(black, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        filtered = np.zeros_like(black)
        for contour in contours:
            if cv2.contourArea(contour) >= self.dead_min_black_area:
                cv2.fillPoly(filtered, [contour], 255)
        black = cv2.dilate(filtered, self.dead_black_kernel, iterations=1)

        gray = cv2.cvtColor(working, cv2.COLOR_BGR2GRAY)
        gray = cv2.bitwise_and(gray, black)
        circles = cv2.HoughCircles(
            gray,
            cv2.HOUGH_GRADIENT,
            self.dead_hough_dp,
            self.dead_hough_min_distance,
            param1=self.dead_hough_param1,
            param2=self.dead_hough_param2,
            minRadius=self.dead_hough_min_radius,
            maxRadius=self.dead_hough_max_radius,
        )
        if circles is None:
            self._reset_dead()
            return self._empty_result()

        best: tuple[int, int, int] | None = None
        best_conf = -1.0
        for x, y, radius in np.round(circles[0, :]).astype("int"):
            if y <= self.dead_min_y or (y - radius) <= self.dead_radius_y_min:
                continue
            conf = self._black_circle_confidence(working, black, int(x), int(y), int(radius))
            if last_x is not None:
                abs_x = int(x) + x0
                proximity = 1.0 - (abs(float(abs_x - last_x)) / max(1.0, float(image.shape[1])))
                conf = _clamp01(0.90 * conf + 0.10 * _clamp01(proximity))
            if conf > best_conf:
                best_conf = conf
                best = (int(x), int(y), int(radius))

        if best is None or best_conf < self.black_conf_threshold:
            self._reset_dead()
            return self._empty_result()

        cx = int(best[0] + x0)
        cy = int(best[1])
        radius = int(best[2])
        bbox = _bbox_from_circle(cx, cy, radius, image.shape)
        self.last_dead_circle = (cx, cy, radius)
        self.last_dead_confidence = _clamp01(best_conf)
        self.last_dead_bbox = bbox
        self.last_dead_origin = "heuristic_black"
        return {
            "found": True,
            "x": int(cx),
            "confidence": float(self.last_dead_confidence),
            "bbox": bbox,
            "circle": {"x": int(cx), "y": int(cy), "r": int(radius)},
            "origin": "heuristic_black",
        }

    def _fallback_live_circle(
        self,
        working: np.ndarray,
        *,
        last_x: int | None,
        x_offset: int,
        frame_width: int,
    ) -> tuple[int, int, int, float] | None:
        if working is None or working.size == 0:
            return None
        hsv = cv2.cvtColor(working, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(
            hsv,
            (0, 0, self.silver_specular_v_min),
            (180, self.silver_specular_s_max, 255),
        )
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return None

        img_area = float(working.shape[0] * working.shape[1])
        max_area = img_area * max(0.02, self.silver_specular_max_area_ratio)
        best_score = -1.0
        best_circle: tuple[int, int, int, float] | None = None

        for contour in contours:
            area = float(cv2.contourArea(contour))
            if area < self.silver_specular_min_area or area > max_area:
                continue
            perimeter = float(cv2.arcLength(contour, True))
            if perimeter <= 1e-6:
                continue
            circularity = float((4.0 * np.pi * area) / (perimeter * perimeter))
            if circularity < self.silver_specular_min_circularity:
                continue
            (x, y), radius = cv2.minEnclosingCircle(contour)
            if radius < 3.0:
                continue
            conf = self._silver_circle_confidence(working, int(x), int(y), int(radius))
            if last_x is not None:
                abs_x = int(x) + int(x_offset)
                proximity = 1.0 - (abs(float(abs_x - last_x)) / max(1.0, float(frame_width)))
                conf = _clamp01(0.90 * conf + 0.10 * _clamp01(proximity))
            score = conf * (0.35 + min(1.0, circularity))
            if score > best_score:
                best_score = score
                best_circle = (int(x), int(y), int(radius), float(conf))
        return best_circle

    def _deduplicate_live_candidates(self, candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if not candidates:
            return []
        sorted_candidates = sorted(candidates, key=lambda item: float(item.get("confidence", 0.0)), reverse=True)
        kept: list[dict[str, Any]] = []
        min_dist_base = max(4.0, float(self.silver_candidate_min_center_dist))
        for candidate in sorted_candidates:
            circle = candidate.get("circle")
            if not isinstance(circle, Mapping):
                continue
            cx = float(circle.get("x", 0.0))
            cy = float(circle.get("y", 0.0))
            radius = max(1.0, float(circle.get("r", 1.0)))
            reject = False
            for current in kept:
                current_circle = current.get("circle")
                if not isinstance(current_circle, Mapping):
                    continue
                ox = float(current_circle.get("x", 0.0))
                oy = float(current_circle.get("y", 0.0))
                oradius = max(1.0, float(current_circle.get("r", 1.0)))
                min_dist = max(min_dist_base, 0.45 * (radius + oradius))
                if ((cx - ox) * (cx - ox) + (cy - oy) * (cy - oy)) <= (min_dist * min_dist):
                    reject = True
                    break
                if _bbox_iou(candidate.get("bbox"), current.get("bbox")) >= self.silver_candidate_iou_nms:
                    reject = True
                    break
            if not reject:
                kept.append(candidate)
        return kept

    def _silver_circle_confidence(self, image: np.ndarray, cx: int, cy: int, radius: int) -> float:
        if image is None or image.size == 0 or radius <= 1:
            return 0.0
        mask = np.zeros(image.shape[:2], dtype=np.uint8)
        cv2.circle(mask, (int(cx), int(cy)), int(radius), 255, thickness=-1)
        pixels = image[mask > 0]
        if pixels.size == 0:
            return 0.0
        hsv_pixels = cv2.cvtColor(pixels.reshape(-1, 1, 3), cv2.COLOR_BGR2HSV).reshape(-1, 3)
        sat = float(np.mean(hsv_pixels[:, 1]))
        val = float(np.mean(hsv_pixels[:, 2]))
        sat_score = _clamp01(1.0 - (sat / 255.0))
        val_score = _clamp01(val / 255.0)
        spec_ratio = float(
            np.mean(
                (hsv_pixels[:, 1] <= self.silver_specular_s_max) & (hsv_pixels[:, 2] >= self.silver_specular_v_min)
            )
        )
        spec_score = _clamp01(spec_ratio * 2.6)
        gray_pixels = cv2.cvtColor(pixels.reshape(-1, 1, 3), cv2.COLOR_BGR2GRAY).reshape(-1)
        texture_score = _clamp01(float(np.std(gray_pixels)) / 70.0)
        conf = 0.36 * sat_score + 0.28 * val_score + 0.22 * spec_score + 0.14 * texture_score
        return _clamp01(conf)

    def _black_circle_confidence(
        self,
        image: np.ndarray,
        black_mask: np.ndarray,
        cx: int,
        cy: int,
        radius: int,
    ) -> float:
        if image is None or image.size == 0 or radius <= 1:
            return 0.0
        mask = np.zeros(image.shape[:2], dtype=np.uint8)
        cv2.circle(mask, (int(cx), int(cy)), int(radius), 255, thickness=-1)
        pixel_idx = mask > 0
        pixels = image[pixel_idx]
        if pixels.size == 0:
            return 0.0
        hsv_pixels = cv2.cvtColor(pixels.reshape(-1, 1, 3), cv2.COLOR_BGR2HSV).reshape(-1, 3)
        val_mean = float(np.mean(hsv_pixels[:, 2]))
        sat_mean = float(np.mean(hsv_pixels[:, 1]))
        dark_ratio = float(np.mean(hsv_pixels[:, 2] <= (self.dead_black_threshold[2] + 25)))
        mask_ratio = float(np.mean(black_mask[pixel_idx] > 0)) if black_mask.size > 0 else 0.0
        conf = (
            0.50 * _clamp01(dark_ratio)
            + 0.25 * _clamp01(1.0 - (val_mean / 255.0))
            + 0.15 * _clamp01(mask_ratio)
            + 0.10 * _clamp01(1.0 - (sat_mean / 255.0))
        )
        return _clamp01(conf)

    def _empty_result(self) -> dict[str, Any]:
        return {"found": False, "x": None, "confidence": 0.0, "bbox": None, "circle": None, "origin": "none"}

    def _reset_live(self) -> None:
        self.last_live_circle = None
        self.last_live_confidence = 0.0
        self.last_live_bbox = None
        self.last_live_origin = "none"

    def _reset_dead(self) -> None:
        self.last_dead_circle = None
        self.last_dead_confidence = 0.0
        self.last_dead_bbox = None
        self.last_dead_origin = "none"


class ColorMarkerDetector:
    def __init__(self, settings: Mapping[str, Any] | None = None) -> None:
        cfg = dict(settings or {})

        self.green_h_min = int(cfg.get("green_h_min", 35))
        self.green_h_max = int(cfg.get("green_h_max", 90))
        self.green_s_min = int(cfg.get("green_s_min", 70))
        self.green_v_min = int(cfg.get("green_v_min", 50))
        self.green_min_area = float(cfg.get("green_min_area", 180))
        self.green_min_aspect = float(cfg.get("green_min_aspect", 0.35))
        self.green_max_aspect = float(cfg.get("green_max_aspect", 3.0))
        self.green_max_area_ratio = float(cfg.get("green_max_area_ratio", 0.20))
        self.green_min_solidity = float(cfg.get("green_min_solidity", 0.72))
        self.green_min_extent = float(cfg.get("green_min_extent", 0.20))
        self.green_max_extent = float(cfg.get("green_max_extent", 0.97))
        self.green_min_short_side = float(cfg.get("green_min_short_side", 8.0))
        self.green_min_line_pixels_nearby = int(cfg.get("green_min_line_pixels_nearby", 110))
        self.green_corner_conf_threshold = float(cfg.get("green_corner_conf_threshold", 0.62))
        self.green_corner_min_area = float(cfg.get("green_corner_min_area", 520))
        self.green_corner_max_area_ratio = float(cfg.get("green_corner_max_area_ratio", 0.55))
        self.green_corner_min_short_side = float(cfg.get("green_corner_min_short_side", 18.0))
        self.green_corner_min_aspect = float(cfg.get("green_corner_min_aspect", 0.30))
        self.green_corner_max_aspect = float(cfg.get("green_corner_max_aspect", 4.2))
        self.green_corner_min_extent = float(cfg.get("green_corner_min_extent", 0.36))
        self.green_corner_min_solidity = float(cfg.get("green_corner_min_solidity", 0.55))
        self.green_corner_border_margin = int(cfg.get("green_corner_border_margin", 12))

        self.red_h1_min = int(cfg.get("red_h1_min", 0))
        self.red_h1_max = int(cfg.get("red_h1_max", 12))
        self.red_h2_min = int(cfg.get("red_h2_min", 165))
        self.red_h2_max = int(cfg.get("red_h2_max", 179))
        self.red_s_min = int(cfg.get("red_s_min", 120))
        self.red_v_min = int(cfg.get("red_v_min", 80))
        self.red_min_area = float(cfg.get("red_min_area", 300))
        self.red_min_ratio = float(cfg.get("red_min_ratio", 3.5))
        self.red_min_long_side = float(cfg.get("red_min_long_side", 30))

        self.green_row_margin = int(cfg.get("green_row_margin", 4))
        self.color_erode_iter = int(cfg.get("color_erode_iter", 1))
        self.color_dilate_iter = int(cfg.get("color_dilate_iter", 2))
        self.color_kernel = int(cfg.get("color_kernel", 3))

    def _clean_mask(self, mask: np.ndarray) -> np.ndarray:
        kernel_size = max(1, self.color_kernel)
        if kernel_size % 2 == 0:
            kernel_size += 1
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_size, kernel_size))
        if self.color_erode_iter > 0:
            mask = cv2.erode(mask, kernel, iterations=self.color_erode_iter)
        if self.color_dilate_iter > 0:
            mask = cv2.dilate(mask, kernel, iterations=self.color_dilate_iter)
        return mask

    def detect_green_instruction(self, image: np.ndarray, black_mask: np.ndarray | None) -> dict[str, Any]:
        green = self.detect_green_side(image)
        contours = list(green["contours"])
        if len(contours) >= 2:
            merged = self._merge_contour_bboxes(contours[:2], image.shape)
            return {
                "found": True,
                "side": "BOTH",
                "instruction": "VERDE MEIA VOLTA",
                "ref_y": None,
                "contours": contours,
                "confidence": 0.95,
                "bbox": merged,
            }

        if len(contours) == 0:
            return {
                "found": False,
                "side": "NONE",
                "instruction": "NO GREEN",
                "ref_y": None,
                "contours": [],
                "confidence": 0.0,
                "bbox": None,
            }

        contour = contours[0]
        x, y, w, h = cv2.boundingRect(contour)
        green_center_y = y + (h / 2.0)

        ref_y = self._horizontal_reference_y(
            black_mask,
            x0=x - (w * 0.5),
            x1=x + w + (w * 0.5),
        )
        if ref_y is None:
            ref_y = image.shape[0] / 2.0

        margin = int(self.green_row_margin)
        if green_center_y <= (ref_y - margin):
            instruction = "VERDE DEPOIS"
        elif green_center_y >= (ref_y + margin):
            instruction = "VERDE ANTES"
        else:
            mask_one = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)
            cv2.drawContours(mask_one, [contour], -1, 255, thickness=cv2.FILLED)
            upper = np.count_nonzero(mask_one[: int(ref_y), :])
            lower = np.count_nonzero(mask_one[int(ref_y) :, :])
            instruction = "VERDE DEPOIS" if upper >= lower else "VERDE ANTES"

        area = float(cv2.contourArea(contour))
        img_area = float(image.shape[0] * image.shape[1])
        conf_area = _clamp01(area / max(float(self.green_min_area), img_area * 0.03, 1.0))
        conf_geom = 1.0 if green["side"] in {"LEFT", "RIGHT", "BOTH"} else 0.0
        confidence = _clamp01(0.65 * conf_geom + 0.35 * conf_area)
        return {
            "found": True,
            "side": green["side"],
            "instruction": instruction,
            "ref_y": int(ref_y),
            "contours": contours,
            "confidence": float(confidence),
            "bbox": _safe_bbox(x, y, w, h, image.shape),
        }

    def detect_green_side(self, image: np.ndarray) -> dict[str, Any]:
        if image is None or image.size == 0:
            return {"found": False, "side": "NONE", "contours": []}

        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        lower = (int(self.green_h_min), int(self.green_s_min), int(self.green_v_min))
        upper = (int(self.green_h_max), 255, 255)
        green_mask = cv2.inRange(hsv, lower, upper)
        green_mask = self._clean_mask(green_mask)

        contours, _ = cv2.findContours(green_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        valid_contours: list[np.ndarray] = []
        has_left = False
        has_right = False
        half_x = image.shape[1] / 2.0

        for contour in contours:
            area = float(cv2.contourArea(contour))
            if area < float(self.green_min_area):
                continue
            img_area = float(image.shape[0] * image.shape[1])
            if area > img_area * max(0.05, float(self.green_max_area_ratio)):
                continue
            x, y, w, h = cv2.boundingRect(contour)
            if h <= 0:
                continue
            aspect = w / float(h)
            if aspect < float(self.green_min_aspect) or aspect > float(self.green_max_aspect):
                continue
            valid_contours.append(contour)
            centre_x = x + (w / 2.0)
            if centre_x < half_x:
                has_left = True
            else:
                has_right = True

        if has_left and has_right:
            side = "BOTH"
        elif has_left:
            side = "LEFT"
        elif has_right:
            side = "RIGHT"
        else:
            side = "NONE"
        return {"found": side != "NONE", "side": side, "contours": valid_contours}

    def detect_green_corner(self, image: np.ndarray) -> dict[str, Any]:
        if image is None or image.size == 0:
            return {"found": False, "confidence": 0.0, "bbox": None, "contours": []}

        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        lower = (int(self.green_h_min), int(self.green_s_min), int(self.green_v_min))
        upper = (int(self.green_h_max), 255, 255)
        green_mask = cv2.inRange(hsv, lower, upper)
        green_mask = self._clean_mask(green_mask)

        contours, _ = cv2.findContours(green_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        img_area = float(max(1, image.shape[0] * image.shape[1]))
        max_area = img_area * max(0.08, self.green_corner_max_area_ratio)
        margin = max(2, int(self.green_corner_border_margin))

        best_conf = 0.0
        best_bbox: dict[str, int] | None = None
        best_contour: np.ndarray | None = None
        for contour in contours:
            area = float(cv2.contourArea(contour))
            if area < self.green_corner_min_area or area > max_area:
                continue

            x, y, w, h = cv2.boundingRect(contour)
            if w <= 0 or h <= 0:
                continue
            short = float(min(w, h))
            long = float(max(w, h))
            if short < self.green_corner_min_short_side:
                continue
            aspect = long / max(1.0, short)
            if aspect < self.green_corner_min_aspect or aspect > self.green_corner_max_aspect:
                continue

            extent = area / float(max(1, w * h))
            hull = cv2.convexHull(contour)
            hull_area = float(cv2.contourArea(hull))
            solidity = area / hull_area if hull_area > 1e-6 else 0.0
            if extent < self.green_corner_min_extent or solidity < self.green_corner_min_solidity:
                continue

            touches_border = (
                x <= margin
                or y <= margin
                or (x + w) >= (image.shape[1] - margin)
                or (y + h) >= (image.shape[0] - margin)
            )
            area_score = _clamp01(area / max(self.green_corner_min_area * 3.0, 1.0))
            shape_score = _clamp01(
                0.45 * _clamp01(extent / max(self.green_corner_min_extent, 1e-6))
                + 0.35 * _clamp01(solidity / max(self.green_corner_min_solidity, 1e-6))
                + 0.20 * _clamp01(short / max(self.green_corner_min_short_side * 1.5, 1.0))
            )
            border_score = 1.0 if touches_border else 0.35
            confidence = _clamp01(0.48 * shape_score + 0.34 * area_score + 0.18 * border_score)
            if confidence > best_conf:
                best_conf = confidence
                best_bbox = _safe_bbox(x, y, w, h, image.shape)
                best_contour = contour

        found = bool(best_bbox is not None and best_conf >= self.green_corner_conf_threshold)
        return {
            "found": found,
            "confidence": float(best_conf if found else 0.0),
            "bbox": best_bbox if found else None,
            "contours": [best_contour] if (found and best_contour is not None) else [],
        }

    @staticmethod
    def _horizontal_reference_y(black_mask: np.ndarray | None, x0: int | float, x1: int | float) -> int | None:
        if black_mask is None or black_mask.size == 0:
            return None
        start_x = max(0, int(x0))
        end_x = min(black_mask.shape[1], int(x1))
        if end_x <= start_x:
            return None
        roi = black_mask[:, start_x:end_x]
        if roi.size == 0:
            return None
        row_counts = np.count_nonzero(roi, axis=1).astype(np.float32)
        if row_counts.max() <= 0:
            return None
        smooth = cv2.GaussianBlur(row_counts.reshape(-1, 1), (1, 9), 0).reshape(-1)
        return int(np.argmax(smooth))

    @staticmethod
    def _merge_contour_bboxes(contours: list[np.ndarray], frame_shape: tuple[int, ...]) -> dict[str, int] | None:
        if not contours:
            return None
        xs: list[int] = []
        ys: list[int] = []
        x2s: list[int] = []
        y2s: list[int] = []
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            xs.append(int(x))
            ys.append(int(y))
            x2s.append(int(x + w))
            y2s.append(int(y + h))
        if not xs:
            return None
        return _safe_bbox(min(xs), min(ys), max(x2s) - min(xs), max(y2s) - min(ys), frame_shape)

    def detect_red_presence(self, image: np.ndarray) -> dict[str, Any]:
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        red1 = cv2.inRange(
            hsv,
            (self.red_h1_min, self.red_s_min, self.red_v_min),
            (self.red_h1_max, 255, 255),
        )
        red2 = cv2.inRange(
            hsv,
            (self.red_h2_min, self.red_s_min, self.red_v_min),
            (self.red_h2_max, 255, 255),
        )
        red = self._clean_mask(cv2.bitwise_or(red1, red2))
        contours, _ = cv2.findContours(red, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        total_area = 0.0
        valid: list[np.ndarray] = []
        best_conf = 0.0
        best_bbox: dict[str, int] | None = None
        for contour in contours:
            area = cv2.contourArea(contour)
            if area < self.red_min_area:
                continue
            rect = cv2.minAreaRect(contour)
            width = float(rect[1][0])
            height = float(rect[1][1])
            short = min(width, height)
            long = max(width, height)
            if short <= 0:
                continue
            ratio = long / short
            if ratio < self.red_min_ratio or long < self.red_min_long_side:
                continue
            valid.append(contour)
            total_area += area
            x, y, w, h = cv2.boundingRect(contour)
            bbox = _safe_bbox(x, y, w, h, image.shape)
            if bbox is None:
                continue
            ratio_score = _clamp01((ratio - self.red_min_ratio) / max(0.5, self.red_min_ratio))
            area_score = _clamp01(area / max(float(self.red_min_area), 1.0) / 4.0)
            conf = _clamp01(0.65 * ratio_score + 0.35 * area_score)
            if conf > best_conf:
                best_conf = conf
                best_bbox = bbox
        return {
            "found": len(valid) > 0,
            "area": int(total_area),
            "contours": valid,
            "confidence": float(best_conf) if valid else 0.0,
            "bbox": best_bbox if valid else None,
        }


class SilverBallRuntime:
    def __init__(self, enabled: bool, model_path: Path | None, threshold: float, input_size: int = 64) -> None:
        self.enabled = bool(enabled)
        self.available = False
        self.error: str | None = None
        self.threshold = float(threshold)
        self.input_size = max(24, int(input_size))
        self._model_path = model_path
        self._initialized = False
        self._model: Any = None
        if not self.enabled:
            self.error = "disabled"

    def _ensure_loaded(self) -> None:
        if self._initialized:
            return
        self._initialized = True
        if not self.enabled:
            self.error = "disabled"
            return
        if self._model_path is None or not self._model_path.exists():
            self.error = "model_not_found"
            return
        try:
            import torch
        except Exception as exc:  # pragma: no cover
            self.error = str(exc)
            return
        try:
            safe_model_path = self._filesystem_safe_path(self._model_path)
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                self._model = torch.jit.load(safe_model_path, map_location="cpu")
                self._model.eval()
            self.available = True
        except Exception as exc:  # pragma: no cover
            self.error = str(exc)

    @staticmethod
    def _filesystem_safe_path(path: Path) -> str:
        value = str(path)
        if os.name != "nt":
            return value
        try:
            import ctypes

            initial = 260
            buffer = ctypes.create_unicode_buffer(initial)
            result = ctypes.windll.kernel32.GetShortPathNameW(value, buffer, initial)
            if result == 0:
                return value
            if result > initial:
                buffer = ctypes.create_unicode_buffer(result)
                result = ctypes.windll.kernel32.GetShortPathNameW(value, buffer, result)
                if result == 0:
                    return value
            short_path = buffer.value
            return short_path if short_path else value
        except Exception:
            return value

    def _prepare_patch(self, image: np.ndarray, bbox: Mapping[str, Any] | None) -> np.ndarray:
        if bbox is not None:
            x = int(bbox.get("x", 0))
            y = int(bbox.get("y", 0))
            w = int(bbox.get("w", 0))
            h = int(bbox.get("h", 0))
            if w > 0 and h > 0:
                x0 = max(0, x)
                y0 = max(0, y)
                x1 = min(image.shape[1], x + w)
                y1 = min(image.shape[0], y + h)
                if x1 > x0 and y1 > y0:
                    patch = image[y0:y1, x0:x1]
                else:
                    patch = image
            else:
                patch = image
        else:
            patch = image
        patch = cv2.resize(patch, (self.input_size, self.input_size), interpolation=cv2.INTER_AREA)
        return patch

    def predict(self, image: np.ndarray, bbox: Mapping[str, Any] | None) -> tuple[bool, float, dict[str, Any]]:
        was_initialized = self._initialized
        self._ensure_loaded()
        just_initialized = not was_initialized
        if not self.available or self._model is None:
            return False, 0.0, {"available": False, "error": self.error or "unavailable", "just_initialized": just_initialized}

        try:
            import torch

            patch = self._prepare_patch(image, bbox)
            rgb = cv2.cvtColor(patch, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
            tensor = torch.from_numpy(np.transpose(rgb, (2, 0, 1))).unsqueeze(0)
            with torch.no_grad():
                logits = self._model(tensor)
            out = logits.reshape(-1).detach().cpu().numpy().astype(np.float32)
            if out.size == 0:
                score = 0.0
            elif out.size == 1:
                score = float(out[0])
                if score < 0.0 or score > 1.0:
                    score = float(1.0 / (1.0 + np.exp(-score)))
            else:
                shifted = out - np.max(out)
                exp = np.exp(shifted)
                denom = float(np.sum(exp))
                probs = exp / denom if denom > 0 else np.zeros_like(exp)
                score = float(probs[1] if probs.size > 1 else probs[0])
            score = _clamp01(score)
            return score >= self.threshold, score, {"available": True, "just_initialized": just_initialized}
        except Exception as exc:  # pragma: no cover
            return False, 0.0, {"available": False, "error": str(exc), "just_initialized": just_initialized}


class SilverLineRuntime:
    def __init__(self, enabled: bool, model_path: Path | None, threshold: float) -> None:
        self.available = False
        self.error: str | None = None
        self.threshold = float(threshold)
        self._enabled = bool(enabled)
        self._model_path = model_path
        self._initialized = False
        self._detector: Any = None

    def _ensure_loaded(self) -> None:
        if self._initialized:
            return
        self._initialized = True

        if not self._enabled:
            self.error = "disabled"
            return
        if self._model_path is None or not self._model_path.exists():
            self.error = "model_not_found"
            return
        try:
            intl_root = _REPO_ROOT / "1_international"
            if str(intl_root) not in sys.path:
                sys.path.insert(0, str(intl_root))
            module = importlib.import_module("behaviours.silver_detection")
            detector_cls = getattr(module, "SilverLineDetector")
            model_arg = self._filesystem_safe_path(self._model_path)
            stream = io.StringIO()
            with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
                self._detector = detector_cls(model_arg)
            self.available = True
        except Exception as exc:  # pragma: no cover
            self.error = str(exc)

    @staticmethod
    def _filesystem_safe_path(path: Path) -> str:
        value = str(path)
        if os.name != "nt":
            return value
        try:
            import ctypes

            initial = 260
            buffer = ctypes.create_unicode_buffer(initial)
            result = ctypes.windll.kernel32.GetShortPathNameW(value, buffer, initial)
            if result == 0:
                return value
            if result > initial:
                buffer = ctypes.create_unicode_buffer(result)
                result = ctypes.windll.kernel32.GetShortPathNameW(value, buffer, result)
                if result == 0:
                    return value
            short_path = buffer.value
            return short_path if short_path else value
        except Exception:
            return value

    def predict(self, image: np.ndarray) -> tuple[bool, float, dict[str, Any]]:
        was_initialized = self._initialized
        self._ensure_loaded()
        just_initialized = not was_initialized
        if not self.available or self._detector is None:
            return False, 0.0, {"available": False, "error": self.error or "unavailable", "just_initialized": just_initialized}
        try:
            out = self._detector.predict(image)
            if isinstance(out, tuple):
                out = out[0]
            confidence = float(out.get("confidence", 0.0))
            found = int(out.get("prediction", 0)) == 1 and confidence >= self.threshold
            return found, confidence, {"available": True, "just_initialized": just_initialized}
        except Exception as exc:  # pragma: no cover
            return False, 0.0, {"available": False, "error": str(exc), "just_initialized": just_initialized}


class DeadVictimRuntime:
    def __init__(self, enabled: bool, model_path: Path | None, threshold: float) -> None:
        self.enabled = bool(enabled)
        self.available = False
        self.error: str | None = None
        self.threshold = float(threshold)
        self._enabled = self.enabled
        self._model_path = model_path
        self._initialized = False
        self._interpreter: Any = None
        self._input: dict[str, Any] | None = None
        self._output: dict[str, Any] | None = None
        if not self._enabled:
            self.error = "disabled"

    def _load(self, model_path: Path) -> None:
        interpreter_cls: Any | None = None
        try:
            from tflite_runtime.interpreter import Interpreter  # type: ignore

            interpreter_cls = Interpreter
        except Exception:
            try:
                from tensorflow.lite.python.interpreter import Interpreter  # type: ignore

                interpreter_cls = Interpreter
            except Exception as exc:  # pragma: no cover
                self.error = str(exc)
                return
        try:
            safe_model_path = SilverLineRuntime._filesystem_safe_path(model_path)
            self._interpreter = interpreter_cls(model_path=safe_model_path)
            self._interpreter.allocate_tensors()
            self._input = self._interpreter.get_input_details()[0]
            self._output = self._interpreter.get_output_details()[0]
            self.available = True
        except Exception as exc:  # pragma: no cover
            self.error = str(exc)

    def _ensure_loaded(self) -> None:
        if self._initialized:
            return
        self._initialized = True
        if not self._enabled:
            self.error = "disabled"
            return
        if self._model_path is None or not self._model_path.exists():
            self.error = "model_not_found"
            return
        self._load(self._model_path)

    @staticmethod
    def _softmax(vector: np.ndarray) -> np.ndarray:
        shifted = vector - np.max(vector)
        exp = np.exp(shifted)
        denom = np.sum(exp)
        return exp / denom if denom > 0 else np.zeros_like(vector)

    def _prepare_input(self, image: np.ndarray) -> np.ndarray:
        if self._input is None:
            raise RuntimeError("missing tflite input details")
        shape = [int(v) for v in self._input["shape"]]
        dtype = self._input["dtype"]
        if len(shape) != 4:
            raise RuntimeError(f"unsupported input shape: {shape}")
        _, d1, d2, d3 = shape
        if d3 in (1, 3):
            h, w, c = d1, d2, d3
            is_nhwc = True
        else:
            c, h, w = d1, d2, d3
            is_nhwc = False
        if c not in (1, 3):
            raise RuntimeError(f"unsupported channel count: {c}")

        tensor = cv2.resize(image, (w, h), interpolation=cv2.INTER_LINEAR)
        if c == 1:
            tensor = cv2.cvtColor(tensor, cv2.COLOR_BGR2GRAY)[:, :, None]
        if not is_nhwc:
            tensor = np.transpose(tensor, (2, 0, 1))
        tensor = tensor.astype(np.float32)
        if np.max(tensor) > 1.0:
            tensor = tensor / 255.0
        tensor = tensor[None, ...]

        if dtype == np.uint8:
            quant = self._input.get("quantization", (0.0, 0))
            scale = float(quant[0]) if quant else 0.0
            zero = int(quant[1]) if quant else 0
            if scale > 0:
                tensor = np.clip(np.round(tensor / scale + zero), 0, 255).astype(np.uint8)
            else:
                tensor = np.clip(np.round(tensor * 255.0), 0, 255).astype(np.uint8)
        else:
            tensor = tensor.astype(dtype)
        return tensor

    def predict(self, image: np.ndarray) -> tuple[bool, float, dict[str, Any]]:
        was_initialized = self._initialized
        self._ensure_loaded()
        just_initialized = not was_initialized
        if not self.available or self._interpreter is None or self._input is None or self._output is None:
            return False, 0.0, {"available": False, "error": self.error or "unavailable", "just_initialized": just_initialized}
        try:
            tensor = self._prepare_input(image)
            self._interpreter.set_tensor(self._input["index"], tensor)
            self._interpreter.invoke()
            output = self._interpreter.get_tensor(self._output["index"]).reshape(-1).astype(np.float32)
            if output.size == 0:
                return False, 0.0, {"available": True, "just_initialized": just_initialized}
            if output.size == 1:
                score = float(output[0])
                if score < 0 or score > 1:
                    score = float(1.0 / (1.0 + np.exp(-score)))
            else:
                probs = self._softmax(output)
                score = float(probs[1] if probs.size > 1 else probs[0])
            return score >= self.threshold, score, {"available": True, "just_initialized": just_initialized}
        except Exception as exc:  # pragma: no cover
            return False, 0.0, {"available": False, "error": str(exc), "just_initialized": just_initialized}


@dataclass(slots=True)
class PipelineOutput:
    event: VisionDetectionEvent
    processed_frame: np.ndarray


class VisionPipelineManager:
    def __init__(self, config: VisionConfig) -> None:
        self.config = config
        self.preprocessor = VisionPreprocessor(config.preprocessor)

        line_resize = self._profile_resize("line", default_w=320, default_h=200)
        rescue_resize = self._profile_resize("rescue", default_w=320, default_h=240)
        self.line_detector = LineDetector(line_resize[0], line_resize[1], config.detector("line"))
        self.ball_detector = BallDetector(rescue_resize[0], rescue_resize[1], config.detector("ball"))
        self.color_detector = ColorMarkerDetector(config.detector("color"))
        ball_cfg = config.detector("ball")
        self.silver_ball = SilverBallRuntime(
            enabled=bool(ball_cfg.get("silver_model_enabled", True)),
            model_path=config.model_path("silver_ball"),
            threshold=float(ball_cfg.get("silver_model_threshold", 0.62)),
            input_size=int(ball_cfg.get("silver_model_input_size", 64)),
        )

        silver_cfg = config.detector("silver_line")
        self.silver_every_n = max(1, int(silver_cfg.get("run_every_n_frames", 2)))
        self.silver = SilverLineRuntime(
            enabled=bool(silver_cfg.get("enabled", True)),
            model_path=config.model_path("silver_line"),
            threshold=float(silver_cfg.get("confidence_threshold", 0.95)),
        )
        dead_cfg = config.detector("dead_victim")
        self.dead_every_n = max(1, int(dead_cfg.get("run_every_n_frames", 3)))
        self.dead = DeadVictimRuntime(
            enabled=bool(dead_cfg.get("enabled", True)),
            model_path=config.model_path("dead_victim_tflite"),
            threshold=float(dead_cfg.get("confidence_threshold", 0.55)),
        )

        benchmark_cfg = config.benchmark()
        self.baseline_monolithic_ms = float(benchmark_cfg.get("baseline_monolithic_ms", 0.0))
        self.expected_by_state = benchmark_cfg.get("state_expected_ms", {})
        runtime_cfg = config.data.get("runtime", {}) if isinstance(config.data.get("runtime"), Mapping) else {}
        history_size = max(10, int(runtime_cfg.get("history_size", 120)))
        self.corner_stability_window = max(3, int(runtime_cfg.get("corner_stability_window", 5)))
        self.corner_on_votes = max(1, int(runtime_cfg.get("corner_on_votes", 3)))
        self.corner_off_votes = max(0, int(runtime_cfg.get("corner_off_votes", 1)))
        self.latency_history: dict[str, deque[float]] = defaultdict(lambda: deque(maxlen=history_size))

        self.frame_counter = 0
        self.last_live_x: int | None = None
        self.last_dead_x: int | None = None
        self.silver_cache = (False, 0.0)
        self.dead_cache = (False, 0.0, {"available": False})
        self.dead_cache_ready = False
        self._warmup_seen: set[str] = set()

    def run(self, state: RobotState | str, frame_bgr: np.ndarray) -> PipelineOutput:
        state_name = _state_name(state)
        self.frame_counter += 1

        pipeline_cfg = self.config.pipeline(state_name)
        profile = str(pipeline_cfg.get("profile", self._default_profile(state_name)))
        detectors = self._active_detectors(pipeline_cfg.get("detectors"))

        started = time.perf_counter()
        prepared = self.preprocessor.prepare(frame_bgr, profile=profile)
        processed = prepared.frame
        overlay_frame = processed.copy()

        line = False
        balls = 0
        green = False
        red = False
        victims = 0
        ignore_benchmark_sample = False
        contour: np.ndarray | None = None
        green_contours: list[np.ndarray] = []
        red_contours: list[np.ndarray] = []

        metadata: dict[str, Any] = {
            "pipeline_profile": profile,
            "active_detectors": detectors,
            "preprocessor": prepared.metadata,
            "runtime": {
                "corner_stability_window": int(self.corner_stability_window),
                "corner_on_votes": int(self.corner_on_votes),
                "corner_off_votes": int(self.corner_off_votes),
            },
            "silver_ball_found": False,
            "silver_ball_confidence": 0.0,
            "silver_ball_bbox": None,
            "silver_ball_origin": "none",
            "silver_ball_candidates": [],
            "silver_ball_count": 0,
            "black_ball_found": False,
            "black_ball_confidence": 0.0,
            "black_ball_bbox": None,
            "black_ball_origin": "none",
            "green_side": "NONE",
            "green_instruction": "NO GREEN",
            "green_marker_found": False,
            "green_marker_confidence": 0.0,
            "green_marker_bbox": None,
            "green_corner_found": False,
            "green_corner_confidence": 0.0,
            "green_corner_bbox": None,
            "red_corner_found": False,
            "red_corner_confidence": 0.0,
            "red_corner_bbox": None,
            "silver_ball_model": {"found": False, "confidence": 0.0, "available": False},
        }

        black_mask: np.ndarray | None = None
        if "line" in detectors:
            contour, black_mask = self.line_detector.black_mask(processed)
            line = contour is not None
            angle, gap = self.line_detector.calculate_angle(contour)
            metadata["line_angle_deg"] = int(angle)
            metadata["line_gap_frames"] = int(gap)

        if "green" in detectors:
            green_out = self.color_detector.detect_green_instruction(processed, black_mask)
            green = bool(green_out.get("found", False))
            green_contours = list(green_out.get("contours", []))
            metadata["green_side"] = green_out.get("side", "NONE")
            metadata["green_instruction"] = green_out.get("instruction", "NO GREEN")
            metadata["green_marker_found"] = bool(green)
            metadata["green_marker_confidence"] = float(green_out.get("confidence", 0.0) if green else 0.0)
            metadata["green_marker_bbox"] = green_out.get("bbox") if green else None

        if "green_corner" in detectors:
            green_corner_out = self.color_detector.detect_green_corner(processed)
            metadata["green_corner_found"] = bool(green_corner_out.get("found", False))
            metadata["green_corner_confidence"] = float(
                green_corner_out.get("confidence", 0.0) if bool(green_corner_out.get("found", False)) else 0.0
            )
            metadata["green_corner_bbox"] = green_corner_out.get("bbox") if bool(green_corner_out.get("found", False)) else None

        if "red" in detectors or "red_zone" in detectors:
            red_out = self.color_detector.detect_red_presence(processed)
            red = bool(red_out.get("found", False))
            red_contours = list(red_out.get("contours", []))
            metadata["red_area"] = int(red_out.get("area", 0))
            metadata["red_corner_found"] = bool(red)
            metadata["red_corner_confidence"] = float(red_out.get("confidence", 0.0) if red else 0.0)
            metadata["red_corner_bbox"] = red_out.get("bbox") if red else None

        if "silver_line" in detectors:
            if self.frame_counter % self.silver_every_n == 0:
                silver_found, silver_conf, silver_meta = self.silver.predict(processed)
                self.silver_cache = (silver_found, silver_conf)
                silver_meta["cached"] = False
            else:
                silver_found, silver_conf = self.silver_cache
                silver_meta = {"available": self.silver.available, "cached": True}
            if bool(silver_meta.get("just_initialized", False)):
                ignore_benchmark_sample = True
            metadata["silver_line"] = {
                "found": bool(silver_found),
                "confidence": float(silver_conf),
                **silver_meta,
            }

        silver_candidates_found: list[dict[str, Any]] = []
        if "balls" in detectors:
            raw_silver_candidates = self.ball_detector.live_detections(processed, self.last_live_x)
            tuned_candidates: list[dict[str, Any]] = []
            primary_model_found = False
            primary_model_conf = 0.0
            primary_model_meta: dict[str, Any] = {"available": False}

            for idx, raw_candidate in enumerate(raw_silver_candidates):
                candidate = dict(raw_candidate)
                heur_conf = float(candidate.get("confidence", 0.0))
                model_conf = 0.0
                model_meta: dict[str, Any] = {"available": False}
                if self.silver_ball.enabled:
                    model_found, model_conf, model_meta = self.silver_ball.predict(
                        processed,
                        candidate.get("bbox") if isinstance(candidate.get("bbox"), Mapping) else None,
                    )
                    if bool(model_meta.get("just_initialized", False)):
                        ignore_benchmark_sample = True
                    if bool(model_meta.get("available", False)):
                        combined = _clamp01(0.55 * heur_conf + 0.45 * float(model_conf))
                        candidate["confidence"] = float(combined)
                        candidate["found"] = bool(combined >= max(self.ball_detector.silver_conf_threshold, 0.48))
                        if bool(candidate.get("found", False)):
                            candidate["origin"] = "hybrid_model"
                    if idx == 0:
                        primary_model_found = bool(model_found)
                        primary_model_conf = float(model_conf)
                        primary_model_meta = dict(model_meta)
                candidate["model_confidence"] = float(model_conf)
                tuned_candidates.append(candidate)

            silver_candidates_found = [
                candidate
                for candidate in tuned_candidates
                if bool(candidate.get("found", False)) and isinstance(candidate.get("bbox"), Mapping)
            ]
            silver_candidates_found.sort(key=lambda item: float(item.get("confidence", 0.0)), reverse=True)
            balls = len(silver_candidates_found)
            self.last_live_x = int(silver_candidates_found[0].get("x", 0)) if silver_candidates_found else None
            metadata["silver_ball_model"] = {
                "found": bool(primary_model_found),
                "confidence": float(primary_model_conf),
                **primary_model_meta,
            }

        black_overlap_suppressed = False

        black_out: dict[str, Any] = self.ball_detector._empty_result()
        if "victims" in detectors:
            black_out = self.ball_detector.dead_detection(processed, self.last_dead_x)
            if bool(black_out.get("found", False)):
                self.last_dead_x = int(black_out["x"])
            else:
                self.last_dead_x = None
            metadata["dead_ball_circle"] = black_out.get("circle")
            metadata["black_ball_found"] = bool(black_out.get("found", False))
            metadata["black_ball_confidence"] = float(black_out.get("confidence", 0.0))
            metadata["black_ball_bbox"] = black_out.get("bbox")
            metadata["black_ball_origin"] = str(black_out.get("origin", "none"))
            metadata["dead_ball_x"] = int(black_out["x"]) if black_out.get("x") is not None else None
        else:
            metadata["dead_ball_circle"] = None
            metadata["dead_ball_x"] = None

        if silver_candidates_found and bool(black_out.get("found", False)):
            overlap_px = max(0, int(self.ball_detector.silver_black_overlap_px))
            black_x = int(black_out["x"]) if black_out.get("x") is not None else None
            black_bbox = black_out.get("bbox") if isinstance(black_out.get("bbox"), Mapping) else None
            filtered_candidates: list[dict[str, Any]] = []
            for candidate in silver_candidates_found:
                silver_x = candidate.get("x")
                silver_bbox = candidate.get("bbox") if isinstance(candidate.get("bbox"), Mapping) else None
                x_overlap = (
                    black_x is not None
                    and silver_x is not None
                    and abs(int(silver_x) - int(black_x)) <= overlap_px
                )
                iou_overlap = _bbox_iou(silver_bbox, black_bbox) >= 0.25
                if x_overlap or iou_overlap:
                    black_overlap_suppressed = True
                    continue
                filtered_candidates.append(candidate)
            silver_candidates_found = filtered_candidates
            balls = len(silver_candidates_found)

        if "balls" in detectors:
            metadata["silver_ball_candidates"] = [
                {
                    "x": int(candidate.get("x", 0)),
                    "confidence": float(_clamp01(float(candidate.get("confidence", 0.0)))),
                    "bbox": dict(candidate.get("bbox", {})) if isinstance(candidate.get("bbox"), Mapping) else None,
                    "circle": dict(candidate.get("circle", {})) if isinstance(candidate.get("circle"), Mapping) else None,
                    "origin": str(candidate.get("origin", "none")),
                }
                for candidate in silver_candidates_found
            ]
            metadata["silver_ball_count"] = int(len(silver_candidates_found))
            if silver_candidates_found:
                primary_silver = silver_candidates_found[0]
                metadata["silver_ball_x"] = int(primary_silver["x"]) if primary_silver.get("x") is not None else None
                metadata["silver_ball_circle"] = primary_silver.get("circle")
                metadata["silver_ball_found"] = True
                metadata["silver_ball_confidence"] = float(primary_silver.get("confidence", 0.0))
                metadata["silver_ball_bbox"] = primary_silver.get("bbox")
                metadata["silver_ball_origin"] = str(primary_silver.get("origin", "none"))
            else:
                metadata["silver_ball_x"] = None
                metadata["silver_ball_circle"] = None
                metadata["silver_ball_found"] = False
                metadata["silver_ball_confidence"] = 0.0
                metadata["silver_ball_bbox"] = None
                metadata["silver_ball_origin"] = (
                    "suppressed_by_black_overlap" if black_overlap_suppressed else "none"
                )
        else:
            metadata["silver_ball_x"] = None
            metadata["silver_ball_circle"] = None

        if "victims" in detectors:
            if self.dead.enabled:
                should_infer = (self.frame_counter % self.dead_every_n == 0) or (not self.dead_cache_ready)
                if should_infer:
                    found, confidence, victim_meta = self.dead.predict(processed)
                    victim_meta["cached"] = False
                    self.dead_cache = (found, confidence, victim_meta)
                    self.dead_cache_ready = True
                else:
                    found, confidence, victim_meta = self.dead_cache
                    victim_meta = dict(victim_meta)
                    victim_meta["cached"] = True
                    victim_meta["just_initialized"] = False

                if bool(victim_meta.get("just_initialized", False)):
                    ignore_benchmark_sample = True

                merged_found = bool(found) or bool(black_out.get("found", False))
                merged_conf = max(float(confidence), float(black_out.get("confidence", 0.0)))
                if merged_found:
                    victims += 1

                if bool(victim_meta.get("available", False)):
                    metadata["dead_victim"] = {
                        "found": bool(merged_found),
                        "confidence": float(merged_conf),
                        "available": True,
                        "fallback": "black_heuristic" if black_out.get("found", False) and not found else "none",
                        "dead_ball_x": metadata.get("dead_ball_x"),
                        "heuristic_black_found": bool(black_out.get("found", False)),
                        **victim_meta,
                    }
                else:
                    metadata["dead_victim"] = {
                        "found": bool(black_out.get("found", False)),
                        "confidence": float(black_out.get("confidence", 0.0)),
                        "available": False,
                        "fallback": "ball_detector_dead",
                        "dead_ball_x": metadata.get("dead_ball_x"),
                        "error": victim_meta.get("error"),
                    }
            else:
                if bool(black_out.get("found", False)):
                    victims += 1
                metadata["dead_victim"] = {
                    "found": bool(black_out.get("found", False)),
                    "confidence": float(black_out.get("confidence", 0.0)),
                    "available": False,
                    "fallback": "ball_detector_dead",
                    "dead_ball_x": metadata.get("dead_ball_x"),
                }

        status_text = self._status_text(
            state_name=state_name,
            line=line,
            green=green,
            red=red,
            balls=balls,
            victims=victims,
            metadata=metadata,
        )
        metadata["status_text"] = status_text
        self._draw_overlay(
            overlay_frame,
            state_name=state_name,
            contour=contour,
            green_contours=green_contours,
            red_contours=red_contours,
            status_text=status_text,
            metadata=metadata,
        )

        latency_ms = (time.perf_counter() - started) * 1000.0
        metadata["benchmark"] = self._update_benchmark(
            state_name,
            latency_ms,
            ignore_sample=ignore_benchmark_sample,
        )
        event = VisionDetectionEvent(
            timestamp=time.time(),
            state=state_name,
            line=bool(line),
            balls=int(balls),
            green=bool(green),
            red=bool(red),
            victims=int(victims),
            latency_ms=float(latency_ms),
            metadata=metadata,
        )
        return PipelineOutput(event=event, processed_frame=overlay_frame)

    @staticmethod
    def _draw_overlay(
        frame: np.ndarray,
        *,
        state_name: str,
        contour: np.ndarray | None,
        green_contours: list[np.ndarray],
        red_contours: list[np.ndarray],
        status_text: str,
        metadata: Mapping[str, Any],
    ) -> None:
        if frame is None or frame.size == 0:
            return

        if contour is not None and len(contour) >= 3:
            cv2.drawContours(frame, [contour], -1, (255, 255, 0), 2)
            rect = cv2.minAreaRect(contour)
            box = np.intp(cv2.boxPoints(rect))
            cv2.polylines(frame, [box], True, (255, 0, 0), 2)

        for item in green_contours:
            if item is None or len(item) < 3:
                continue
            cv2.drawContours(frame, [item], -1, (0, 220, 0), 2)
            rect = cv2.minAreaRect(item)
            box = np.intp(cv2.boxPoints(rect))
            cv2.polylines(frame, [box], True, (0, 60, 220), 1)

        for item in red_contours:
            if item is None or len(item) < 3:
                continue
            x, y, w, h = cv2.boundingRect(item)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
            cv2.rectangle(frame, (x - 2, y - 2), (x + w + 2, y + h + 2), (40, 220, 40), 1)

        silver_candidates = metadata.get("silver_ball_candidates")
        if isinstance(silver_candidates, list) and silver_candidates:
            for candidate in silver_candidates:
                if not isinstance(candidate, Mapping):
                    continue
                VisionPipelineManager._draw_labeled_bbox(
                    frame,
                    candidate.get("bbox"),
                    label="SILVER",
                    confidence=float(candidate.get("confidence", 0.0)),
                    color=(255, 229, 0),  # #00E5FF
                )
        else:
            VisionPipelineManager._draw_labeled_bbox(
                frame,
                metadata.get("silver_ball_bbox"),
                label="SILVER",
                confidence=float(metadata.get("silver_ball_confidence", 0.0)),
                color=(255, 229, 0),  # #00E5FF
            )
        VisionPipelineManager._draw_labeled_bbox(
            frame,
            metadata.get("black_ball_bbox"),
            label="BLACK",
            confidence=float(metadata.get("black_ball_confidence", 0.0)),
            color=(0, 179, 255),  # #FFB300
        )
        VisionPipelineManager._draw_labeled_bbox(
            frame,
            metadata.get("green_marker_bbox"),
            label="GREEN",
            confidence=float(metadata.get("green_marker_confidence", 0.0)),
            color=(30, 240, 80),
        )
        VisionPipelineManager._draw_labeled_bbox(
            frame,
            metadata.get("green_corner_bbox"),
            label="GREEN CORNER",
            confidence=float(metadata.get("green_corner_confidence", 0.0)),
            color=(102, 255, 0),  # #00FF66
        )
        VisionPipelineManager._draw_labeled_bbox(
            frame,
            metadata.get("red_corner_bbox"),
            label="RED CORNER",
            confidence=float(metadata.get("red_corner_confidence", 0.0)),
            color=(48, 59, 255),  # #FF3B30
        )

        cv2.putText(
            frame,
            state_name,
            (10, 24),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (90, 220, 120),
            2,
            cv2.LINE_AA,
        )
        cv2.putText(
            frame,
            status_text,
            (10, frame.shape[0] - 14),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.48,
            (220, 220, 220),
            1,
            cv2.LINE_AA,
        )

    @staticmethod
    def _draw_labeled_bbox(
        frame: np.ndarray,
        bbox: Any,
        *,
        label: str,
        confidence: float,
        color: tuple[int, int, int],
    ) -> None:
        if not isinstance(bbox, Mapping):
            return
        x = int(bbox.get("x", -1))
        y = int(bbox.get("y", -1))
        w = int(bbox.get("w", -1))
        h = int(bbox.get("h", -1))
        if x < 0 or y < 0 or w <= 0 or h <= 0:
            return
        x2 = min(frame.shape[1] - 1, x + w)
        y2 = min(frame.shape[0] - 1, y + h)
        if x2 <= x or y2 <= y:
            return

        cv2.rectangle(frame, (x, y), (x2, y2), color, 2)
        text = f"{label} {int(round(_clamp01(float(confidence)) * 100.0)):02d}%"
        (tw, th), baseline = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.42, 1)
        tx = max(2, x)
        ty = max(th + 4, y - 4)
        bx0, by0 = tx - 2, ty - th - 3
        bx1, by1 = tx + tw + 2, ty + baseline + 2
        cv2.rectangle(frame, (bx0, by0), (bx1, by1), color, thickness=-1)
        cv2.putText(frame, text, (tx, ty), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (245, 245, 245), 1, cv2.LINE_AA)

    @staticmethod
    def _status_text(
        *,
        state_name: str,
        line: bool,
        green: bool,
        red: bool,
        balls: int,
        victims: int,
        metadata: Mapping[str, Any],
    ) -> str:
        silver_ball_found = bool(metadata.get("silver_ball_found", False))
        black_ball_found = bool(metadata.get("black_ball_found", False))
        red_corner_found = bool(metadata.get("red_corner_found", False))
        green_corner_found = bool(metadata.get("green_corner_found", False))
        if state_name == RobotState.SEARCHING_LINE.value:
            return "... Searching line ..."
        if state_name == RobotState.FOLLOWING_LINE.value:
            silver_meta = metadata.get("silver_line")
            if isinstance(silver_meta, Mapping) and bool(silver_meta.get("found", False)):
                return "... Validating silver line ..."
            if green:
                return "... Green marker detected ..."
            return "... Following Line ..."
        if state_name == RobotState.VALIDATING_GAP.value:
            return "... Validating gap ..."
        if state_name == RobotState.CROSSING_GAP.value:
            return "... Crossing gap ..."
        if state_name == RobotState.VICTIM_FOUND.value:
            if victims > 0 or black_ball_found:
                return "... Picking up alive victim ..."
            if balls > 0 or silver_ball_found:
                return "... Tracking victim ..."
            return "... Searching victim ..."
        if state_name == RobotState.RESCUE_ZONE_DETECTED.value:
            if balls > 0 or silver_ball_found:
                return "... Tracking silver ball ..."
            if victims > 0 or black_ball_found:
                return "... Picking up alive victim ..."
            if red or red_corner_found:
                return "... Driving to red corner ..."
            if green_corner_found:
                return "... Driving to green corner ..."
            return "... Searching for red corner ..."
        if not line:
            return "... Searching line ..."
        return "... Following Line ..."

    def benchmark_snapshot(self) -> dict[str, dict[str, float]]:
        snapshot: dict[str, dict[str, float]] = {}
        for state_name, values in self.latency_history.items():
            if not values:
                continue
            array = np.array(values, dtype=np.float32)
            avg_ms = float(np.mean(array))
            p95_ms = float(np.percentile(array, 95))
            reduction = 0.0
            if self.baseline_monolithic_ms > 0:
                reduction = (self.baseline_monolithic_ms - avg_ms) / self.baseline_monolithic_ms * 100.0
            snapshot[state_name] = {
                "samples": float(len(array)),
                "avg_ms": avg_ms,
                "p95_ms": p95_ms,
                "baseline_monolithic_ms": float(self.baseline_monolithic_ms),
                "load_reduction_pct": float(reduction),
            }
        return snapshot

    def _update_benchmark(self, state_name: str, latency_ms: float, *, ignore_sample: bool = False) -> dict[str, float]:
        expected_ms = 0.0
        if isinstance(self.expected_by_state, Mapping):
            expected_ms = float(self.expected_by_state.get(state_name, 0.0))

        if state_name not in self._warmup_seen or ignore_sample:
            self._warmup_seen.add(state_name)
            reason = "state_warmup" if not ignore_sample else "detector_init_warmup"
            return {
                "samples": 0.0,
                "avg_ms": float(latency_ms),
                "p95_ms": float(latency_ms),
                "baseline_monolithic_ms": float(self.baseline_monolithic_ms),
                "expected_state_ms": expected_ms,
                "load_reduction_pct": 0.0,
                "warmup_ignored": 1.0,
                "warmup_reason": reason,
            }

        history = self.latency_history[state_name]
        history.append(float(latency_ms))
        array = np.array(history, dtype=np.float32)
        avg_ms = float(np.mean(array))
        p95_ms = float(np.percentile(array, 95)) if len(array) > 1 else avg_ms
        reduction = 0.0
        if self.baseline_monolithic_ms > 0:
            reduction = (self.baseline_monolithic_ms - avg_ms) / self.baseline_monolithic_ms * 100.0
        return {
            "samples": float(len(array)),
            "avg_ms": avg_ms,
            "p95_ms": p95_ms,
            "baseline_monolithic_ms": float(self.baseline_monolithic_ms),
            "expected_state_ms": expected_ms,
            "load_reduction_pct": float(reduction),
        }

    def _profile_resize(self, profile: str, *, default_w: int, default_h: int) -> tuple[int, int]:
        payload = self.config.preprocessor.get(profile, {})
        if not isinstance(payload, Mapping):
            return default_w, default_h
        resize = payload.get("resize", {})
        if not isinstance(resize, Mapping):
            return default_w, default_h
        return int(resize.get("width", default_w)), int(resize.get("height", default_h))

    @staticmethod
    def _active_detectors(payload: Any) -> list[str]:
        if isinstance(payload, list):
            out = [str(item).strip().lower() for item in payload if str(item).strip()]
            if out:
                return out
        return ["line", "red"]

    @staticmethod
    def _default_profile(state_name: str) -> str:
        if state_name in (RobotState.RESCUE_ZONE_DETECTED.value, RobotState.VICTIM_FOUND.value):
            return "rescue"
        return "line"


_MANAGER_CACHE: dict[str, VisionPipelineManager] = {}


def _coerce_config(config: VisionConfig | Mapping[str, Any] | str | Path | None) -> VisionConfig:
    if config is None:
        return load_vision_config()
    if isinstance(config, VisionConfig):
        return config
    if isinstance(config, (str, Path)):
        return load_vision_config(config)
    if isinstance(config, Mapping):
        return VisionConfig(
            data=dict(config),
            config_path=DEFAULT_CONFIG_PATH,
            project_root=_REPO_ROOT,
            cache_key=f"inline:{id(config)}",
        )
    raise TypeError(f"unsupported vision config type: {type(config)!r}")


def get_pipeline_manager(config: VisionConfig | Mapping[str, Any] | str | Path | None = None) -> VisionPipelineManager:
    resolved = _coerce_config(config)
    manager = _MANAGER_CACHE.get(resolved.cache_key)
    if manager is None:
        manager = VisionPipelineManager(resolved)
        _MANAGER_CACHE[resolved.cache_key] = manager
    return manager


def switch_pipeline(
    state: RobotState | str,
    frame_bgr: np.ndarray,
    config: VisionConfig | Mapping[str, Any] | str | Path | None,
) -> VisionDetectionEvent:
    manager = get_pipeline_manager(config)
    return manager.run(state, frame_bgr).event
