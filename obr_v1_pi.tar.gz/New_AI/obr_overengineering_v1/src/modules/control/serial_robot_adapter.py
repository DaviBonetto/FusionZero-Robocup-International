from __future__ import annotations

import glob
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol

try:
    import serial as pyserial
except ImportError:  # pragma: no cover
    pyserial = None

try:
    from ...core.event_bus import EventBus, EventTopic, LogEvent, UICommandEvent, VisionDetectionEvent
    from ...core.state_machine import RobotState
except ImportError:  # pragma: no cover
    from core.event_bus import EventBus, EventTopic, LogEvent, UICommandEvent, VisionDetectionEvent
    from core.state_machine import RobotState


class SerialTransport(Protocol):
    @property
    def port(self) -> str:
        ...

    def write(self, payload: bytes) -> int:
        ...

    def flush(self) -> None:
        ...

    def close(self) -> None:
        ...


@dataclass(slots=True)
class RobotSerialConfig:
    port: str | None = None
    baud_rate: int = 115200
    green_forward_ms: int = 5000
    green_trigger_streak: int = 2
    green_cooldown_ms: int = 6000
    min_send_interval_ms: int = 120
    auto_detect: bool = True
    dry_run: bool = False


class SerialRobotAdapter:
    AUTO_PORT_PATTERNS = (
        "/dev/serial/by-id/*",
        "/dev/ttyACM*",
        "/dev/ttyUSB*",
        "COM*",
    )

    def __init__(
        self,
        event_bus: EventBus,
        *,
        config: RobotSerialConfig,
        serial_factory: Callable[[str, int], SerialTransport] | None = None,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self._event_bus = event_bus
        self._config = config
        self._serial_factory = serial_factory or self._default_serial_factory
        self._monotonic = monotonic

        self._transport: SerialTransport | None = None
        self._resolved_port: str | None = None
        self._last_send_at = 0.0
        self._last_green_trigger_at = 0.0
        self._green_streak = 0
        self._running = False

        self._detection_sub = self._event_bus.subscribe(EventTopic.VISION_DETECTIONS, self._on_detection)
        self._ui_sub = self._event_bus.subscribe(EventTopic.UI_COMMAND, self._on_ui_command)

    @property
    def enabled(self) -> bool:
        return bool(self._config.port or self._config.auto_detect)

    @property
    def connected(self) -> bool:
        return self._transport is not None

    @property
    def resolved_port(self) -> str | None:
        return self._resolved_port

    def start(self) -> None:
        self._running = True
        if not self.enabled:
            self._publish_log("INFO", "robot serial adapter disabled")
            return
        self._ensure_transport()

    def stop(self) -> None:
        self._running = False
        try:
            self._detection_sub.unsubscribe()
        except Exception:
            pass
        try:
            self._ui_sub.unsubscribe()
        except Exception:
            pass
        self._close_transport()

    def _on_detection(self, event: VisionDetectionEvent) -> None:
        if not self._running or not isinstance(event, VisionDetectionEvent):
            return

        if event.state != RobotState.FOLLOWING_LINE.value or not bool(event.green):
            self._green_streak = 0
            return

        metadata = event.metadata if isinstance(event.metadata, Mapping) else {}
        instruction = str(metadata.get("green_instruction", "NO GREEN")).strip().upper()
        side = str(metadata.get("green_side", "NONE")).strip().upper()
        if instruction == "NO GREEN" or side == "NONE":
            self._green_streak = 0
            return

        self._green_streak += 1
        if self._green_streak < max(1, int(self._config.green_trigger_streak)):
            return

        now = self._monotonic()
        cooldown_s = max(0.0, float(self._config.green_cooldown_ms) / 1000.0)
        if (now - self._last_green_trigger_at) < cooldown_s:
            return

        self._last_green_trigger_at = now
        self._green_streak = 0
        self.send_forward(
            duration_ms=int(self._config.green_forward_ms),
            reason=f"green_detected instruction={instruction} side={side}",
            state=event.state,
        )

    def _on_ui_command(self, event: UICommandEvent) -> None:
        if not self._running or not isinstance(event, UICommandEvent):
            return

        command = str(event.command or "").strip().lower()
        params = event.params if isinstance(event.params, Mapping) else {}

        if command == "robot.forward_test":
            duration_ms = int(params.get("duration_ms", self._config.green_forward_ms))
            self.send_forward(duration_ms=duration_ms, reason="ui_manual_forward", state="MANUAL")
            return

        if command == "robot.stop":
            self.send_stop(reason="ui_manual_stop", state="MANUAL")

    def send_forward(self, *, duration_ms: int, reason: str, state: str) -> None:
        payload = f"CMD FORWARD {max(0, int(duration_ms))}\n"
        self._send_command(payload, reason=reason, state=state)

    def send_stop(self, *, reason: str, state: str) -> None:
        self._send_command("CMD STOP 0\n", reason=reason, state=state)

    def _send_command(self, payload: str, *, reason: str, state: str) -> None:
        if not self.enabled:
            return
        if not self._rate_limit_ok():
            return

        if not self._ensure_transport() and not self._config.dry_run:
            self._publish_log("WARNING", f"robot serial unavailable for command {payload.strip()}", state=state)
            return

        if self._config.dry_run:
            self._last_send_at = self._monotonic()
            self._publish_log("INFO", f"robot dry-run -> {payload.strip()} ({reason})", state=state)
            return

        transport = self._transport
        if transport is None:
            return

        try:
            transport.write(payload.encode("ascii"))
            transport.flush()
            self._last_send_at = self._monotonic()
            self._publish_log(
                "INFO",
                f"robot command -> {payload.strip()} port={self._resolved_port or transport.port} ({reason})",
                state=state,
            )
        except Exception as exc:
            self._publish_log("ERROR", f"robot serial write failed: {exc}", state=state)
            self._close_transport()

    def _rate_limit_ok(self) -> bool:
        now = self._monotonic()
        min_interval_s = max(0.0, float(self._config.min_send_interval_ms) / 1000.0)
        return (now - self._last_send_at) >= min_interval_s

    def _ensure_transport(self) -> bool:
        if self._transport is not None:
            return True

        resolved = self._resolve_port()
        if not resolved:
            self._publish_log("WARNING", "robot serial port not found")
            return False

        try:
            self._transport = self._serial_factory(resolved, int(self._config.baud_rate))
            self._resolved_port = resolved
            self._publish_log("INFO", f"robot serial connected port={resolved} baud={self._config.baud_rate}")
            return True
        except Exception as exc:
            self._resolved_port = resolved
            self._publish_log("ERROR", f"robot serial open failed on {resolved}: {exc}")
            self._transport = None
            return False

    def _resolve_port(self) -> str | None:
        explicit = (self._config.port or "").strip()
        if explicit:
            return explicit
        if not self._config.auto_detect:
            return None

        for pattern in self.AUTO_PORT_PATTERNS:
            matches = sorted(glob.glob(pattern))
            for candidate in matches:
                if Path(candidate).name.startswith("ttyS"):
                    continue
                return candidate
        return None

    def _close_transport(self) -> None:
        transport = self._transport
        self._transport = None
        if transport is None:
            return
        try:
            transport.close()
        except Exception:
            pass

    def _publish_log(self, level: str, message: str, *, state: str = "") -> None:
        try:
            self._event_bus.publish(
                EventTopic.SYSTEM_LOG,
                LogEvent(
                    level=str(level).upper(),
                    message=message,
                    source="robot_serial_adapter",
                    state=state,
                ),
            )
        except Exception:
            pass

    @staticmethod
    def _default_serial_factory(port: str, baud_rate: int) -> SerialTransport:
        if pyserial is None:
            raise RuntimeError("pyserial not installed")
        return pyserial.Serial(port=port, baudrate=int(baud_rate), timeout=0.1, write_timeout=0.2)
