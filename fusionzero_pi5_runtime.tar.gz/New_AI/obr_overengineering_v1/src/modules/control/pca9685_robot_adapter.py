from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol

try:
    from ...core.event_bus import EventBus, EventTopic, LogEvent, UICommandEvent, VisionDetectionEvent
    from ...core.state_machine import RobotState
except ImportError:  # pragma: no cover
    from core.event_bus import EventBus, EventTopic, LogEvent, UICommandEvent, VisionDetectionEvent
    from core.state_machine import RobotState


class PwmDriver(Protocol):
    def set_pwm_us(self, channel: int, pulse_us: int) -> None:
        ...

    def close(self) -> None:
        ...


@dataclass(slots=True)
class Pca9685RobotConfig:
    i2c_address: int = 0x40
    frequency_hz: int = 50
    left_channel: int = 0
    right_channel: int = 1
    min_us: int = 1000
    neutral_us: int = 1500
    max_us: int = 2000
    base_throttle_us: int = 120
    turn_gain_us: int = 220
    max_output_us: int = 360
    green_turn_us: int = 260
    green_hold_ms: int = 900
    green_trigger_streak: int = 2
    green_cooldown_ms: int = 6000
    line_confidence_floor: float = 0.18
    control_timeout_ms: int = 700
    monitor_interval_ms: int = 50
    left_inverted: bool = False
    right_inverted: bool = True
    dry_run: bool = False


class _AdafruitPca9685Driver:
    def __init__(self, config: Pca9685RobotConfig) -> None:
        try:
            import board  # type: ignore
            import busio  # type: ignore
            from adafruit_pca9685 import PCA9685  # type: ignore
        except ImportError as exc:  # pragma: no cover - depends on Pi packages
            raise RuntimeError(
                "PCA9685 dependencies missing. Install adafruit-circuitpython-pca9685 on the Raspberry Pi."
            ) from exc

        self._frequency_hz = max(1, int(config.frequency_hz))
        self._i2c = busio.I2C(board.SCL, board.SDA)
        self._pca = PCA9685(self._i2c, address=int(config.i2c_address))
        self._pca.frequency = self._frequency_hz

    def set_pwm_us(self, channel: int, pulse_us: int) -> None:
        period_us = 1_000_000.0 / float(self._frequency_hz)
        duty_cycle = int(max(0, min(0xFFFF, round((float(pulse_us) / period_us) * 0xFFFF))))
        self._pca.channels[int(channel)].duty_cycle = duty_cycle

    def close(self) -> None:
        try:
            self._pca.deinit()
        except Exception:
            pass


class Pca9685RobotAdapter:
    def __init__(
        self,
        event_bus: EventBus,
        *,
        config: Pca9685RobotConfig,
        pwm_factory: Callable[[Pca9685RobotConfig], PwmDriver] | None = None,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self._event_bus = event_bus
        self._config = config
        self._pwm_factory = pwm_factory or _AdafruitPca9685Driver
        self._monotonic = monotonic

        self._driver: PwmDriver | None = None
        self._running = False
        self._estop_latched = False
        self._failsafe_active = False
        self._green_streak = 0
        self._last_green_trigger_at = 0.0
        self._last_detection_at = 0.0
        self._last_command_at = 0.0
        self._manual_until = 0.0
        self._maneuver_until = 0.0
        self._control_mode = "STOPPED"
        self._assist_kind = "none"
        self._line_error = 0.0
        self._pid_output = 0.0
        self._obstacle_state = "CLEAR"
        self._green_instruction = "NO_GREEN"
        self._last_left_us = int(config.neutral_us)
        self._last_right_us = int(config.neutral_us)
        self._last_event_line = ""
        self._last_event_at = 0.0

        self._lock = threading.RLock()
        self._monitor_stop = threading.Event()
        self._monitor_thread: threading.Thread | None = None
        self._detection_sub = self._event_bus.subscribe(EventTopic.VISION_DETECTIONS, self._on_detection)
        self._ui_sub = self._event_bus.subscribe(EventTopic.UI_COMMAND, self._on_ui_command)

    @property
    def connected(self) -> bool:
        return self._config.dry_run or self._driver is not None

    def start(self) -> None:
        with self._lock:
            self._running = True
            if self._config.dry_run:
                self._publish_log("INFO", "pca9685 robot adapter running in dry-run mode")
            else:
                self._driver = self._pwm_factory(self._config)
                self._publish_log(
                    "INFO",
                    f"pca9685 connected address=0x{self._config.i2c_address:02x} freq={self._config.frequency_hz}",
                )
            self._neutralize_locked(mode="STOPPED", assist_kind="none", failsafe=False)

        self._monitor_stop.clear()
        self._monitor_thread = threading.Thread(target=self._monitor_loop, name="pca9685-robot-monitor", daemon=True)
        self._monitor_thread.start()

    def stop(self) -> None:
        self._monitor_stop.set()
        if self._monitor_thread is not None:
            self._monitor_thread.join(timeout=1.0)
        self._monitor_thread = None

        try:
            self.request_safe_stop(reason="adapter_shutdown", state="SHUTDOWN", emergency=False)
        except Exception:
            pass

        with self._lock:
            self._running = False
            driver = self._driver
            self._driver = None

        try:
            self._detection_sub.unsubscribe()
        except Exception:
            pass
        try:
            self._ui_sub.unsubscribe()
        except Exception:
            pass
        if driver is not None:
            driver.close()

    def request_safe_stop(self, *, reason: str, state: str, emergency: bool, force: bool = True) -> bool:
        del force
        with self._lock:
            if emergency:
                self._estop_latched = True
                self._failsafe_active = True
            self._last_event_line = f"{'ESTOP' if emergency else 'STOP'} {reason}"
            self._last_event_at = self._monotonic()
            self._neutralize_locked(
                mode="ESTOP" if emergency else "STOPPED",
                assist_kind="estop" if emergency else "stop",
                failsafe=emergency,
            )
        self._publish_log("WARNING" if emergency else "INFO", f"pca9685 {'estop' if emergency else 'stop'} ({reason})", state=state)
        return True

    def send_stop(self, *, reason: str, state: str, force: bool = True) -> bool:
        return self.request_safe_stop(reason=reason, state=state, emergency=False, force=force)

    def send_estop(self, *, reason: str, state: str, force: bool = True) -> bool:
        return self.request_safe_stop(reason=reason, state=state, emergency=True, force=force)

    def clear_estop(self, *, reason: str, state: str) -> bool:
        with self._lock:
            self._estop_latched = False
            self._failsafe_active = False
            self._neutralize_locked(mode="STOPPED", assist_kind="clear_estop", failsafe=False)
        self._publish_log("INFO", f"pca9685 estop cleared ({reason})", state=state)
        return True

    def status_payload(self) -> dict[str, Any]:
        with self._lock:
            state = "dry-run" if self._config.dry_run else ("connected" if self._driver is not None else "waiting")
            telemetry = {
                "mode": self._control_mode,
                "line_error": round(float(self._line_error), 4),
                "pid": round(float(self._pid_output), 2),
                "green": self._green_instruction,
                "obstacle": self._obstacle_state,
                "failsafe": bool(self._failsafe_active or self._estop_latched),
                "left_pwm": int(self._last_left_us),
                "right_pwm": int(self._last_right_us),
            }
            return {
                "state": state,
                "connected": bool(self.connected),
                "port": f"i2c:0x{self._config.i2c_address:02x}",
                "backend": "pca9685",
                "heartbeat_ok": not bool(self._failsafe_active),
                "heartbeat_age_ms": None,
                "telemetry_age_ms": None
                if self._last_command_at <= 0
                else int(max(0.0, (self._monotonic() - self._last_command_at) * 1000.0)),
                "ack": "PWM",
                "ack_age_ms": None,
                "event": self._last_event_line,
                "event_age_ms": None
                if self._last_event_at <= 0
                else int(max(0.0, (self._monotonic() - self._last_event_at) * 1000.0)),
                "assist_kind": self._assist_kind,
                "control_mode": self._control_mode,
                "line_error": self._line_error,
                "pid_output": self._pid_output,
                "obstacle_state": self._obstacle_state,
                "green_instruction": self._green_instruction,
                "failsafe": bool(self._failsafe_active or self._estop_latched),
                "telemetry": telemetry,
            }

    def latest_telemetry(self) -> dict[str, Any]:
        return dict(self.status_payload().get("telemetry", {}))

    def _on_detection(self, event: VisionDetectionEvent) -> None:
        if not self._running or not isinstance(event, VisionDetectionEvent):
            return

        metadata = event.metadata if isinstance(event.metadata, Mapping) else {}
        with self._lock:
            if self._estop_latched:
                self._neutralize_locked(mode="ESTOP", assist_kind="estop", failsafe=True)
                return

            self._last_detection_at = self._monotonic()
            if self._maybe_handle_obstacle_locked(event.state, metadata):
                return
            if self._maybe_handle_green_locked(event, metadata):
                return
            if self._maneuver_until > self._monotonic():
                return
            if event.state != RobotState.FOLLOWING_LINE.value or not bool(event.line):
                self._green_streak = 0
                self._neutralize_locked(mode="STOPPED", assist_kind="line_lost", failsafe=False)
                return

            confidence = float(metadata.get("line_confidence", 0.0) or 0.0)
            if confidence < float(self._config.line_confidence_floor):
                return

            offset = max(-1.0, min(1.0, float(metadata.get("line_offset_norm", 0.0) or 0.0)))
            correction = offset * float(self._config.turn_gain_us)
            left_speed = float(self._config.base_throttle_us) - correction
            right_speed = float(self._config.base_throttle_us) + correction
            self._apply_drive_locked(
                left_speed_us=left_speed,
                right_speed_us=right_speed,
                mode="FOLLOW_LINE",
                assist_kind="line",
                line_error=offset,
                pid_output=correction,
            )

    def _on_ui_command(self, event: UICommandEvent) -> None:
        if not self._running or not isinstance(event, UICommandEvent):
            return
        command = str(event.command or "").strip().lower()
        params = event.params if isinstance(event.params, Mapping) else {}

        with self._lock:
            if command == "robot.forward_test" and not self._estop_latched:
                duration_ms = max(1, int(params.get("duration_ms", 1200)))
                now = self._monotonic()
                self._manual_until = now + (duration_ms / 1000.0)
                self._apply_drive_locked(
                    left_speed_us=float(self._config.base_throttle_us),
                    right_speed_us=float(self._config.base_throttle_us),
                    mode="MANUAL",
                    assist_kind="forward_test",
                    line_error=0.0,
                    pid_output=0.0,
                )
                return
            if command == "robot.stop":
                self._neutralize_locked(mode="STOPPED", assist_kind="stop", failsafe=False)
                return
            if command in {"robot.force_stop", "robot.estop"}:
                self._estop_latched = True
                self._failsafe_active = True
                self._neutralize_locked(mode="ESTOP", assist_kind="estop", failsafe=True)
                return
            if command in {"robot.clear_estop", "robot.reset_estop"}:
                self._estop_latched = False
                self._failsafe_active = False
                self._neutralize_locked(mode="STOPPED", assist_kind="clear_estop", failsafe=False)
                return
            if command in {"robot.obstacle_test", "robot.obstacle_ahead"}:
                self._obstacle_state = "TEST" if command == "robot.obstacle_test" else "AHEAD"
                self._neutralize_locked(mode="OBSTACLE", assist_kind="obstacle", failsafe=False)
                return
            if command in {"robot.obstacle_clear", "robot.clear_obstacle"}:
                self._obstacle_state = "CLEAR"
                self._neutralize_locked(mode="STOPPED", assist_kind="obstacle_clear", failsafe=False)

    def _maybe_handle_obstacle_locked(self, state: str, metadata: Mapping[str, Any]) -> bool:
        del state
        raw = metadata.get("obstacle")
        if isinstance(raw, Mapping):
            obstacle_state = str(raw.get("state", "CLEAR")).strip().upper()
        else:
            obstacle_state = str(metadata.get("obstacle_state", "")).strip().upper()
        if not obstacle_state:
            return False
        self._obstacle_state = obstacle_state
        if obstacle_state != "CLEAR":
            self._neutralize_locked(mode="OBSTACLE", assist_kind="obstacle", failsafe=False)
            return True
        return False

    def _maybe_handle_green_locked(self, event: VisionDetectionEvent, metadata: Mapping[str, Any]) -> bool:
        if not bool(event.green):
            self._green_streak = 0
            return False
        instruction = str(metadata.get("green_instruction", "NO_GREEN")).strip().upper().replace(" ", "_")
        side = str(metadata.get("green_side", "NONE")).strip().upper()
        if instruction in {"", "NO_GREEN", "NONE"} or side == "NONE":
            self._green_streak = 0
            return False

        self._green_streak += 1
        if self._green_streak < max(1, int(self._config.green_trigger_streak)):
            return False

        now = self._monotonic()
        cooldown_s = max(0.0, float(self._config.green_cooldown_ms) / 1000.0)
        if (now - self._last_green_trigger_at) < cooldown_s:
            return False

        if "MEIA" in instruction or side == "BOTH":
            left_speed = float(self._config.green_turn_us)
            right_speed = -float(self._config.green_turn_us)
        elif side == "LEFT":
            left_speed = -float(self._config.green_turn_us)
            right_speed = float(self._config.green_turn_us)
        else:
            left_speed = float(self._config.green_turn_us)
            right_speed = -float(self._config.green_turn_us)

        self._green_instruction = instruction
        self._last_green_trigger_at = now
        self._green_streak = 0
        self._maneuver_until = now + (max(0, int(self._config.green_hold_ms)) / 1000.0)
        self._apply_drive_locked(
            left_speed_us=left_speed,
            right_speed_us=right_speed,
            mode="GREEN",
            assist_kind="green",
            line_error=0.0,
            pid_output=0.0,
        )
        return True

    def _monitor_loop(self) -> None:
        interval = max(0.02, float(self._config.monitor_interval_ms) / 1000.0)
        while not self._monitor_stop.wait(interval):
            with self._lock:
                if not self._running or self._estop_latched:
                    continue
                now = self._monotonic()
                if self._manual_until > 0 and now >= self._manual_until:
                    self._manual_until = 0.0
                    self._neutralize_locked(mode="STOPPED", assist_kind="manual_timeout", failsafe=False)
                    continue
                if self._maneuver_until > 0 and now >= self._maneuver_until:
                    self._maneuver_until = 0.0
                    self._neutralize_locked(mode="STOPPED", assist_kind="green_timeout", failsafe=False)
                    continue
                timeout_s = max(0.1, float(self._config.control_timeout_ms) / 1000.0)
                if self._control_mode == "FOLLOW_LINE" and self._last_detection_at > 0 and (now - self._last_detection_at) > timeout_s:
                    self._neutralize_locked(mode="STOPPED", assist_kind="detection_timeout", failsafe=False)

    def _apply_drive_locked(
        self,
        *,
        left_speed_us: float,
        right_speed_us: float,
        mode: str,
        assist_kind: str,
        line_error: float,
        pid_output: float,
    ) -> None:
        left_pulse = self._pulse_for_speed(left_speed_us, inverted=bool(self._config.left_inverted))
        right_pulse = self._pulse_for_speed(right_speed_us, inverted=bool(self._config.right_inverted))
        self._set_pair_locked(left_pulse, right_pulse)
        self._control_mode = mode
        self._assist_kind = assist_kind
        self._line_error = float(line_error)
        self._pid_output = float(pid_output)
        self._failsafe_active = False
        self._last_command_at = self._monotonic()

    def _neutralize_locked(self, *, mode: str, assist_kind: str, failsafe: bool) -> None:
        self._set_pair_locked(int(self._config.neutral_us), int(self._config.neutral_us))
        self._control_mode = mode
        self._assist_kind = assist_kind
        self._line_error = 0.0
        self._pid_output = 0.0
        self._failsafe_active = bool(failsafe)
        self._last_command_at = self._monotonic()

    def _set_pair_locked(self, left_us: int, right_us: int) -> None:
        left_us = self._clamp_pulse(left_us)
        right_us = self._clamp_pulse(right_us)
        self._last_left_us = left_us
        self._last_right_us = right_us
        if self._config.dry_run:
            return
        if self._driver is None:
            raise RuntimeError("PCA9685 driver unavailable")
        self._driver.set_pwm_us(int(self._config.left_channel), left_us)
        self._driver.set_pwm_us(int(self._config.right_channel), right_us)

    def _pulse_for_speed(self, speed_us: float, *, inverted: bool) -> int:
        max_output = min(
            abs(int(self._config.max_output_us)),
            abs(int(self._config.max_us) - int(self._config.neutral_us)),
            abs(int(self._config.neutral_us) - int(self._config.min_us)),
        )
        signed = max(-max_output, min(max_output, float(speed_us)))
        if inverted:
            signed = -signed
        return self._clamp_pulse(round(float(self._config.neutral_us) + signed))

    def _clamp_pulse(self, value: int) -> int:
        return int(max(int(self._config.min_us), min(int(self._config.max_us), int(value))))

    def _publish_log(self, level: str, message: str, *, state: str = "") -> None:
        try:
            self._event_bus.publish(
                EventTopic.SYSTEM_LOG,
                LogEvent(
                    timestamp=time.time(),
                    level=str(level).upper(),
                    message=str(message),
                    source="pca9685_robot_adapter",
                    state=str(state),
                ),
            )
        except Exception:
            pass
