from __future__ import annotations

import argparse
import math
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable, Mapping

import cv2
import psutil

if __package__ in (None, ""):
    PROJECT_ROOT = Path(__file__).resolve().parents[1]
    SRC_ROOT = Path(__file__).resolve().parent
    if str(PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(PROJECT_ROOT))
    if str(SRC_ROOT) not in sys.path:
        sys.path.insert(0, str(SRC_ROOT))

    from src.core.event_bus import EventBus, EventTopic, HealthEvent, LogEvent, PoseEvent, UICommandEvent, VisionDetectionEvent
    from src.core.state_machine import RobotEvent, RobotState, StateMachine
    from src.remote_dashboard import RemoteDashboardServer
    from src.modules.control import Pca9685RobotAdapter, Pca9685RobotConfig, RobotSerialConfig, SerialRobotAdapter
    from src.modules.vision.vision_node import VisionNode
    from src.ops_profiles import OpsProfile, OpsProfileCatalog, load_ops_profile_catalog
    from src.session_recording import SessionRecorder
else:
    from .core.event_bus import EventBus, EventTopic, HealthEvent, LogEvent, PoseEvent, UICommandEvent, VisionDetectionEvent
    from .core.state_machine import RobotEvent, RobotState, StateMachine
    from .remote_dashboard import RemoteDashboardServer
    from .modules.control import Pca9685RobotAdapter, Pca9685RobotConfig, RobotSerialConfig, SerialRobotAdapter
    from .modules.vision.vision_node import VisionNode
    from .ops_profiles import OpsProfile, OpsProfileCatalog, load_ops_profile_catalog
    from .session_recording import SessionRecorder


class LiveDashboardRunner:
    def __init__(
        self,
        *,
        camera_index: int,
        camera_width: int,
        camera_height: int,
        camera_fps: int,
        config_path: str | Path | None = None,
        robot_serial_port: str | None = None,
        robot_baud: int = 115200,
        robot_green_forward_ms: int = 5000,
        robot_green_streak: int = 2,
        robot_green_cooldown_ms: int = 6000,
        robot_green_hold_ms: int = 900,
        robot_obstacle_hold_ms: int = 1200,
        robot_dry_run: bool = False,
        robot_backend: str = "serial",
        pca9685_i2c_address: int = 0x40,
        pca9685_frequency_hz: int = 50,
        pca9685_left_channel: int = 0,
        pca9685_right_channel: int = 1,
        pca9685_min_us: int = 1000,
        pca9685_neutral_us: int = 1500,
        pca9685_max_us: int = 2000,
        pca9685_base_throttle_us: int = 120,
        pca9685_turn_gain_us: int = 220,
        pca9685_max_output_us: int = 360,
        pca9685_green_turn_us: int = 260,
        pca9685_left_inverted: bool = False,
        pca9685_right_inverted: bool = True,
        profile_name: str | None = None,
        recordings_root: str | Path | None = None,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self.camera_index = int(camera_index)
        self.camera_width = int(camera_width)
        self.camera_height = int(camera_height)
        self.camera_fps = max(1, int(camera_fps))
        self.config_path = config_path
        self._monotonic = monotonic
        self._profile_catalog: OpsProfileCatalog = load_ops_profile_catalog(config_path)
        self._active_profile_name = "custom"
        self._active_profile: OpsProfile | None = None
        self._recording_auto_start = False
        self._last_detection_latency_ms = 0.0
        self._camera_backend_name = ""
        self._display_turn_gain_us = float(pca9685_turn_gain_us)
        self._last_power_sample_at = 0.0
        self._power_status_cache: dict[str, Any] = {
            "available": False,
            "status": "unknown",
            "summary": "vcgencmd unavailable",
            "undervoltage_now": False,
            "undervoltage_occurred": False,
            "throttled_now": False,
            "throttled_occurred": False,
            "raw_value": "",
        }

        self.bus = EventBus(max_queue_size=2048, drop_oldest=True)
        self.fsm = StateMachine(event_bus=self.bus)
        self.vision = VisionNode(
            self.bus,
            config=config_path,
            publish_raw_frame=True,
            publish_processed_frame=True,
        )
        self._robot_backend = str(robot_backend or "serial").strip().lower().replace("-", "_")
        if self._robot_backend == "pca9685":
            self.robot = Pca9685RobotAdapter(
                self.bus,
                config=Pca9685RobotConfig(
                    i2c_address=int(pca9685_i2c_address),
                    frequency_hz=int(pca9685_frequency_hz),
                    left_channel=int(pca9685_left_channel),
                    right_channel=int(pca9685_right_channel),
                    min_us=int(pca9685_min_us),
                    neutral_us=int(pca9685_neutral_us),
                    max_us=int(pca9685_max_us),
                    base_throttle_us=int(pca9685_base_throttle_us),
                    turn_gain_us=int(pca9685_turn_gain_us),
                    max_output_us=int(pca9685_max_output_us),
                    green_turn_us=int(pca9685_green_turn_us),
                    green_hold_ms=int(robot_green_hold_ms),
                    green_trigger_streak=int(robot_green_streak),
                    green_cooldown_ms=int(robot_green_cooldown_ms),
                    left_inverted=bool(pca9685_left_inverted),
                    right_inverted=bool(pca9685_right_inverted),
                    dry_run=bool(robot_dry_run),
                ),
                monotonic=monotonic,
            )
        else:
            self._robot_backend = "serial"
            self.robot = SerialRobotAdapter(
                self.bus,
                config=RobotSerialConfig(
                    port=(str(robot_serial_port).strip() if robot_serial_port else None),
                    baud_rate=int(robot_baud),
                    green_forward_ms=int(robot_green_forward_ms),
                    green_trigger_streak=int(robot_green_streak),
                    green_cooldown_ms=int(robot_green_cooldown_ms),
                    green_hold_ms=int(robot_green_hold_ms),
                    obstacle_hold_ms=int(robot_obstacle_hold_ms),
                    dry_run=bool(robot_dry_run),
                ),
            )
        self.session_recorder = SessionRecorder(
            self.bus,
            output_root=recordings_root,
            default_options=self._profile_catalog.default_recording,
        )

        self._capture_lock = threading.RLock()
        self._capture: Any = None
        self._stop_event = threading.Event()
        self._worker: threading.Thread | None = None
        self._safety_worker: threading.Thread | None = None

        self._frame_id = 0
        self._last_capture_ts = 0.0
        self._fps_capture = 0.0
        self._last_health_ts = 0.0
        self._last_no_camera_log = 0.0
        self._last_camera_ok_at = self._monotonic()
        self._last_vision_ok_at = self._monotonic()
        self._last_detection_at = self._monotonic()
        self._camera_timeout_s = 1.0
        self._fsm_stall_timeout_s = 1.2
        self._vision_fresh_window_s = 0.5
        self._camera_fault_active = False
        self._fsm_fault_active = False
        self._camera_read_fail_streak = 0
        self._camera_read_fail_threshold = 8
        self._camera_reopen_backoff_s = 0.25

        self._line_lost_streak = 0
        self._line_found_streak = 0
        self._pose_x = 0.0
        self._pose_y = 0.0
        self._pose_theta = 0.0

        self._subs = [
            self.bus.subscribe(EventTopic.VISION_DETECTIONS, self._on_detection),
            self.bus.subscribe(EventTopic.UI_COMMAND, self._on_ui_command),
        ]
        if profile_name:
            self._apply_profile(profile_name, source="startup")

    def start(self) -> None:
        self._stop_event.clear()
        now = self._monotonic()
        self._last_camera_ok_at = now
        self._last_vision_ok_at = now
        self._last_detection_at = now
        self._camera_fault_active = False
        self._fsm_fault_active = False
        self._camera_read_fail_streak = 0
        self._open_camera()
        self.robot.start()
        if self._recording_auto_start and not self.session_recorder.status_payload()["enabled"]:
            self.session_recorder.start(reason="profile_auto_start", context=self._session_context())
        self._worker = threading.Thread(target=self._capture_loop, name="live-dashboard-capture", daemon=True)
        self._worker.start()
        self._safety_worker = threading.Thread(target=self._safety_loop, name="live-dashboard-safety", daemon=True)
        self._safety_worker.start()
        self._publish_log(
            "INFO",
            (
                f"live runner started cam={self.camera_index} "
                f"{self.camera_width}x{self.camera_height}@{self.camera_fps} "
                f"profile={self._active_profile_name}"
            ),
        )

    def stop(self) -> None:
        self._stop_event.set()
        self._request_safe_stop("runner_shutdown", emergency=False)
        if self._worker is not None:
            self._worker.join(timeout=2.0)
        self._worker = None
        if self._safety_worker is not None:
            self._safety_worker.join(timeout=2.0)
        self._safety_worker = None

        for sub in self._subs:
            try:
                sub.unsubscribe()
            except Exception:
                pass
        self._subs.clear()

        self._release_camera()
        self.robot.stop()
        self.session_recorder.close()
        self.vision.close()
        self.bus.stop()

    def _capture_loop(self) -> None:
        try:
            while not self._stop_event.is_set():
                cap = self._get_capture()
                if cap is None:
                    now = self._monotonic()
                    if now - self._last_no_camera_log >= 2.0:
                        self._last_no_camera_log = now
                        self._publish_log("WARNING", f"camera {self.camera_index} unavailable, retrying")
                    self._open_camera()
                    time.sleep(0.2)
                    continue

                ok, frame = cap.read()
                if not ok or frame is None:
                    reopened = self._handle_capture_read_failure()
                    time.sleep(self._camera_reopen_backoff_s if reopened else 0.03)
                    continue

                self._handle_capture_read_success()
                self._last_camera_ok_at = self._monotonic()
                ts = time.time()
                self._frame_id += 1
                try:
                    self.vision.process_frame(frame, frame_id=self._frame_id, timestamp=ts)
                    self._last_vision_ok_at = self._monotonic()
                except Exception as exc:
                    self._publish_log("ERROR", f"vision process failed: {exc}")
                    time.sleep(0.01)
                    continue

                self._update_capture_fps()
                self._publish_health_if_due()
        except Exception as exc:
            self._publish_log("ERROR", f"capture loop crashed: {exc}")
            self._request_safe_stop("capture_loop_crash", emergency=True)
            self._stop_event.set()

    def _safety_loop(self) -> None:
        while not self._stop_event.wait(0.1):
            try:
                self._evaluate_safety()
            except Exception as exc:
                self._publish_log("ERROR", f"safety monitor failed: {exc}")
                self._request_safe_stop("safety_monitor_failure", emergency=True)
                self._stop_event.set()
                return

    def _evaluate_safety(self) -> None:
        now = self._monotonic()

        if (now - self._last_vision_ok_at) > self._camera_timeout_s:
            if not self._camera_fault_active:
                self._camera_fault_active = True
                self._publish_log("ERROR", "camera/vision heartbeat lost; issuing safe STOP")
                self._request_safe_stop("camera_timeout", emergency=False)
        elif self._camera_fault_active:
            self._camera_fault_active = False
            self._publish_log("INFO", "camera/vision heartbeat restored")

        detection_stale = (now - self._last_detection_at) > self._fsm_stall_timeout_s
        vision_fresh = (now - self._last_vision_ok_at) <= self._vision_fresh_window_s
        if self._frame_id > 0 and vision_fresh and detection_stale:
            if not self._fsm_fault_active:
                self._fsm_fault_active = True
                self._publish_log("ERROR", "fsm/detection pipeline stalled; issuing ESTOP")
                self._request_safe_stop("fsm_stall", emergency=True)
        elif self._fsm_fault_active and not detection_stale:
            self._fsm_fault_active = False
            self._publish_log("INFO", "fsm/detection pipeline recovered")

        if not self._is_valid_state_object(self.fsm.state):
            self._publish_log("ERROR", f"invalid fsm state object: {self.fsm.state!r}")
            self._request_safe_stop("invalid_fsm_state", emergency=True)

    def _on_detection(self, event: VisionDetectionEvent) -> None:
        if not isinstance(event, VisionDetectionEvent):
            return
        self._last_detection_at = self._monotonic()
        self._last_detection_latency_ms = max(0.0, float(event.latency_ms))
        if self._fsm_fault_active:
            self._fsm_fault_active = False
            self._publish_log("INFO", "fsm/detection pipeline recovered")
        if not self._is_valid_state_name(event.state):
            self._publish_log("ERROR", f"invalid detection state received: {event.state!r}")
            self._request_safe_stop("invalid_detection_state", emergency=True)
            return
        if not self._is_valid_state_object(self.fsm.state):
            self._publish_log("ERROR", f"invalid fsm state object: {self.fsm.state!r}")
            self._request_safe_stop("invalid_fsm_state", emergency=True)
            return

        self._inject_telemetry(event)
        self._publish_pose(event)

        trigger: RobotEvent | None = None
        reason = "vision_live"

        if event.red:
            trigger = RobotEvent.ON_RESCUE_RED_DETECTED
        elif event.victims > 0:
            trigger = RobotEvent.ON_VICTIM_DETECTED
        elif event.line:
            self._line_found_streak += 1
            self._line_lost_streak = 0
            if self.fsm.state in {
                RobotState.SEARCHING_LINE,
                RobotState.VALIDATING_GAP,
                RobotState.CROSSING_GAP,
            }:
                trigger = RobotEvent.ON_LINE_FOUND
            elif self.fsm.state == RobotState.FOLLOWING_LINE and event.green:
                trigger = RobotEvent.ON_INTERSECTION
        else:
            self._line_lost_streak += 1
            self._line_found_streak = 0
            if self.fsm.state == RobotState.FOLLOWING_LINE and self._line_lost_streak == 1:
                trigger = RobotEvent.ON_GAP
                reason = "line_gap_suspected"
            elif self._line_lost_streak >= 3:
                trigger = RobotEvent.ON_LINE_LOST
                reason = "line_lost_streak"

        if trigger is None:
            return
        try:
            next_state = self.fsm.handle(trigger, payload={"reason": reason})
            if not isinstance(next_state, RobotState):
                self._publish_log("ERROR", f"invalid fsm state returned: {next_state!r}")
                self._request_safe_stop("invalid_fsm_state", emergency=True)
        except Exception as exc:
            self._publish_log("ERROR", f"fsm handle failed: {exc}")
            self._request_safe_stop("fsm_handle_failure", emergency=True)

    def _on_ui_command(self, event: UICommandEvent) -> None:
        if not isinstance(event, UICommandEvent):
            return
        command = str(event.command or "").strip().lower()
        params = event.params if isinstance(event.params, Mapping) else {}

        if command == "tuning.update":
            key = str(params.get("key", "")).strip()
            value = params.get("value")
            if key:
                self._apply_tuning(key, value)
            return

        if command == "config.load_profile":
            profile_name = str(params.get("profile", "")).strip().lower()
            if profile_name:
                self._apply_profile(profile_name, source="ui")
            return

        if command == "camera.reconnect":
            self.camera_index = int(params.get("index", self.camera_index))
            self.camera_width = int(params.get("width", self.camera_width))
            self.camera_height = int(params.get("height", self.camera_height))
            self.camera_fps = max(1, int(params.get("fps", self.camera_fps)))
            self._reset_camera_runtime_state()
            self._open_camera()
            self._publish_log(
                "INFO",
                f"camera reconfigured idx={self.camera_index} {self.camera_width}x{self.camera_height}@{self.camera_fps}",
            )
            return

        if command == "fsm.force_mode":
            mode = str(params.get("mode", "")).strip().lower()
            if mode == "line":
                trigger = RobotEvent.ON_LINE_FOUND
            elif mode == "rescue":
                trigger = RobotEvent.ON_RESCUE_RED_DETECTED
            else:
                self._publish_log("WARNING", f"unknown mode request: {mode!r}")
                return
            try:
                next_state = self.fsm.handle(trigger, payload={"reason": f"ui_force_mode:{mode}"})
                if not isinstance(next_state, RobotState):
                    self._publish_log("ERROR", f"invalid fsm state returned: {next_state!r}")
                    self._request_safe_stop("invalid_fsm_state", emergency=True)
                    return
                self._publish_log("INFO", f"fsm forced to {self._state_value()} via {mode}")
            except Exception as exc:
                self._publish_log("ERROR", f"fsm force mode failed: {exc}")
                self._request_safe_stop("fsm_force_mode_failure", emergency=True)
            return

        if command == "session.recording.configure":
            options = self.session_recorder.configure(params)
            self._publish_log("INFO", f"session recording configured {options.to_payload()}")
            return

        if command == "session.recording.start":
            self.session_recorder.configure(params)
            session_dir = self.session_recorder.start(reason="ui", context=self._session_context())
            self._publish_log("INFO", f"session recording started dir={session_dir}")
            return

        if command == "session.recording.stop":
            self.session_recorder.stop(reason="ui")
            self._publish_log("INFO", "session recording stopped")

    def _apply_tuning(self, key: str, value: object) -> None:
        manager = self.vision._pipeline
        line = manager.line_detector
        color = manager.color_detector
        ball = manager.ball_detector

        try:
            if key == "line.black_v_max":
                line.black_v_max = int(value)
            elif key == "line.black_s_max":
                line.black_s_max = int(value)
            elif key == "line.min_area":
                line.min_black_area = int(value)
            elif key == "line.erode_iter":
                line.erode_iter = int(value)
            elif key == "line.dilate_iter":
                line.dilate_iter = int(value)
            elif key == "green.h_min":
                color.green_h_min = int(value)
            elif key == "green.h_max":
                color.green_h_max = int(value)
            elif key == "green.s_min":
                color.green_s_min = int(value)
            elif key == "green.v_min":
                color.green_v_min = int(value)
            elif key == "green.min_area":
                color.green_min_area = float(value)
            elif key == "red.h1_min":
                color.red_h1_min = int(value)
            elif key == "red.h1_max":
                color.red_h1_max = int(value)
            elif key == "red.h2_min":
                color.red_h2_min = int(value)
            elif key == "red.h2_max":
                color.red_h2_max = int(value)
            elif key == "red.s_min":
                color.red_s_min = int(value)
            elif key == "red.v_min":
                color.red_v_min = int(value)
            elif key == "red.min_area":
                color.red_min_area = float(value)
            elif key == "silver.conf":
                manager.silver.threshold = float(value)
            elif key == "silver.blur":
                blur = max(3, int(value))
                ball.silver_blur = blur if blur % 2 == 1 else blur + 1
            elif key == "dead.black_v_max":
                v = max(0, min(255, int(value)))
                ball.dead_black_threshold = (v, v, v)
            else:
                return
            self._publish_log("INFO", f"tuning applied {key}={value}")
        except Exception as exc:
            self._publish_log("ERROR", f"failed tuning {key}: {exc}")

    def _inject_telemetry(self, event: VisionDetectionEvent) -> None:
        metadata = event.metadata if isinstance(event.metadata, dict) else {}
        serial_status = self._serial_status_payload()
        telemetry = serial_status.get("telemetry", {}) if isinstance(serial_status, Mapping) else {}
        if not isinstance(telemetry, Mapping) or not telemetry:
            angle = float(metadata.get("line_angle_deg", 90.0))
            front = max(120, int(1200 - abs(angle - 90.0) * 8.0))
            left = max(100, int(900 + (angle - 90.0) * 9.0))
            right = max(100, int(900 - (angle - 90.0) * 9.0))
            back = 1400 if event.line else max(250, int(500 + self._line_lost_streak * 120))
            telemetry = {
                "front": front,
                "left": left,
                "right": right,
                "back": back,
                "yaw": round(self._pose_theta * 180.0 / math.pi, 2),
                "roll": round(math.sin(time.monotonic() * 0.7) * 4.0, 2),
                "pitch": round(math.cos(time.monotonic() * 0.6) * 4.0, 2),
                "gripper": 90 if event.victims == 0 else 1400,
            }
        else:
            telemetry = dict(telemetry)
            if "heading_deg" in telemetry and "yaw" not in telemetry:
                telemetry["yaw"] = telemetry["heading_deg"]
        metadata["telemetry"] = telemetry
        line_error, pid_output = self._display_line_control(event, metadata, serial_status)
        metadata["control"] = {
            "control_mode": str(serial_status.get("control_mode", "")).strip(),
            "line_error": line_error,
            "pid_output": pid_output,
            "obstacle_state": str(serial_status.get("obstacle_state", "")).strip(),
            "green_instruction": str(serial_status.get("green_instruction", "")).strip(),
            "failsafe": bool(serial_status.get("failsafe", False)),
            "assist_kind": str(serial_status.get("assist_kind", "none")).strip(),
            "vision_confidence": float(metadata.get("line_confidence", 0.0) or 0.0),
        }
        metadata["serial"] = serial_status
        metadata["robot"] = serial_status
        event.metadata = metadata

    def _display_line_control(
        self,
        event: VisionDetectionEvent,
        metadata: Mapping[str, Any],
        robot_status: Mapping[str, Any],
    ) -> tuple[object, object]:
        line_error = robot_status.get("line_error")
        pid_output = robot_status.get("pid_output")
        mode = str(robot_status.get("control_mode", "")).strip().upper()
        confidence = float(metadata.get("line_confidence", 0.0) or 0.0)
        if bool(event.line) and confidence > 0.0 and mode not in {"FOLLOW_LINE", "GREEN", "MANUAL"}:
            offset = float(metadata.get("line_offset_norm", 0.0) or 0.0)
            line_error = round(max(-1.0, min(1.0, offset)), 4)
            pid_output = round(float(line_error) * float(self._display_turn_gain_us), 2)
        return line_error, pid_output

    def _reset_camera_runtime_state(self) -> None:
        now = self._monotonic()
        self._frame_id = 0
        self._last_capture_ts = 0.0
        self._fps_capture = 0.0
        self._last_camera_ok_at = now
        self._last_vision_ok_at = now
        self._last_detection_at = now
        self._camera_fault_active = False
        self._fsm_fault_active = False
        self._camera_read_fail_streak = 0
        self._line_lost_streak = 0
        self._line_found_streak = 0

    def _publish_pose(self, event: VisionDetectionEvent) -> None:
        angle_deg = float(event.metadata.get("line_angle_deg", 90.0)) if isinstance(event.metadata, Mapping) else 90.0
        self._pose_theta = math.radians(max(0.0, min(180.0, angle_deg)) - 90.0)
        step = 0.012 if event.line else 0.004
        self._pose_x += math.cos(self._pose_theta) * step
        self._pose_y += math.sin(self._pose_theta) * step

        try:
            self.bus.publish(
                EventTopic.NAV_POSE,
                PoseEvent(timestamp=time.time(), x=self._pose_x, y=self._pose_y, theta=self._pose_theta),
            )
        except Exception:
            pass

    def _update_capture_fps(self) -> None:
        now = time.perf_counter()
        if self._last_capture_ts <= 0:
            self._last_capture_ts = now
            return
        dt = now - self._last_capture_ts
        self._last_capture_ts = now
        if dt <= 0:
            return
        instant = 1.0 / dt
        self._fps_capture = instant if self._fps_capture <= 0 else (0.9 * self._fps_capture + 0.1 * instant)

    def _publish_health_if_due(self) -> None:
        now = time.monotonic()
        if now - self._last_health_ts < 0.2:
            return
        self._last_health_ts = now
        memory = psutil.virtual_memory()
        self._power_status_cache = self._read_power_status(now)
        try:
            self.bus.publish(
                EventTopic.SYSTEM_HEALTH,
                HealthEvent(
                    timestamp=time.time(),
                    cpu_percent=float(psutil.cpu_percent(interval=None)),
                    fps_capture=float(self._fps_capture),
                    fps_process=float(self.vision.fps),
                    fps_ui=float(self.vision.fps),
                    queue_depth=int(self.bus.queue_depth),
                    metadata={
                        "memory_percent": float(memory.percent),
                        "memory_available_mb": round(float(memory.available) / (1024.0 * 1024.0), 1),
                        "network_latency_ms": 0.0,
                        "network": {
                            "latency_ms": 0.0,
                            "state": "local",
                            "peer": "local",
                        },
                        "camera": self._camera_status_payload(),
                        "serial": self._serial_status_payload(),
                        "power": dict(self._power_status_cache),
                        "profiles": self._profile_status_payload(),
                        "recording": self.session_recorder.status_payload(),
                        "vision": {
                            "latency_ms": float(self._last_detection_latency_ms),
                            "state": self._state_value(),
                        },
                    },
                ),
            )
        except Exception:
            pass

    def _open_camera(self) -> None:
        with self._capture_lock:
            self._release_camera_locked()
            for backend_name, backend in self._preferred_camera_backends():
                cap = cv2.VideoCapture(self.camera_index, backend)
                if cap is None or not cap.isOpened():
                    if cap is not None:
                        try:
                            cap.release()
                        except Exception:
                            pass
                    continue

                cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.camera_width)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.camera_height)
                cap.set(cv2.CAP_PROP_FPS, self.camera_fps)
                self._capture = cap
                self._camera_backend_name = backend_name
                self._camera_read_fail_streak = 0
                self._publish_log(
                    "INFO",
                    (
                        f"camera {self.camera_index} connected backend={backend_name} "
                        f"{self.camera_width}x{self.camera_height}@{self.camera_fps}"
                    ),
                )
                return

            self._capture = None
            self._camera_backend_name = ""

    def _get_capture(self) -> Any:
        with self._capture_lock:
            return self._capture

    def _release_camera(self) -> None:
        with self._capture_lock:
            self._release_camera_locked()

    def _release_camera_locked(self) -> None:
        cap = self._capture
        self._capture = None
        self._camera_backend_name = ""
        if cap is None:
            return
        try:
            cap.release()
        except Exception:
            pass

    def _preferred_camera_backends(self) -> list[tuple[str, int]]:
        backends: list[tuple[str, int]] = []
        if os.name == "nt" and hasattr(cv2, "CAP_DSHOW"):
            backends.append(("dshow", int(cv2.CAP_DSHOW)))
        elif hasattr(cv2, "CAP_V4L2"):
            backends.append(("v4l2", int(cv2.CAP_V4L2)))
        if hasattr(cv2, "CAP_ANY"):
            any_backend = int(cv2.CAP_ANY)
            if not any(value == any_backend for _, value in backends):
                backends.append(("any", any_backend))
        if not backends:
            backends.append(("default", 0))
        return backends

    def _handle_capture_read_failure(self) -> bool:
        self._camera_read_fail_streak += 1
        if self._camera_read_fail_streak == 1:
            self._publish_log("WARNING", f"camera {self.camera_index} frame read failed")
            return False
        if self._camera_read_fail_streak < self._camera_read_fail_threshold:
            return False

        streak = self._camera_read_fail_streak
        self._camera_read_fail_streak = 0
        self._publish_log(
            "WARNING",
            f"camera {self.camera_index} read failure streak={streak}; reopening capture",
        )
        self._release_camera()
        return True

    def _handle_capture_read_success(self) -> None:
        if self._camera_read_fail_streak <= 0:
            return
        streak = self._camera_read_fail_streak
        self._camera_read_fail_streak = 0
        self._publish_log("INFO", f"camera {self.camera_index} frame read recovered after {streak} failure(s)")

    def _request_safe_stop(self, reason: str, *, emergency: bool) -> None:
        state = self._state_value()
        try:
            if hasattr(self.robot, "request_safe_stop"):
                self.robot.request_safe_stop(reason=reason, state=state, emergency=emergency)
                return
            if emergency and hasattr(self.robot, "send_estop"):
                self.robot.send_estop(reason=reason, state=state)
                return
            if hasattr(self.robot, "send_stop"):
                self.robot.send_stop(reason=reason, state=state)
        except Exception as exc:
            self._publish_log("ERROR", f"robot failsafe command failed: {exc}")

    def _state_value(self) -> str:
        state = self.fsm.state
        return state.value if isinstance(state, RobotState) else str(state)

    def _apply_profile(self, profile_name: str, *, source: str) -> bool:
        profile = self._profile_catalog.get(profile_name)
        if profile is None:
            self._publish_log("WARNING", f"unknown config profile: {profile_name!r}")
            return False

        self._active_profile_name = profile.name
        self._active_profile = profile
        self._recording_auto_start = bool(profile.recording.get("auto_start", False))

        camera = profile.camera
        self.camera_index = int(camera.get("index", self.camera_index))
        self.camera_width = int(camera.get("width", self.camera_width))
        self.camera_height = int(camera.get("height", self.camera_height))
        self.camera_fps = max(1, int(camera.get("fps", self.camera_fps)))
        if self._get_capture() is not None:
            self._open_camera()

        for key, value in profile.tuning.items():
            self._apply_tuning(key, value)

        self.session_recorder.configure(profile.recording)
        should_start_recording = self._recording_auto_start and source != "startup"
        if should_start_recording and not self.session_recorder.status_payload()["enabled"]:
            self.session_recorder.start(reason=f"profile:{profile.name}", context=self._session_context())

        self._publish_log(
            "INFO",
            (
                f"profile applied name={profile.name} source={source} "
                f"camera={self.camera_index}:{self.camera_width}x{self.camera_height}@{self.camera_fps}"
            ),
        )
        return True

    def _profile_status_payload(self) -> dict[str, Any]:
        active_description = self._active_profile.description if self._active_profile is not None else "manual base config"
        return {
            "active": self._active_profile_name,
            "description": active_description,
            "available": self._profile_catalog.available_payload(),
        }

    def _session_context(self) -> dict[str, Any]:
        return {
            "profile": self._active_profile_name,
            "robot_backend": self._robot_backend,
            "camera": {
                "index": self.camera_index,
                "width": self.camera_width,
                "height": self.camera_height,
                "fps": self.camera_fps,
            },
            "config_path": str(self.config_path or self._profile_catalog.config_path),
        }

    def _camera_status_payload(self) -> dict[str, Any]:
        if self._get_capture() is None:
            state = "offline"
        elif self._camera_fault_active or self._camera_read_fail_streak > 0:
            state = "degraded"
        else:
            state = "online"
        return {
            "state": state,
            "index": int(self.camera_index),
            "width": int(self.camera_width),
            "height": int(self.camera_height),
            "fps": int(self.camera_fps),
            "backend": self._camera_backend_name,
            "read_fail_streak": int(self._camera_read_fail_streak),
        }

    def _serial_status_payload(self) -> dict[str, Any]:
        payload_fn = getattr(self.robot, "status_payload", None)
        if callable(payload_fn):
            try:
                payload = payload_fn()
                if isinstance(payload, Mapping):
                    return dict(payload)
            except Exception as exc:
                self._publish_log("ERROR", f"robot status payload failed: {exc}")

        connected = bool(getattr(self.robot, "connected", False))
        dry_run = bool(getattr(getattr(self.robot, "_config", None), "dry_run", False))
        if dry_run:
            state = "dry-run"
        elif connected:
            state = "connected"
        elif bool(getattr(self.robot, "enabled", False)):
            state = "waiting"
        else:
            state = "disabled"
        return {
            "state": state,
            "connected": connected,
            "port": str(getattr(self.robot, "resolved_port", "") or ""),
            "backend": self._robot_backend,
            "telemetry": {},
            "control_mode": "",
            "line_error": None,
            "pid_output": None,
            "obstacle_state": "",
            "green_instruction": "",
            "failsafe": False,
            "assist_kind": "none",
        }

    def _read_power_status(self, now: float) -> dict[str, Any]:
        if (now - self._last_power_sample_at) < 2.0:
            return dict(self._power_status_cache)
        self._last_power_sample_at = now
        binary = shutil.which("vcgencmd")
        if not binary:
            return {
                "available": False,
                "status": "unknown",
                "summary": "vcgencmd unavailable",
                "undervoltage_now": False,
                "undervoltage_occurred": False,
                "throttled_now": False,
                "throttled_occurred": False,
                "raw_value": "",
            }
        try:
            completed = subprocess.run(
                [binary, "get_throttled"],
                capture_output=True,
                text=True,
                timeout=0.4,
                check=False,
            )
        except Exception as exc:
            return {
                "available": False,
                "status": "unknown",
                "summary": f"power status failed: {exc}",
                "undervoltage_now": False,
                "undervoltage_occurred": False,
                "throttled_now": False,
                "throttled_occurred": False,
                "raw_value": "",
            }
        return self._parse_power_status(completed.stdout.strip() or completed.stderr.strip())

    @staticmethod
    def _parse_power_status(raw_text: str) -> dict[str, Any]:
        text = str(raw_text or "").strip().lower()
        if "0x" not in text:
            return {
                "available": False,
                "status": "unknown",
                "summary": raw_text or "vcgencmd returned no value",
                "undervoltage_now": False,
                "undervoltage_occurred": False,
                "throttled_now": False,
                "throttled_occurred": False,
                "raw_value": raw_text,
            }
        try:
            raw_value = int(text.split("0x", 1)[1], 16)
        except Exception:
            return {
                "available": False,
                "status": "unknown",
                "summary": raw_text,
                "undervoltage_now": False,
                "undervoltage_occurred": False,
                "throttled_now": False,
                "throttled_occurred": False,
                "raw_value": raw_text,
            }
        undervoltage_now = bool(raw_value & (1 << 0))
        throttled_now = bool(raw_value & (1 << 2))
        undervoltage_occurred = bool(raw_value & (1 << 16))
        throttled_occurred = bool(raw_value & (1 << 18))
        if undervoltage_now or throttled_now:
            status = "error"
            summary = "undervoltage/throttling active"
        elif undervoltage_occurred or throttled_occurred:
            status = "warn"
            summary = "power issue detected earlier"
        else:
            status = "ok"
            summary = "power stable"
        return {
            "available": True,
            "status": status,
            "summary": summary,
            "undervoltage_now": undervoltage_now,
            "undervoltage_occurred": undervoltage_occurred,
            "throttled_now": throttled_now,
            "throttled_occurred": throttled_occurred,
            "raw_value": f"0x{raw_value:x}",
        }

    @staticmethod
    def _is_valid_state_name(state_name: object) -> bool:
        return str(state_name).strip().upper() in RobotState._value2member_map_

    @staticmethod
    def _is_valid_state_object(state: object) -> bool:
        return isinstance(state, RobotState)

    def _publish_log(self, level: str, message: str) -> None:
        try:
            self.bus.publish(
                EventTopic.SYSTEM_LOG,
                LogEvent(
                    timestamp=time.time(),
                    level=level,
                    message=message,
                    source="live_runner",
                    state=self._state_value(),
                ),
            )
        except Exception:
            pass


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Live camera + AI runner for overengineering dashboard")
    parser.add_argument("--camera-index", type=int, default=0, help="Camera index")
    parser.add_argument("--camera-width", type=int, default=640, help="Camera capture width")
    parser.add_argument("--camera-height", type=int, default=480, help="Camera capture height")
    parser.add_argument("--camera-fps", type=int, default=30, help="Camera capture FPS target")
    parser.add_argument("--headless", action="store_true", help="Run only the AI + remote relay server, without opening a local dashboard")
    parser.add_argument(
        "--config",
        type=str,
        default="New_AI/obr_overengineering_v1/configs/vision_config.json",
        help="Vision config path",
    )
    parser.add_argument("--remote-bind", type=str, default="0.0.0.0", help="Bind address for the remote dashboard relay")
    parser.add_argument("--remote-port", type=int, default=8765, help="TCP port for the remote dashboard relay")
    parser.add_argument("--remote-stream-fps", type=float, default=8.0, help="Max frame rate sent to the remote dashboard")
    parser.add_argument("--remote-jpeg-quality", type=int, default=70, help="JPEG quality used for remote frame streaming")
    parser.add_argument("--robot-serial-port", type=str, default="", help="Arduino serial port on the Raspberry, for example /dev/ttyACM0")
    parser.add_argument("--robot-baud", type=int, default=115200, help="Arduino serial baud rate")
    parser.add_argument("--robot-backend", choices=("serial", "pca9685"), default="serial", help="Robot control backend")
    parser.add_argument("--robot-green-forward-ms", type=int, default=5000, help="Milliseconds sent on GREEN integration test")
    parser.add_argument("--robot-green-streak", type=int, default=2, help="Consecutive GREEN detections required before triggering")
    parser.add_argument("--robot-green-cooldown-ms", type=int, default=6000, help="Cooldown between GREEN motor commands")
    parser.add_argument("--robot-green-hold-ms", type=int, default=900, help="How long a GREEN assist stays valid on the Arduino")
    parser.add_argument("--robot-obstacle-hold-ms", type=int, default=1200, help="How long an obstacle assist stays valid on the Arduino")
    parser.add_argument("--robot-dry-run", action="store_true", help="Log robot commands without writing to serial")
    parser.add_argument("--pca9685-i2c-address", type=lambda value: int(str(value), 0), default=0x40, help="PCA9685 I2C address")
    parser.add_argument("--pca9685-frequency-hz", type=int, default=50, help="PCA9685 PWM frequency")
    parser.add_argument("--pca9685-left-channel", type=int, default=0, help="PCA9685 channel for the left servo/motor signal")
    parser.add_argument("--pca9685-right-channel", type=int, default=1, help="PCA9685 channel for the right servo/motor signal")
    parser.add_argument("--pca9685-min-us", type=int, default=1000, help="Minimum servo pulse width in microseconds")
    parser.add_argument("--pca9685-neutral-us", type=int, default=1500, help="Neutral/stop servo pulse width in microseconds")
    parser.add_argument("--pca9685-max-us", type=int, default=2000, help="Maximum servo pulse width in microseconds")
    parser.add_argument("--pca9685-base-throttle-us", type=int, default=120, help="Base signed pulse offset for line following")
    parser.add_argument("--pca9685-turn-gain-us", type=int, default=220, help="Turn correction gain in microseconds per normalized offset")
    parser.add_argument("--pca9685-max-output-us", type=int, default=360, help="Maximum signed pulse offset from neutral")
    parser.add_argument("--pca9685-green-turn-us", type=int, default=260, help="Signed pulse offset used for green maneuvers")
    parser.add_argument("--pca9685-left-inverted", action="store_true", help="Invert left servo/motor signal")
    parser.add_argument("--pca9685-right-inverted", action=argparse.BooleanOptionalAction, default=True, help="Invert right servo/motor signal")
    parser.add_argument("--profile", type=str, default="", help="Named ops profile from configs/vision_config.json")
    parser.add_argument("--recordings-root", type=str, default="", help="Output directory for session recordings")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    runner = LiveDashboardRunner(
        camera_index=args.camera_index,
        camera_width=args.camera_width,
        camera_height=args.camera_height,
        camera_fps=args.camera_fps,
        config_path=args.config,
        robot_serial_port=args.robot_serial_port,
        robot_baud=args.robot_baud,
        robot_green_forward_ms=args.robot_green_forward_ms,
        robot_green_streak=args.robot_green_streak,
        robot_green_cooldown_ms=args.robot_green_cooldown_ms,
        robot_green_hold_ms=args.robot_green_hold_ms,
        robot_obstacle_hold_ms=args.robot_obstacle_hold_ms,
        robot_dry_run=args.robot_dry_run,
        robot_backend=args.robot_backend,
        pca9685_i2c_address=args.pca9685_i2c_address,
        pca9685_frequency_hz=args.pca9685_frequency_hz,
        pca9685_left_channel=args.pca9685_left_channel,
        pca9685_right_channel=args.pca9685_right_channel,
        pca9685_min_us=args.pca9685_min_us,
        pca9685_neutral_us=args.pca9685_neutral_us,
        pca9685_max_us=args.pca9685_max_us,
        pca9685_base_throttle_us=args.pca9685_base_throttle_us,
        pca9685_turn_gain_us=args.pca9685_turn_gain_us,
        pca9685_max_output_us=args.pca9685_max_output_us,
        pca9685_green_turn_us=args.pca9685_green_turn_us,
        pca9685_left_inverted=args.pca9685_left_inverted,
        pca9685_right_inverted=args.pca9685_right_inverted,
        profile_name=(args.profile or "").strip() or None,
        recordings_root=(args.recordings_root or "").strip() or None,
    )
    remote_server: RemoteDashboardServer | None = None
    runner.start()
    try:
        if args.headless:
            remote_server = RemoteDashboardServer(
                runner.bus,
                host=args.remote_bind,
                port=args.remote_port,
                stream_fps=args.remote_stream_fps,
                jpeg_quality=args.remote_jpeg_quality,
            )
            remote_server.start()
            runner._publish_log(
                "INFO",
                (
                    f"remote dashboard relay listening on {args.remote_bind}:{args.remote_port} "
                    f"fps={args.remote_stream_fps} jpeg_q={args.remote_jpeg_quality}"
                ),
            )
            try:
                while True:
                    time.sleep(0.5)
            except KeyboardInterrupt:
                return 0
        if __package__ in (None, ""):
            from src.ui_overengineering.dashboard import run_dashboard
        else:
            from .ui_overengineering.dashboard import run_dashboard
        return run_dashboard(
            event_bus=runner.bus,
            camera_index=args.camera_index,
            camera_width=args.camera_width,
            camera_height=args.camera_height,
            camera_fps=args.camera_fps,
            mock=False,
            config_path=args.config,
        )
    finally:
        if remote_server is not None:
            remote_server.stop()
        runner.stop()


if __name__ == "__main__":
    raise SystemExit(main())
