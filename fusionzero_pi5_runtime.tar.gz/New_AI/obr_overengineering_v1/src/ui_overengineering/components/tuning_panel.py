from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from PyQt6.QtCore import QEvent, QObject, QTimer, Qt, QUrl, pyqtSignal
from PyQt6.QtGui import QDesktopServices, QGuiApplication
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from .base import CardFrame


class TuningPanel(CardFrame):
    parameter_changed = pyqtSignal(str, object)
    camera_reconnect_requested = pyqtSignal(dict)
    mock_mode_changed = pyqtSignal(bool)
    mode_switch_requested = pyqtSignal(str)
    robot_command_requested = pyqtSignal(str, dict)
    profile_apply_requested = pyqtSignal(str)
    recording_command_requested = pyqtSignal(str, dict)
    calibration_changed = pyqtSignal(dict)
    calibration_snapshot_requested = pyqtSignal(dict)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__("Operations", parent)
        self._controls: dict[str, QSpinBox | QDoubleSpinBox] = {}
        self._defaults: dict[str, float | int] = {}
        self._profiles: dict[str, dict[str, Any]] = {}
        self._last_recording_session_dir = ""

        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._scroll_content = QWidget(self.scroll_area)
        self._scroll_content.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        root = QVBoxLayout(self._scroll_content)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(8)

        root.addWidget(self._build_profile_group(self._scroll_content))
        root.addWidget(self._build_camera_group(self._scroll_content))
        root.addWidget(self._build_calibration_group(self._scroll_content))
        root.addWidget(self._build_recording_group(self._scroll_content))
        root.addWidget(self._build_line_group(self._scroll_content))
        root.addWidget(self._build_color_group(self._scroll_content))
        root.addWidget(self._build_ball_group(self._scroll_content))
        root.addWidget(self._build_robot_group(self._scroll_content))
        root.addWidget(self._build_actions_group(self._scroll_content))
        root.addStretch(1)

        self.scroll_area.setWidget(self._scroll_content)
        self.scroll_area.viewport().installEventFilter(self)
        self.content_layout.addWidget(self.scroll_area, 1)
        QTimer.singleShot(0, self._sync_scroll_content_width)

    def eventFilter(self, watched: QObject | None, event: QEvent | None) -> bool:  # type: ignore[name-defined]
        if watched is self.scroll_area.viewport() and event is not None and event.type() == QEvent.Type.Resize:
            QTimer.singleShot(0, self._sync_scroll_content_width)
        return super().eventFilter(watched, event)

    def _build_profile_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Profiles", parent)
        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        self.profile_combo = QComboBox(group)
        self.profile_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.profile_combo.setMinimumContentsLength(14)
        layout.addWidget(self.profile_combo)

        self.apply_profile_button = QPushButton("Apply profile", group)
        self.apply_profile_button.clicked.connect(self._emit_profile_apply)
        layout.addWidget(self.apply_profile_button)

        self.profile_status_label = self._build_detail_label(group, "Using manual base config")
        layout.addWidget(self.profile_status_label)
        return self._finalize_group(group)

    def _build_camera_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Camera", parent)
        layout = QVBoxLayout(group)
        form = QFormLayout()
        form.setContentsMargins(8, 8, 8, 8)
        form.setSpacing(6)

        self._add_spin(form, "camera.index", "Index", 0, 8, 0)
        self._add_spin(form, "camera.width", "Width", 160, 1920, 640, step=16)
        self._add_spin(form, "camera.height", "Height", 120, 1080, 480, step=16)
        self._add_spin(form, "camera.fps", "FPS", 1, 120, 30)
        layout.addLayout(form)

        self.mock_checkbox = QCheckBox("Mock mode", group)
        self.mock_checkbox.setChecked(False)
        self.mock_checkbox.toggled.connect(self.mock_mode_changed.emit)
        layout.addWidget(self.mock_checkbox)

        reconnect = QPushButton("Reconnect camera", group)
        reconnect.clicked.connect(self._emit_camera_reconnect)
        layout.addWidget(reconnect)
        return self._finalize_group(group)

    def _build_calibration_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Calibration", parent)
        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        self.calibration_view_combo = QComboBox(group)
        self.calibration_view_combo.addItem("Raw frame", "raw")
        self.calibration_view_combo.addItem("Processed view", "processed")
        self.calibration_view_combo.addItem("Line mask", "line_mask")
        self.calibration_view_combo.addItem("Green mask", "green_mask")
        self.calibration_view_combo.addItem("Red mask", "red_mask")
        self.calibration_view_combo.addItem("Victim mask", "victim_mask")
        self.calibration_view_combo.addItem("Composite debug", "composite")
        self.calibration_view_combo.currentIndexChanged.connect(self._emit_calibration_changed)
        layout.addWidget(self.calibration_view_combo)

        self.freeze_checkbox = QCheckBox("Freeze current frame", group)
        self.freeze_checkbox.toggled.connect(self._emit_calibration_changed)
        layout.addWidget(self.freeze_checkbox)

        snapshot_button = QPushButton("Audit snapshot", group)
        snapshot_button.clicked.connect(
            lambda: self.calibration_snapshot_requested.emit(self.current_calibration_options())
        )
        layout.addWidget(snapshot_button)

        self.calibration_status_label = self._build_detail_label(group, "Raw frame live")
        layout.addWidget(self.calibration_status_label)
        return self._finalize_group(group)

    def _build_recording_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Session Recording", parent)
        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        self.record_raw_checkbox = QCheckBox("Sample raw frames", group)
        self.record_raw_checkbox.setChecked(False)
        layout.addWidget(self.record_raw_checkbox)

        self.record_processed_checkbox = QCheckBox("Sample processed frames", group)
        self.record_processed_checkbox.setChecked(True)
        layout.addWidget(self.record_processed_checkbox)

        form = QFormLayout()
        form.setContentsMargins(0, 0, 0, 0)
        form.setSpacing(6)
        self.record_every_spin = QSpinBox(group)
        self.record_every_spin.setMinimum(1)
        self.record_every_spin.setMaximum(600)
        self.record_every_spin.setValue(20)
        form.addRow("Every N frames", self.record_every_spin)
        layout.addLayout(form)

        start_row = QHBoxLayout()
        start_row.setContentsMargins(0, 0, 0, 0)
        start_row.setSpacing(6)
        self.recording_start_button = QPushButton("Start recording", group)
        self.recording_start_button.clicked.connect(
            lambda: self.recording_command_requested.emit("start", self.current_recording_options())
        )
        start_row.addWidget(self.recording_start_button)

        self.recording_apply_button = QPushButton("Apply options", group)
        self.recording_apply_button.clicked.connect(
            lambda: self.recording_command_requested.emit("configure", self.current_recording_options())
        )
        start_row.addWidget(self.recording_apply_button)
        layout.addLayout(start_row)

        stop_row = QHBoxLayout()
        stop_row.setContentsMargins(0, 0, 0, 0)
        stop_row.setSpacing(6)
        self.recording_stop_button = QPushButton("Stop recording", group)
        self.recording_stop_button.clicked.connect(lambda: self.recording_command_requested.emit("stop", {}))
        stop_row.addWidget(self.recording_stop_button)

        self.recording_open_button = QPushButton("Open folder", group)
        self.recording_open_button.clicked.connect(self._open_recording_folder)
        stop_row.addWidget(self.recording_open_button)
        layout.addLayout(stop_row)

        self.recording_copy_button = QPushButton("Copy path", group)
        self.recording_copy_button.clicked.connect(self._copy_recording_path)
        layout.addWidget(self.recording_copy_button)

        self.recording_status_label = self._build_detail_label(group, "Recorder idle")
        layout.addWidget(self.recording_status_label)

        self.recording_path_label = self._build_detail_label(group, "No session folder yet", selectable=True)
        layout.addWidget(self.recording_path_label)
        self._refresh_recording_buttons(active=False)
        return self._finalize_group(group)

    def _build_line_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Line Detector", parent)
        form = QFormLayout(group)
        form.setContentsMargins(8, 8, 8, 8)
        form.setSpacing(6)
        self._add_spin(form, "line.black_v_max", "Black V max", 0, 255, 70)
        self._add_spin(form, "line.black_s_max", "Black S max", 0, 255, 255)
        self._add_spin(form, "line.min_area", "Min area", 1, 4000, 50)
        self._add_spin(form, "line.erode_iter", "Erode iter", 0, 8, 3)
        self._add_spin(form, "line.dilate_iter", "Dilate iter", 0, 8, 4)
        return self._finalize_group(group)

    def _build_color_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Markers", parent)
        form = QFormLayout(group)
        form.setContentsMargins(8, 8, 8, 8)
        form.setSpacing(6)
        self._add_spin(form, "green.h_min", "Green H min", 0, 179, 35)
        self._add_spin(form, "green.h_max", "Green H max", 0, 179, 90)
        self._add_spin(form, "green.s_min", "Green S min", 0, 255, 70)
        self._add_spin(form, "green.v_min", "Green V min", 0, 255, 50)
        self._add_spin(form, "green.min_area", "Green area", 1, 6000, 180)

        self._add_spin(form, "red.h1_min", "Red H1 min", 0, 179, 0)
        self._add_spin(form, "red.h1_max", "Red H1 max", 0, 179, 12)
        self._add_spin(form, "red.h2_min", "Red H2 min", 0, 179, 165)
        self._add_spin(form, "red.h2_max", "Red H2 max", 0, 179, 179)
        self._add_spin(form, "red.s_min", "Red S min", 0, 255, 120)
        self._add_spin(form, "red.v_min", "Red V min", 0, 255, 80)
        self._add_spin(form, "red.min_area", "Red area", 1, 6000, 300)
        return self._finalize_group(group)

    def _build_ball_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Balls / Victims", parent)
        form = QFormLayout(group)
        form.setContentsMargins(8, 8, 8, 8)
        form.setSpacing(6)
        self._add_double(form, "silver.conf", "Silver conf", 0.0, 1.0, 0.95, 0.01)
        self._add_spin(form, "silver.blur", "Silver blur", 3, 31, 7, step=2)
        self._add_spin(form, "dead.black_v_max", "Black V max", 0, 120, 60)
        return self._finalize_group(group)

    def _build_robot_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Robot", parent)
        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        form = QFormLayout()
        form.setContentsMargins(0, 0, 0, 0)
        form.setSpacing(6)
        self.robot_forward_ms_spin = QSpinBox(group)
        self.robot_forward_ms_spin.setMinimum(100)
        self.robot_forward_ms_spin.setMaximum(15000)
        self.robot_forward_ms_spin.setSingleStep(100)
        self.robot_forward_ms_spin.setValue(1200)
        form.addRow("Forward ms", self.robot_forward_ms_spin)
        layout.addLayout(form)

        button_row = QHBoxLayout()
        button_row.setContentsMargins(0, 0, 0, 0)
        button_row.setSpacing(6)

        forward_button = QPushButton("Forward test", group)
        forward_button.clicked.connect(self._emit_robot_forward_test)
        button_row.addWidget(forward_button)

        stop_button = QPushButton("STOP", group)
        stop_button.clicked.connect(self._emit_robot_stop)
        button_row.addWidget(stop_button)
        layout.addLayout(button_row)

        estop_row = QHBoxLayout()
        estop_row.setContentsMargins(0, 0, 0, 0)
        estop_row.setSpacing(6)

        force_stop_button = QPushButton("Force STOP", group)
        force_stop_button.clicked.connect(self._emit_robot_force_stop)
        estop_row.addWidget(force_stop_button)

        clear_estop_button = QPushButton("Clear ESTOP", group)
        clear_estop_button.clicked.connect(self._emit_robot_clear_estop)
        estop_row.addWidget(clear_estop_button)
        layout.addLayout(estop_row)

        obstacle_row = QHBoxLayout()
        obstacle_row.setContentsMargins(0, 0, 0, 0)
        obstacle_row.setSpacing(6)

        obstacle_test_button = QPushButton("Obstacle test", group)
        obstacle_test_button.clicked.connect(self._emit_robot_obstacle_test)
        obstacle_row.addWidget(obstacle_test_button)

        obstacle_clear_button = QPushButton("Clear obstacle", group)
        obstacle_clear_button.clicked.connect(self._emit_robot_obstacle_clear)
        obstacle_row.addWidget(obstacle_clear_button)
        layout.addLayout(obstacle_row)

        self.robot_status_label = self._build_detail_label(
            group,
            "Robot commands and obstacle test triggers are forwarded as UI_COMMAND events to the live runner.",
        )
        layout.addWidget(self.robot_status_label)
        return self._finalize_group(group)

    def _build_actions_group(self, parent: QWidget) -> QGroupBox:
        group = QGroupBox("Actions", parent)
        layout = QVBoxLayout(group)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        mode_row = QHBoxLayout()
        mode_row.setContentsMargins(0, 0, 0, 0)
        mode_row.setSpacing(6)
        force_line = QPushButton("Force LINE", group)
        force_line.clicked.connect(lambda: self.mode_switch_requested.emit("line"))
        mode_row.addWidget(force_line)

        force_rescue = QPushButton("Force RESCUE", group)
        force_rescue.clicked.connect(lambda: self.mode_switch_requested.emit("rescue"))
        mode_row.addWidget(force_rescue)
        layout.addLayout(mode_row)

        reset = QPushButton("Reset defaults", group)
        reset.clicked.connect(self.reset_defaults)
        layout.addWidget(reset)
        return self._finalize_group(group)

    def _build_detail_label(self, parent: QWidget, text: str, *, selectable: bool = False) -> QLabel:
        label = QLabel(text, parent)
        label.setObjectName("HealthDetail")
        label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        label.setWordWrap(True)
        label.setTextFormat(Qt.TextFormat.PlainText)
        label.setMinimumWidth(0)
        label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        if selectable:
            label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        return label

    @staticmethod
    def _finalize_group(group: QGroupBox) -> QGroupBox:
        group.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        return group

    def _sync_scroll_content_width(self) -> None:
        viewport_width = self.scroll_area.viewport().width()
        if viewport_width <= 0:
            return
        if self._scroll_content.width() != viewport_width:
            self._scroll_content.setFixedWidth(viewport_width)

    def _add_spin(
        self,
        form: QFormLayout,
        key: str,
        label: str,
        minimum: int,
        maximum: int,
        value: int,
        step: int = 1,
    ) -> None:
        spin = QSpinBox(form.parentWidget())
        spin.setMinimum(minimum)
        spin.setMaximum(maximum)
        spin.setSingleStep(step)
        spin.setValue(value)
        spin.valueChanged.connect(lambda v, item=key: self.parameter_changed.emit(item, int(v)))
        form.addRow(label, spin)
        self._controls[key] = spin
        self._defaults[key] = int(value)

    def _add_double(
        self,
        form: QFormLayout,
        key: str,
        label: str,
        minimum: float,
        maximum: float,
        value: float,
        step: float,
    ) -> None:
        spin = QDoubleSpinBox(form.parentWidget())
        spin.setMinimum(minimum)
        spin.setMaximum(maximum)
        spin.setSingleStep(step)
        spin.setValue(value)
        spin.setDecimals(3 if step < 0.01 else 2)
        spin.valueChanged.connect(lambda v, item=key: self.parameter_changed.emit(item, float(v)))
        form.addRow(label, spin)
        self._controls[key] = spin
        self._defaults[key] = float(value)

    def _emit_camera_reconnect(self) -> None:
        self.camera_reconnect_requested.emit(
            {
                "index": int(self.value("camera.index", 0)),
                "width": int(self.value("camera.width", 640)),
                "height": int(self.value("camera.height", 480)),
                "fps": int(self.value("camera.fps", 30)),
            }
        )

    def _emit_profile_apply(self) -> None:
        name = str(self.profile_combo.currentData() or "").strip().lower()
        if name:
            self.profile_apply_requested.emit(name)

    def _open_recording_folder(self) -> None:
        session_dir = self._recording_session_dir_path()
        if session_dir is None:
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(session_dir)))

    def _copy_recording_path(self) -> None:
        session_dir = self._recording_session_dir_path()
        if session_dir is None:
            return
        clipboard = QGuiApplication.clipboard()
        if clipboard is not None:
            clipboard.setText(str(session_dir))

    def _emit_robot_forward_test(self) -> None:
        self.robot_command_requested.emit(
            "robot.forward_test",
            {"duration_ms": int(self.robot_forward_ms_spin.value())},
        )

    def _emit_robot_stop(self) -> None:
        self.robot_command_requested.emit("robot.stop", {})

    def _emit_robot_force_stop(self) -> None:
        self.robot_command_requested.emit("robot.force_stop", {})

    def _emit_robot_clear_estop(self) -> None:
        self.robot_command_requested.emit("robot.clear_estop", {})

    def _emit_robot_obstacle_test(self) -> None:
        self.robot_command_requested.emit("robot.obstacle_test", {})

    def _emit_robot_obstacle_clear(self) -> None:
        self.robot_command_requested.emit("robot.obstacle_clear", {})

    def _emit_calibration_changed(self) -> None:
        payload = self.current_calibration_options()
        view_name = str(self.calibration_view_combo.currentText()).strip()
        suffix = "frozen" if payload["freeze"] else "live"
        self.calibration_status_label.setText(f"{view_name} {suffix}")
        self.calibration_changed.emit(payload)

    def reset_defaults(self) -> None:
        self.apply_values(self._defaults, emit_changes=True)

    def set_mock_mode(self, enabled: bool) -> None:
        self.mock_checkbox.blockSignals(True)
        self.mock_checkbox.setChecked(bool(enabled))
        self.mock_checkbox.blockSignals(False)

    def set_profiles(self, profiles: list[Mapping[str, Any]], active_name: str | None = None) -> None:
        current_name = str(active_name or self.profile_combo.currentData() or "").strip().lower()
        self._profiles = {}
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        for payload in profiles:
            if not isinstance(payload, Mapping):
                continue
            name = str(payload.get("name", "")).strip().lower()
            if not name:
                continue
            description = str(payload.get("description", name.replace("_", " ").title())).strip()
            self.profile_combo.addItem(name, name)
            self.profile_combo.setItemData(self.profile_combo.count() - 1, description, Qt.ItemDataRole.ToolTipRole)
            self._profiles[name] = dict(payload)
        self.profile_combo.blockSignals(False)

        if current_name:
            for idx in range(self.profile_combo.count()):
                if str(self.profile_combo.itemData(idx) or "").strip().lower() == current_name:
                    self.profile_combo.setCurrentIndex(idx)
                    break

    def set_active_profile(self, name: str, description: str = "") -> None:
        active = str(name or "custom").strip().lower() or "custom"
        for idx in range(self.profile_combo.count()):
            if str(self.profile_combo.itemData(idx) or "").strip().lower() == active:
                self.profile_combo.setCurrentIndex(idx)
                break
        text = description.strip() if description else active.replace("_", " ")
        self.profile_combo.setToolTip(text)
        self.profile_status_label.setText(f"Active profile: {active}\n{text}")
        self.profile_status_label.setToolTip(text)
        self._sync_scroll_content_width()

    def update_recording_status(self, payload: Mapping[str, Any]) -> None:
        enabled = bool(payload.get("enabled", False))
        options = payload.get("options", {})
        if isinstance(options, Mapping):
            self.record_raw_checkbox.setChecked(bool(options.get("include_raw", self.record_raw_checkbox.isChecked())))
            self.record_processed_checkbox.setChecked(
                bool(options.get("include_processed", self.record_processed_checkbox.isChecked()))
            )
            self.record_every_spin.setValue(max(1, int(options.get("every_n_frames", self.record_every_spin.value()))))

        session_dir = str(payload.get("session_dir", "")).strip()
        if session_dir:
            self._last_recording_session_dir = session_dir

        if enabled:
            event_count = int(payload.get("event_count", 0))
            frame_count = int(payload.get("frame_count", 0))
            summary = f"REC ON | {event_count} events | {frame_count} frames"
            dropped = int(payload.get("dropped_records", 0))
            if dropped > 0:
                summary = f"{summary} | dropped {dropped}"
        else:
            summary = "Recorder idle"
            if self._last_recording_session_dir:
                summary = f"{summary} | last session available"
        self.recording_status_label.setText(summary)
        if self._last_recording_session_dir:
            self.recording_path_label.setText(self._display_recording_path(self._last_recording_session_dir))
            self.recording_path_label.setToolTip(self._last_recording_session_dir)
        else:
            self.recording_path_label.setText("No session folder yet")
            self.recording_path_label.setToolTip("")
        self._refresh_recording_buttons(active=enabled)
        self._sync_scroll_content_width()

    def current_recording_options(self) -> dict[str, Any]:
        return {
            "include_raw": bool(self.record_raw_checkbox.isChecked()),
            "include_processed": bool(self.record_processed_checkbox.isChecked()),
            "every_n_frames": int(self.record_every_spin.value()),
        }

    def _recording_session_dir_path(self) -> Path | None:
        session_dir = self._last_recording_session_dir.strip()
        if not session_dir:
            return None
        try:
            candidate = Path(session_dir)
        except Exception:
            return None
        return candidate if candidate.exists() else None

    def _refresh_recording_buttons(self, *, active: bool) -> None:
        has_known_path = bool(self._last_recording_session_dir.strip())
        local_path_available = self._recording_session_dir_path() is not None
        self.recording_start_button.setEnabled(not active)
        self.recording_apply_button.setEnabled(True)
        self.recording_stop_button.setEnabled(active)
        self.recording_open_button.setEnabled(local_path_available)
        self.recording_copy_button.setEnabled(has_known_path)

    @staticmethod
    def _display_recording_path(session_dir: str) -> str:
        cleaned = str(session_dir).strip()
        if not cleaned:
            return "No session folder yet"
        try:
            parts = [part for part in Path(cleaned).parts if part and part != Path(cleaned).anchor]
        except Exception:
            return cleaned
        if not parts:
            return cleaned
        tail = parts[-3:]
        head = "/".join(tail[:-1])
        if len(parts) > len(tail) and head:
            head = f".../{head}"
        elif len(parts) > len(tail):
            head = "..."
        if head:
            return f"{head}\n{tail[-1]}"
        return tail[-1]

    def current_calibration_options(self) -> dict[str, Any]:
        return {
            "view_mode": str(self.calibration_view_combo.currentData() or "raw"),
            "freeze": bool(self.freeze_checkbox.isChecked()),
        }

    def control_snapshot(self) -> dict[str, Any]:
        return {key: self.value(key, default) for key, default in self._defaults.items()}

    def apply_values(self, values: Mapping[str, Any], *, emit_changes: bool) -> None:
        for key, value in values.items():
            control = self._controls.get(str(key))
            if control is None:
                continue
            control.blockSignals(True)
            if isinstance(control, QDoubleSpinBox):
                control.setValue(float(value))
            else:
                control.setValue(int(value))
            control.blockSignals(False)
            if emit_changes:
                self.parameter_changed.emit(str(key), self.value(str(key), value))

    def set_camera_values(self, values: Mapping[str, Any]) -> None:
        camera_values = {
            "camera.index": int(values.get("index", self.value("camera.index", 0))),
            "camera.width": int(values.get("width", self.value("camera.width", 640))),
            "camera.height": int(values.get("height", self.value("camera.height", 480))),
            "camera.fps": int(values.get("fps", self.value("camera.fps", 30))),
        }
        self.apply_values(camera_values, emit_changes=False)

    def value(self, key: str, fallback: Any = None) -> Any:
        control = self._controls.get(key)
        if control is None:
            return fallback
        if isinstance(control, QDoubleSpinBox):
            return float(control.value())
        return int(control.value())
