from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Palette:
    bg: str = "#1F2126"
    surface: str = "#272A31"
    surface_alt: str = "#2D3037"
    border: str = "#3A3F48"
    text: str = "#E8EAF0"
    text_dim: str = "#AEB5C2"
    accent: str = "#33D17A"
    danger: str = "#E24E5D"
    warning: str = "#F4C95D"
    chip_bg: str = "#171A1F"


PALETTE = Palette()


def build_dashboard_stylesheet() -> str:
    p = PALETTE
    return f"""
QWidget#DashboardRoot {{
    background-color: {p.bg};
    color: {p.text};
    font-family: "Segoe UI";
    font-size: 12px;
}}
QFrame#CardFrame {{
    background-color: {p.surface};
    border: 1px solid {p.border};
    border-radius: 10px;
}}
QLabel#CardTitle {{
    color: {p.text_dim};
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.5px;
}}
QFrame#MetricPill {{
    background-color: {p.chip_bg};
    border: 1px solid {p.border};
    border-radius: 6px;
}}
QLabel#MetricKey {{
    color: {p.text_dim};
    font-size: 11px;
    font-weight: 600;
}}
QLabel#MetricValue {{
    color: {p.text};
    font-size: 13px;
    font-weight: 700;
}}
QLabel#HealthKey {{
    color: {p.text_dim};
    font-size: 11px;
    font-weight: 600;
}}
QLabel#HealthValue {{
    color: {p.text};
    font-size: 12px;
    font-weight: 700;
}}
QLabel#HealthValue[level="ok"] {{
    color: {p.accent};
}}
QLabel#HealthValue[level="warn"] {{
    color: {p.warning};
}}
QLabel#HealthValue[level="error"] {{
    color: {p.danger};
}}
QLabel#HealthDetail {{
    color: {p.text_dim};
    font-size: 11px;
}}
QFrame#StatusBadge {{
    background-color: {p.chip_bg};
    border: 1px solid {p.border};
    border-radius: 6px;
}}
QFrame#StatusBadge[active="true"] {{
    border: 1px solid {p.accent};
}}
QLabel#StatusName {{
    color: {p.text_dim};
    font-size: 10px;
    font-weight: 600;
}}
QLabel#StatusValue {{
    color: {p.text};
    font-size: 11px;
    font-weight: 700;
}}
QLabel#StatusValue[active="true"] {{
    color: {p.accent};
}}
QLabel#StatusValue[active="false"] {{
    color: {p.danger};
}}
QLabel#VideoLabel {{
    background-color: #101216;
    border: 1px solid {p.border};
    border-radius: 8px;
}}
QLabel#OverlayText {{
    background-color: rgba(16, 18, 22, 180);
    color: {p.text};
    border: 1px solid {p.border};
    border-radius: 6px;
    padding: 3px 8px;
    font-weight: 600;
}}
QLabel#StateHeadline {{
    font-size: 18px;
    font-weight: 700;
    color: {p.text};
}}
QLabel#StateSummary {{
    color: {p.text_dim};
    font-size: 13px;
}}
QLabel#TimerMain {{
    font-size: 42px;
    font-weight: 700;
    color: {p.text};
}}
QLabel#TimerSecondary {{
    font-size: 26px;
    font-weight: 600;
    color: {p.text_dim};
}}
QListWidget#TransitionList {{
    background-color: #1A1D23;
    border: 1px solid {p.border};
    border-radius: 8px;
    color: {p.text};
}}
QGroupBox {{
    border: 1px solid {p.border};
    border-radius: 8px;
    margin-top: 10px;
    padding-top: 10px;
    font-weight: 600;
    color: {p.text_dim};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 8px;
    padding: 0 4px;
}}
QSpinBox, QDoubleSpinBox {{
    background-color: #151920;
    border: 1px solid {p.border};
    border-radius: 4px;
    padding: 3px 4px;
    color: {p.text};
}}
QPushButton {{
    background-color: #11151B;
    border: 1px solid {p.border};
    border-radius: 6px;
    padding: 5px 10px;
    color: {p.text};
    font-weight: 600;
}}
QPushButton:hover {{
    background-color: #181D25;
}}
QCheckBox {{
    spacing: 6px;
}}
QCheckBox::indicator {{
    width: 14px;
    height: 14px;
}}
QCheckBox::indicator:unchecked {{
    border: 1px solid {p.border};
    background-color: #151920;
    border-radius: 3px;
}}
QCheckBox::indicator:checked {{
    border: 1px solid {p.accent};
    background-color: {p.accent};
    border-radius: 3px;
}}
QScrollArea {{
    border: none;
}}
QWidget#SteeringPanel {{
    background-color: transparent;
}}
QLabel#SteeringChip {{
    background-color: #12161C;
    border: 1px solid {p.border};
    border-radius: 4px;
    color: {p.text};
    min-height: 28px;
    max-height: 28px;
    font-size: 12px;
    font-weight: 700;
}}
QLabel#SteeringArrow {{
    background-color: #12161C;
    border: 1px solid {p.border};
    border-radius: 4px;
    color: {p.text};
    min-height: 28px;
    max-height: 28px;
    font-size: 16px;
    font-weight: 700;
}}
QLabel#SteeringText {{
    background-color: #12161C;
    border: 1px solid {p.border};
    border-radius: 4px;
    color: {p.text_dim};
    min-height: 24px;
    max-height: 24px;
    font-size: 11px;
    font-weight: 600;
}}
"""
